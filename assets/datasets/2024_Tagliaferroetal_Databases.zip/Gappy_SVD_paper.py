#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 23 15:46:36 2023

@author: adrian
"""

#%reset

import numpy as np
import scipy.io
import hdf5storage
#import hosvd 
from scipy.interpolate import griddata
import os               # To create/open folders
from numpy import linalg as LA
import matplotlib.pyplot as plt
import pandas as pd
from mpl_toolkits.mplot3d import Axes3D
from numpy import savetxt

## INPUTS
#database='C:\Users\Sofia\OneDrive - Università degli Studi di Verona\MEET-OUT\Pollini\DB_R\Madrid\DB\pollen_2018_2022_ML.csv' #database: name of the file: the .mat is a matrix with form [n,m]
#file_path='/home/sole/Desktop/SOFIA/Gappy_SVD/pollen_2018_2022_ML.csv'
path0 = os.getcwd()
path1 = path0 + '/paper/5%NAs/3days/'
folder = 'mean10'
path2 = path1+folder
os.mkdir(path2)


with open(f'{path0}/pollen_2018_2022_ML.csv') as x:
    ncols = len(x.readline().split(','))
database2 = pd.read_csv(f'{path0}/pollen_2018_2022_ML.csv', sep=',', usecols=range(1,ncols), skiprows = 1,header = None).to_numpy()

method = 'svd' # SVD for matrices, HOSVD for Tensor
m = 10 # Number of modes to retain on the reconstruction
decision_1 = 'mean' # IMPLEMENTED: 'zeros', 'mean', 'interp_1d' (suitable for a matrix with variables in columns),
                         #              'interp_2d' (suitable for surfaces, method = 'nearest' the rest do not work)

## OUTPUTS
output_1 = 'yes' # Decay of the singular values before/after
output_2 = 'yes' # Comparison of the surfaces

A = pd.read_csv(f'{path1}alnus_bz2.csv', sep=',', skiprows = 1,header = None).to_numpy()
B = pd.read_csv(f'{path1}alnus_vi1.csv', sep=',', skiprows = 1,header = None).to_numpy()
C = pd.read_csv(f'{path1}gram_bz2.csv', sep=',', skiprows = 1,header = None).to_numpy()
D = pd.read_csv(f'{path1}gram_vi1.csv', sep=',', skiprows = 1,header = None).to_numpy()

RRMSE_iterA = np.zeros(100)
RRMSE_iterB = np.zeros(100)
RRMSE_iterC = np.zeros(100)
RRMSE_iterD = np.zeros(100)

for iter in range(100):
    database = database2.copy()
    database[1461:1611,2] = A[:-1,iter]
    database[1461:1611,13] = B[:-1,iter]
    database[1551:1764,62] = C[:-1,iter]
    database[1551:1764,73] = D[:-1,iter]
    namefile = "/Database_%d.csv" % (iter+1)
    namefile = f'{path2}' + namefile
    savetxt(namefile, database, delimiter=',')
    # Read Matrix
    #A_gappy_ = hdf5storage.loadmat(database)
    A_gappy=database
    print('here0')
    print(np.shape(A_gappy))
    #A_gappy = list(A_gappy_.values())[-1]
    
    N = sum(np.isnan(A_gappy.flatten()))
    
    # Initial reconstruction
    if decision_1 == 'zeros':
        A0_1 = np.nan_to_num(A_gappy)
    elif decision_1 == 'mean':
        A0_1 = np.nan_to_num(A_gappy)
        A0_1 = np.nan_to_num(A_gappy,nan=sum(A0_1.flatten())/(A0_1.size-N))
    elif decision_1 == 'interp_1d':
        A0_1 = np.zeros(A_gappy.shape)
        # y = np.linspace(0, 1, A_gappy.shape[1])
        y = np.linspace(0, 1, A_gappy.shape[0])
        for j in range(np.size(A_gappy,1)):   
            A_gappycolumn = A_gappy[:,j]
            A0_1[:,j] = np.interp(y, y[np.isfinite(A_gappy[:,j])], A_gappycolumn[np.isfinite(A_gappy[:,j])])
    elif decision_1 == 'interp_2d':
        x = np.linspace(0, 1, A_gappy.shape[0])
        y = np.linspace(0, 1, A_gappy.shape[1])
        xv, yv = np.meshgrid(y, x)
        xnumber = xv[np.isfinite(A_gappy)]
        ynumber = yv[np.isfinite(A_gappy)]
        A0_1 = griddata(np.transpose(np.array([xnumber, ynumber])), A_gappy[np.isfinite(A_gappy)] , (xv, yv), method='nearest')
                        
    # Start the reconstruction (loop)
    A_s = A0_1.copy()
    print('here0')
    print(np.shape(A_s))
    MSE_gaps = np.zeros(500)
    
    for ii in range(500):
                      
        if method == 'svd':
            [U,S,V]=LA.svd(A_s)
            S = np.diag(S)
            A_reconst = U[:,0:m] @ S[0:m,0:m] @ V[0:m,:]
        elif method == 'hosvd':
            n = m*np.ones(np.shape(A_s.shape))
            A_reconst = hosvd.HOSVD_function(A_s,n)[0]
        
        MSE_gaps[ii] = LA.norm(A_reconst[np.isnan(A_gappy)]-A_s[np.isnan(A_gappy)])/N
    
        if ii>3 and MSE_gaps[ii]>=MSE_gaps[ii-1]:
            break
        else:
            A_s[np.isnan(A_gappy)] = A_reconst[np.isnan(A_gappy)]

    A_s[A_s<0]=0
    # save to csv file
    #savetxt(f'{path0}/data_reconstructed_interp1d_5m.csv', A_s, delimiter=',')
    RRMSE_iterA[iter] = LA.norm(database2[1461:1611,2]-A_s[1461:1611,2])/np.sqrt(151)
    RRMSE_iterB[iter] = LA.norm(database2[1461:1611,13]-A_s[1461:1611,13])/np.sqrt(151)
    RRMSE_iterC[iter] = LA.norm(database2[1551:1764,62]-A_s[1551:1764,62])/np.sqrt(214)
    RRMSE_iterD[iter] = LA.norm(database2[1551:1764,73]-A_s[1551:1764,73])/np.sqrt(214)
    #print(RRMSE_iterA[iter],RRMSE_iterB[iter],RRMSE_iterC[iter],RRMSE_iterD[iter])

RRMSE_meanA = np.mean(RRMSE_iterA)
RRMSE_meanB = np.mean(RRMSE_iterB)
RRMSE_meanC = np.mean(RRMSE_iterC)
RRMSE_meanD = np.mean(RRMSE_iterD)

RRMSE_stdA = np.std(RRMSE_iterA)
RRMSE_stdB = np.std(RRMSE_iterB)
RRMSE_stdC = np.std(RRMSE_iterC)
RRMSE_stdD = np.std(RRMSE_iterD)

print('The mean error of alnus_bz2 is:',RRMSE_meanA)
print('The mean error of alnus_vi1 is:',RRMSE_meanB)
print('The mean error of gram_bz2 is:',RRMSE_meanC)
print('The mean error of gram_vi1 is:',RRMSE_meanD)

namefile = f'{path2}' + '/RRMSE.csv'
savetxt(namefile, [RRMSE_meanA,RRMSE_meanB,RRMSE_meanC,RRMSE_meanD,RRMSE_stdA,RRMSE_stdB,RRMSE_stdC,RRMSE_stdD], delimiter=',')

namefile = f'{path2}' + '/RRMSE_A.csv'
savetxt(namefile, RRMSE_iterA, delimiter=',')
namefile = f'{path2}' + '/RRMSE_B.csv'
savetxt(namefile,  RRMSE_iterB, delimiter=',')
namefile = f'{path2}' + '/RRMSE_C.csv'
savetxt(namefile,  RRMSE_iterC, delimiter=',')
namefile = f'{path2}' + '/RRMSE_D.csv'
savetxt(namefile, RRMSE_iterD, delimiter=',')



