# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.

# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
# --------------------------------------------------------
# References:
# DeiT: https://github.com/facebookresearch/deit
# BEiT: https://github.com/microsoft/unilm/tree/master/beit
# --------------------------------------------------------

# region Import libraries

import math
import sys
from typing import Iterable, Optional
import torch
import wandb
from timm.data import Mixup
from timm.utils import accuracy

import numpy as np

# endregion

# region Import local libraries

import util.misc as misc
import util.lr_sched as lr_sched

# endregion

def train_one_epoch(model: torch.nn.Module, criterion: torch.nn.Module,
                    data_loader: Iterable, optimizer: torch.optim.Optimizer,
                    device: torch.device, epoch: int, loss_scaler, max_norm: float = 0,
                    mixup_fn: Optional[Mixup] = None, log_writer=None,
                    args=None, regression_mode = False):
    model.train(True)
    metric_logger = misc.MetricLogger(delimiter="  ")
    metric_logger.add_meter('lr', misc.SmoothedValue(window_size=1, fmt='{value:.6f}'))
    header = 'Epoch: [{}]'.format(epoch)
    print_freq = 20

    accum_iter = args.accum_iter

    optimizer.zero_grad()

    if log_writer is not None:
        print('log_dir: {}'.format(log_writer.log_dir))

    for data_iter_step, (samples, targets) in enumerate(metric_logger.log_every(data_loader, print_freq, header)):

        # we use a per iteration (instead of per epoch) lr scheduler
        if data_iter_step % accum_iter == 0:
            lr_sched.adjust_learning_rate(optimizer, data_iter_step / len(data_loader) + epoch, args)

        samples = samples.to(device, non_blocking=True)

        # Case regression
        if type(targets) == list:
            targets[0] = targets[0].to(device, non_blocking=True)
            targets[1] = targets[1].to(device, non_blocking=True)

        # Case classification
        else:
            targets = targets.to(device, non_blocking=True)

        # Adoption of Mixup if activated (seems to worsen the performance in the MAE)
        if mixup_fn is not None:

            if regression_mode:

                print('Mixup computing...')

                # Mixup process for inputs and labels for regression tasks
                if mixup_fn.mixup_alpha > 0:
                    lambda_val = torch.distributions.Beta(mixup_fn.mixup_alpha, mixup_fn.mixup_alpha).sample()
                else:
                    lambda_val = 1

                batch_size = samples.shape[0]
                indices = torch.randperm(batch_size)  # Random permutation of the batch

                samples = lambda_val * samples + (1 - lambda_val) * samples[indices]
                targets = lambda_val * targets + (1 - lambda_val) * targets[indices]

            # Case regression
            if type(targets) == list:
                print('Mixup part of target list')
                samples, targets[1] = mixup_fn(samples, targets[1])

            # Case classification
            else:
                samples, targets = mixup_fn(samples, targets)

        loss = 0.0
        with torch.cuda.amp.autocast():

            loss_twobranch, outputs = model(samples, args.mask_ratio)

            # Case regression
            if type(targets) == list:

                if not('weights_classes' in args):

                    downstream_loss = args.lambda_weight * criterion(outputs, targets[1])

                else:
                    if len(args.weights_classes) == 0:

                        downstream_loss = args.lambda_weight * criterion(outputs, targets[1])

                    else:

                        input_weights = torch.from_numpy(np.array(args.weights_classes.copy(), dtype=np.float32))
                        input_weights = input_weights.to(device, non_blocking=True)

                        batch_weights = input_weights[targets[0]]

                        # batch_weights = batch_weights.to(device, non_blocking=True)

                        downstream_loss = args.lambda_weight * criterion(outputs, targets[1], batch_weights)

            # Case classification
            else:

                downstream_loss = args.lambda_weight * criterion(outputs, targets)

            loss_twobranch = (1-args.lambda_weight) * loss_twobranch
            loss = loss_twobranch + downstream_loss


        loss_value = loss.item()

        if not math.isfinite(loss_value):
            print("Loss is {}, stopping training".format(loss_value))
            sys.exit(1)

        loss /= accum_iter
        loss_scaler(loss, optimizer, clip_grad=max_norm,
                    parameters=model.parameters(), create_graph=False,
                    update_grad=(data_iter_step + 1) % accum_iter == 0)
        if (data_iter_step + 1) % accum_iter == 0:
            optimizer.zero_grad()

        torch.cuda.synchronize()

        metric_logger.update(training_loss=loss_value)
        metric_logger.update(mae_loss = loss_twobranch)
        metric_logger.update(downstream_loss = downstream_loss)
        min_lr = 10.
        max_lr = 0.
        for group in optimizer.param_groups:
            min_lr = min(min_lr, group["lr"])
            max_lr = max(max_lr, group["lr"])

        metric_logger.update(lr=max_lr)

        loss_value_reduce = misc.all_reduce_mean(loss_value)
        if log_writer is not None and (data_iter_step + 1) % accum_iter == 0:
            """ We use epoch_1000x as the x-axis in tensorboard.
            This calibrates different curves when batch size changes.
            """
            epoch_1000x = int((data_iter_step / len(data_loader) + epoch) * 1000)
            log_writer.add_scalar('loss', loss_value_reduce, epoch_1000x)
            log_writer.add_scalar('lr', max_lr, epoch_1000x)

    # gather the stats from all processes
    metric_logger.synchronize_between_processes()
    print("Averaged stats:", metric_logger)
    return {k: meter.global_avg for k, meter in metric_logger.meters.items()}


@torch.no_grad()
def evaluate(data_loader, model, device, regression_mode = False):

    if regression_mode:

        criterion = torch.nn.MSELoss()

    else:

        criterion = torch.nn.CrossEntropyLoss()

    metric_logger = misc.MetricLogger(delimiter="  ")
    header = 'Test:'

    # switch to evaluation mode
    model.eval()

    for batch in metric_logger.log_every(data_loader, 10, header):
        images = batch[0]

        if type(batch[-1]) == list:

            target = batch[-1][-1]
        else:
            target = batch[-1]

        images = images.to(device, non_blocking=True)
        target = target.to(device, non_blocking=True)

        # compute output
        with torch.cuda.amp.autocast():
            output = model.forward_test(images)
            loss = criterion(output, target)

        if not regression_mode:
            acc1, acc5 = accuracy(output, target, topk=(1, 5))

        batch_size = images.shape[0]
        metric_logger.update(testing_loss=loss.item())

        if not regression_mode:
            metric_logger.meters['acc1'].update(acc1.item(), n=batch_size)
            metric_logger.meters['acc5'].update(acc5.item(), n=batch_size)

        else:
            metric_logger.meters['mse'].update(loss.item(), n=batch_size)

    # gather the stats from all processes
    metric_logger.synchronize_between_processes()

    if not regression_mode:
        print('* Acc@1 {top1.global_avg:.3f} Acc@5 {top5.global_avg:.3f} loss {losses.global_avg:.3f}'
              .format(top1=metric_logger.acc1, top5=metric_logger.acc5, losses=metric_logger.testing_loss))
    else:
        print('* loss {losses.global_avg:.3f}'.format(losses=metric_logger.testing_loss))

    return {k: meter.global_avg for k, meter in metric_logger.meters.items()}
