# -*- coding: utf-8 -*-
"""
Created on Wed Apr 17 13:04:19 2024

@author: praji
"""


import matplotlib.pyplot as plt
import numpy as np
import time
import pysensors as ps
from mplcursors import cursor
import seaborn as sns
import pandas as pd
from pandas import DataFrame  
import scipy
from numpy import random
from keras.backend import sigmoid
from keras.layers import Activation
import h5py




# Setting seed

np.random.seed(12)


"""Reading the data """


""" Function to retrieve user choice for selecting the dataset """


def display_options_and_get_choice():
    options = [
        " 1: Laminar",
        " 2: Turbulent",
        " 3: Upload link"
        " 4: Exit"
    ]

    # Display the options
    for i, option in enumerate(options, start=1):
        print(f"{i}. {option}")

    # Get user input 
    while True:
        try:
            choice = int(input("Please enter the number of your choice: "))
            if 1 <= choice <= len(options):
                return choice
            else:
                print(f"Please enter a number between 1 and {len(options)}.")
        except ValueError:
            print("Invalid input. Please enter a valid number.")

user_choice = display_options_and_get_choice()

""" Function to perform lcsvd based on optimum sensors, equally spaced samples and data assimilation """


def display_options_and_get_choice1():
    options = [
        " 1: lcSVD-equispaced sample",
        " 2: lcSVD-optimum sensors",
        " 3: lcSVD-DA"
    ]

    # Display the options
    for i, option in enumerate(options, start=1):
        print(f"{i}. {option}")

    # Get user input 
    while True:
        try:
            choice = int(input("Please enter the number of your choice: "))
            if 1 <= choice <= len(options):
                return choice
            else:
                print(f"Please enter a number between 1 and {len(options)}.")
        except ValueError:
            print("Invalid input. Please enter a valid number.")

user_choice1 = display_options_and_get_choice1()

"""Function to process the laminar and turbulent dataset. Change the path in accordance with the file saved in your local system """


if user_choice==1:
    tensor_orig_temp = np.load('C:/Users/praji/OneDrive/Desktop/Spain/Encoding/combustion/work_directory/data.npy')
    data=np.array(tensor_orig_temp)
    unscaled_data=data   
    data=unscaled_data[:,:,:,-201:]
    nva,nxa,nya,nta=np.shape(data)
    components1 = ["$T$","$O$","$O_2$","$OH$","$H_2O$","$CH_4$","$CO$","$CO_2$","$C_2H_2$","$N_2$"]
    # swapping axes to change shape from (nv,nx,ny,nt) to (nt,ny,nx,nv)
    #data=np.swapaxes(data,3,0)                
    #data=np.swapaxes(data,1,2)
    key=0
    nv, ny, nx, nt = np.shape(data)
    print(f'No of timesteps: {nt}')
    print(f'No of points in grid (Y): {ny}')
    print(f'No of points in grid (X): {nx}')
    print(f'No of variables: {nv}')
    for i in range(nva):
        contour = plt.contourf(data[i, :, :, 100])
        colorbar = plt.colorbar(contour)
        plt.xlabel('X/D')
        plt.ylabel('Y/D')
        plt.xticks([])  
        plt.yticks([])  
        plt.show()

    data = np.swapaxes(data,0,3)
    data = np.swapaxes(data,1,2) 
    
elif user_choice==2:
    
    hf=h5py.File('C:/Users/praji/OneDrive/Desktop/Spain/Encoding/combustion/lcsvd/Data.h5', 'r')
    data0 = hf.get('Flow/Hot/u')
    data01 = hf.get('Flow/Hot/v')
    data0=np.array(data0[:,25:,25:105])
    data0=np.reshape(data0,(2000,84,80,1))
    data01=np.array(data01[:,25:,25:105])
    data01=np.reshape(data01,(2000,84,80,1))
    data_fin0 = np.concatenate([data0,data01],axis=3)  
    data=data_fin0
    nta,nxa,nya,nva=np.shape(data)
    components = ['Velocity(u)', 'Velocity(v)']
    key=1

    for i in range(nva):
        contour=plt.contourf(data[100,:,:,i])
        colorbar = plt.colorbar(contour)
        plt.xlabel('X/D')
        plt.ylabel('Y/D')
        plt.xticks([])  
        plt.yticks([])  
        plt.show()
    #data1=data_fin
    #data_fin0 = np.swapaxes(data_fin0,0,3)
    data_fin0=np.swapaxes(data_fin0,1,2)                
    print(np.shape(data_fin0))
    nt, ny, nx, nv = np.shape(data[:,:,:,:])
    print(f'No of timesteps: {nt}')
    print(f'No of points in grid (Y): {ny}')
    print(f'No of points in grid (X): {nx}')
    print(f'No of variables: {nv}')
    data=data_fin0[-401:,:,:,:]


elif user_choice==3:
    link=str(input("Please enter the link"))
    data= np.load(link)
    data=np.swapaxes(data,0,3)               

else:
    exit()


print(f"You chose: Option {user_choice}")

""" Function to perform different scaling based on user input """

def display_options_and_get_choice3():
    options = [
        " 1: Auto Scaling",
        " 2: Range Scaling",
        " 3: Pareto Scaling"
    ]

    # Display the options
    for i, option in enumerate(options, start=1):
        print(f"{i}. {option}")

    # Get user input 
    while True:
        try:
            choice = int(input("Please enter the number of your choice: "))
            if 1 <= choice <= len(options):
                return choice
            else:
                print(f"Please enter a number between 1 and {len(options)}.")
        except ValueError:
            print("Invalid input. Please enter a valid number.")

user_choice3 = display_options_and_get_choice3()

"""Function to choose the sensor size based on user input """


def get_sensor_size():
    # Display the prompt to enter the sensor (downsample) size
    print("Enter the sensor size (use default value 500) :")
    
    # Get user input and validate as a float
    while True:
        try:
            datapoints = int(input("Sensor (downsample) size: "))
            return datapoints
        except ValueError:
            print("Invalid input. ")

# Assign the sensor (downsample) size to `datapoints`
datapoint_s = get_sensor_size()
print("The sensor (downsample) size is:", datapoint_s)

"""Function to retain the percentage of modes based on user input """


def mode_percent():
    options = [
        " 1: 20 %",
        " 2: 50 %",
        " 3: 100 %"
    ]

    # Display the options
    for i, option in enumerate(options, start=1):
        print(f"{i}. {option}")

    # Get user input 
    while True:
        try:
            choice = int(input("Please enter the number of your choice: "))
            if 1 <= choice <= len(options):
                return choice
            else:
                print(f"Please enter a number between 1 and {len(options)}.")
        except ValueError:
            print("Invalid input. Please enter a valid number.")

user_choice4 = mode_percent()

if user_choice4==1:
    sam=5
elif user_choice4==2:
    sam=2
else:
    sam=1
                         
nt, ny, nx, nv = np.shape(data)




# Adding a minor noise to the original DNS dataset

data_noise=np.zeros((nt,ny,nx,nv))
for i in range(nt):
    for j in range(ny):
        for k in range(nx):
            for p in range(nv):
                data_noise[i,j,k,p]=data[i,j,k,p]+1e-12*random.rand()


""" Uncomment to use the DNS dataset with noise """

#data=data_noise

""" Reconstructing tensor after reshaping"""

Mat_orig = np.reshape(data,[nt,nv*nx*ny])
Mat_orig = np.transpose(Mat_orig)
Tensor_orig1 = np.reshape(Mat_orig,[nv,nx,ny,nt], order='F')



"""Centering and scaling (auto,range,pareto)"""

Tensor_orig = np.zeros(Tensor_orig1.shape)
Factor = np.zeros(data.shape[3])
Media = np.zeros(data.shape[3])
Media_tiempo = np.zeros(np.shape(Tensor_orig))

for iter in range(nt):
    Media_tiempo[:,:,:,iter] = np.mean(Tensor_orig1,axis=3)
    
Tensor_orig2 = Tensor_orig1-Media_tiempo

if user_choice3==1:
    
    for p in range(data.shape[3]):
        variable = Tensor_orig2[p,:,:,:]
        Factor[p] = np.std(variable) #Auto scaling
        Media[p] = np.mean(variable)
        Tensor_orig[p,:,:,:] = (variable-Media[p])/(Factor[p])
    
elif user_choice3==2:

    for p in range(data.shape[3]):
        variable = Tensor_orig2[p,:,:,:]
        min_val = np.min(variable)  # Minimum value
        max_val = np.max(variable)  # Maximum value
        Factor[p] = max_val - min_val  # Range
        Media[p] = np.mean(variable)
        Tensor_orig[p,:,:,:] = (variable-Media[p])/(Factor[p])
    
else:
    for p in range(data.shape[3]):
        variable = Tensor_orig2[p,:,:,:]
        Factor[p] = np.sqrt(np.std(variable)) #Pareto scaling
        Media[p] = np.mean(variable)
        Tensor_orig[p,:,:,:] = (variable-Media[p])/(Factor[p])
    

""" Plotting centered and scaled tensor"""

Mat_orig = np.reshape(Tensor_orig,[nv*nx*ny,nt],order='F')   


# Assigning centered and scaled tensor for further processing. dataset1_final is passed to the main function 
dataset1_final= Tensor_orig                            


# Define the length and width of domain (change for datasets)
lenx=0.05
leny=0.05

"""Functions for plotting errors """

def RRMSE (real, predicted):
  a = np.linalg.norm((real-predicted))
  b = np.linalg.norm(predicted)
  return(a/b)*100

def mean_absolute_percentage_error(y_true, y_pred):
    epsilon = 1e-10
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    return np.mean(np.abs((y_true - y_pred) / np.maximum(epsilon,np.abs(y_true)))) * 100

def smape(A, F):
    return ((100.0/len(A)) * np.sum(2 * np.abs(F - A) / (np.abs(A) + np.abs(F))+ np.finfo(float).eps))

""" Function to invert the centered and scaled tensor back to original """


def invert_tensor(temp0,temp1,temp2,temp7,fac,medi1,data_med):
    
    nv, nx, ny, nt = np.shape(temp0)
    for k in range(nv):    
        temp0[k,:,:,:]=temp0[k,:,:,:]*fac[k]+medi1[k]
        temp1[k,:,:,:]=temp1[k,:,:,:]*fac[k]+medi1[k]
        temp2[k,:,:,:]=temp2[k,:,:,:]*fac[k]+medi1[k]
        temp7[k,:,:,:]=temp7[k,:,:,:]*fac[k]+medi1[k]
    temp0=temp0+data_med
    temp1=temp1+data_med
    temp2=temp2+data_med
    temp7=temp7+data_med
    
    return temp0,temp1,temp2,temp7
    
""" Function to plot the modes(SVD vs lcSVD) """


def plot_modes_lcsvd(AML_mode_svd,AML_mode_lcsvd,Utr,Utr1,US_lcsvd,US_svd,V_svd,V_lcsvd):
    
    import numpy as np
           
    US_svd=np.swapaxes(US_svd,1,0)    
    #US_svd=US_svd/np.max(US_svd)            
    US_lcsvd=np.swapaxes(US_lcsvd,1,0) 
    #US_lcsvd=US_lcsvd/np.max(US_lcsvd)            


    # Calculate the RRMSE
    error_matrix = US_svd - US_lcsvd
    rrmse = np.sqrt(np.sum(error_matrix**2) / error_matrix.size) / np.sqrt(np.sum(US_svd**2) / US_svd.size)
    
    print("RRMSE:", rrmse)

    # change the list for the modes to plot

    mo=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19]
    if key==0:
        components = ["$T$", "$O$", "$O_2$", "$OH$", "$H_2O$", "$CH_4$", "$CO$", "$CO_2$", "$C_2H_2$", "$N_2$"]
    else:
        components = ['Velocity(u)', 'Velocity(v)']                

    for i in mo:
        p=0
        for j in range(len(components)):
            
            fig0, ax0 = plt.subplots(1, 3, figsize=(24, 8), width_ratios=[25,25,1])
            #plt.suptitle(f"2D POD Modes  | {components[j]}"+" (Mode :"+str(i+1)+")",fontsize=36)
            temp00=US_svd[i,:] 
            temp00=np.reshape(temp00,[nv,nx,ny,1], order='F')
            temp00=(temp00[p,:,:,0]*(Factor[p])+Media[p])+Media_tiempo[p,:,:,0]
            temp00=temp00/np.abs(temp00).max()
            if key==0:    
                temp00[temp00<0]=0
            else:
                temp00=temp00
            im1=ax0[0].contourf(temp00[:,:],label="SVD")
            #ax0[0].set_title("POD mode: " + str(i+1)+" (SVD)",fontsize = 32)
            ax0[0].set_xlabel("X/D",fontsize = 28)
            ax0[0].set_ylabel("Y/D",fontsize = 28)
            ax0[0].set_xticks([])              # Remove x-axis ticks
            ax0[0].set_yticks([])  
            #ax0[0].legend(loc='best',fontsize=22)
            temp01=US_lcsvd[i,:]
            temp01=np.reshape(temp01,[nv,nx,ny,1], order='F')
            temp01=(temp01[p,:,:,0]*(Factor[p])+Media[p])+Media_tiempo[p,:,:,0]
            temp01=temp01/np.abs(temp01).max()
            if key==0:    
                temp01[temp01<0]=0
            else:
                temp01=temp01
            im2=ax0[1].contourf(temp01[:,:],label="lcSVD")
            #ax0[1].set_title("POD mode: " + str(i+1)+" (lcSVD)",fontsize = 32)  
            #ax0[1].legend(loc='best',fontsize=22)
            ax0[1].set_xlabel("X/D",fontsize = 28)
            ax0[1].set_ylabel("Y/D",fontsize = 28)
            ax0[1].set_xticks([])              # Remove x-axis ticks
            ax0[1].set_yticks([])  
            ax0[2].set_xticks([])              # Remove x-axis ticks
            ax0[2].set_yticks([])  
            cbar=fig0.colorbar(im1, cax=ax0[2],ticks=[-1, -0.5, 0, 0.5, 1])
            cbar.ax.tick_params(labelsize=24)
            plt.tight_layout()
            plt.show()
            p=p+1
 
    for i in mo:
        p=0
        for j in range(len(components)):
            
            fig0, ax0 = plt.subplots(1, 4, figsize=(24, 6), width_ratios=[25,25,25,1])
            #plt.suptitle(f"2D POD Modes  | {components[j]}"+" (Mode :"+str(i+1)+")",fontsize=30)
            temp00=US_svd[i,:]
            temp00=np.reshape(temp00,[nv,nx,ny,1], order='F')
            temp00=(temp00[p,:,:,0]*(Factor[p])+Media[p])+Media_tiempo[p,:,:,0]
            if key==0:    
                temp00[temp00<0]=0
            else:
                temp00=temp00
                
            im1=ax0[0].contourf(temp00[:,:],label="SVD")
            #ax0[0].set_title("POD mode: " + str(i+1)+" (SVD)",fontsize = 26)
            ax0[0].set_xlabel("X/D",fontsize = 26)
            ax0[0].set_ylabel("Y/D",fontsize = 26)
            ax0[0].set_xticks([])              # Remove x-axis ticks
            ax0[0].set_yticks([])  
            #fig0.colorbar(im1, cax=ax0[1])

            #ax0[0].legend(loc='best',fontsize=22)
            temp01=US_lcsvd[i,:]
            temp01=np.reshape(temp01,[nv,nx,ny,1], order='F')
            temp01=(temp01[p,:,:,0]*(Factor[p])+Media[p])+Media_tiempo[p,:,:,0]
            if key==0:    
                temp01[temp01<0]=0
            else:
                temp01=temp01
            im2=ax0[1].contourf(temp01[:,:],label="lcSVD")
            #ax0[1].set_title("POD mode: " + str(i+1)+" (lcSVD)",fontsize = 26)  
            #ax0[1].legend(loc='best',fontsize=22)
            ax0[1].set_xlabel("X/D",fontsize = 26)
            ax0[1].set_ylabel("Y/D",fontsize = 26)
            ax0[1].set_xticks([])              # Remove x-axis ticks
            ax0[1].set_yticks([])  
            #fig0.colorbar(im2, cax=ax0[3])
            tem0=np.abs(temp01-temp00)
            im3=ax0[2].contourf(tem0[:,:],label="Error")
            #ax0[2].set_title("Error",fontsize = 26)  
            #ax0[1].legend(loc='best',fontsize=22)
            ax0[2].set_xlabel("X/D",fontsize = 26)
            ax0[2].set_ylabel("Y/D",fontsize = 26)
            ax0[2].set_xticks([])              # Remove x-axis ticks
            ax0[2].set_yticks([])  
            cbar=fig0.colorbar(im1, cax=ax0[3])
            cbar.ax.tick_params(labelsize=24)
            plt.tight_layout()
            plt.show()
            p=p+1


"""LcSVD functions"""

def lcsvd_sensors(Tensor, n_sensors, sel):

    def sensor_opt(Tensor0, n_sensors):

        shape = Tensor0.shape
        print(shape)

        if Tensor0.ndim == 3:
            Matrix = np.reshape(Tensor0, (np.prod(shape[:-1]), shape[-1]))

            mesh_size = shape[:-1]

        else:
            norm = np.linalg.norm(Tensor0.reshape(shape[0], np.prod(shape[1:])), axis = 0)

            norm = np.reshape(norm, (1, *shape[1:]))

            Matrix = np.reshape(norm, (np.prod(shape[1:-1]), shape[-1])) # Matrix loses 1 dimensions since there is now only 1 vel component (the norm)

            mesh_size = shape[1:-1]

        X_train = np.transpose(Matrix, (1, 0))

        n_samples, n_features = X_train.shape
        print('Number of samples:', n_samples)
        print('Number of possible sensors:', n_features)

        model = ps.SSPOR(basis = ps.basis.SVD(n_basis_modes = 50),n_sensors=n_sensors)

        model.fit(X_train,seed=10)
        sensors = model.get_selected_sensors() # Sensor positions refering to the flattened out spatial mesh

        sens = np.zeros(n_features)
        sens[sensors] = 1
        matrix = np.array(np.reshape(sens, mesh_size)) # Matrix for zeros shaped Nx, Ny which contains 1 in the sensor positions

        x = []
        y = []
        z = []

        if len(shape) == 3: # For 2D data with only 1 component (Nx, Ny, Nt)
            for i in range(shape[1]):
                for j in range(shape[0]):
                    if matrix[j, i] == 1:
                        x.append(i) # X coordinates of the sensors
                        y.append(j) # Y coordinates of the sensors

        elif len(shape) in [4, 5]: # 2D data with more than 1 component, and 3D data
            for i in range(shape[2]):
                for j in range(shape[1]):
                    if matrix.ndim == 2:
                        if matrix[j, i] == 1:
                            x.append(i) # X coordinates of the sensors
                            y.append(j) # Y coordinates of the sensors
                    elif matrix.ndim == 3:
                        for k in range(shape[3]):
                            if matrix[j, i, k] == 1:
                                x.append(i) # X coordinates of the sensors
                                y.append(j) # Y coordinates of the sensors
                                z.append(k) # Z coordinates of the sensors

        if matrix.shape == 2:
            z = None

        return sensors, x, y, z, matrix


    def SVD_sensorChecker(tensor, sensors, sel):

        shape = tensor.shape
        dims_prod = np.prod(shape[:-1])
        Tensor = np.reshape(tensor, (dims_prod, shape[-1])) # dims_prod is the compression of the spatial data, shape[-1] y the shape of the spatial data
        Ared = Tensor[sensors, :]

        Ured, Sred, Vred = np.linalg.svd(Ared, full_matrices = False)

        Sred = np.diag(Sred)
        Ured = Ured[:, :sel]
        Sred = Sred[:sel, :sel]
        Vred = Vred.conj().T
        Vred = Vred[:, :sel]

        Q, R = np.linalg.qr(Ured)
        Ured = Ured @ np.linalg.inv(R[:sel, :])
        Q1, R1 = np.linalg.qr(Vred)
        Vred = Vred @ np.linalg.inv(R1[:sel, :])

        ss = Ured.conj().T @ Ared @ Vred
        ss1 = np.sign(np.diag(np.diag(ss)))

        Vred = Vred @ ss1

        # Calculate the original SVD modes using the reduced modes
        U = (Tensor @ Vred) @ np.linalg.inv(Sred)
        V = (Tensor[sensors, :].conj().T @ Ured) @ np.linalg.inv(Sred)
        S = Sred

        TensorCheck = np.reshape((U @ S) @ V.conj().T, (shape))

        return TensorCheck

    RelativeErrorRMS = 1

    i = 1

    while RelativeErrorRMS * 100 > 99: # set the reconstruction tolerance

        print(f'Iteration number {i}')

        i += 1

        t0 = time.time()

        sensors, x, y, z, matrix = sensor_opt(Tensor, n_sensors)

        TensorCheck = SVD_sensorChecker(Tensor, sensors, sel)

        t1 = time.time()

        print(f'Optimal sensor low-cost SVD execution time: {(t1 - t0):.5f} seconds')

        Norm2V = np.linalg.norm(Tensor.flatten(), 2)
        diff = (Tensor - TensorCheck).flatten()
        Norm2diff = np.linalg.norm(diff, ord=2)
        RelativeErrorRMS = Norm2diff/Norm2V

        print(f'OS-lcSVD reconstruction error for the sensors combination: {(RelativeErrorRMS * 100):.5f}%')

    print(f'OS-lcSVD reconstruction error for the optimal sensors combination: {(RelativeErrorRMS * 100):.5f}%')

    if Tensor.ndim == 3:
        fig, ax = plt.subplots(1, 1, figsize = (10, 4))
        # plt.suptitle('Sensor positions')
        ax.contourf(Tensor[..., 0], alpha = 0.5)
        ax.scatter(x, y, color = 'k')
        ax.set_xlabel('X/D')
        ax.set_ylabel('Y/D')
        cursor(hover=True)
        plt.grid(True, color = 'grey')
        # ax.set_aspect('equal')
        ax.tick_params(which='both', colors=(0,0,0,0), size = 1)
        plt.tight_layout()
        plt.show()

    if Tensor.ndim == 4:
        comps = Tensor.shape[0]
        fig, ax = plt.subplots(1, comps, figsize = (12, 4), sharey = True)
        ax[0].set_ylabel('Y/D')
        ax[0].yaxis.set_label_coords(-0.025, .5)
        # plt.suptitle('Sensor positions')
        for col in range(comps):
            ax[col].contourf(Tensor[col, ..., 0], alpha = 0.5)
            ax[col].scatter(x, y, color = 'k')
            # ax[col].set_aspect('equal')
            ax[col].grid(True, color='grey')
            ax[col].set_xlabel('X/D')
            ax[col].xaxis.set_label_coords(.5, -.035)
            ax[col].tick_params(which='both', colors=(0,0,0,0), size = 1)

        cursor(hover=True)
        plt.tight_layout()
        plt.show()

    if Tensor.ndim == 5:
        comps = Tensor.ndim - 2
        fig, ax = plt.subplots(1, comps, figsize = (14, 4))
        ax[0].set_ylabel('Y/D')
        ax[0].yaxis.set_label_coords(-0.025, .5)
        ax[0].contourf(Tensor[0, ..., 0, 0], alpha = 0.5)
        ax[0].scatter(x, y, color = 'k')
        ax[0].set_xlabel('X/D')
        ax[0].grid(True, color='grey')
        ax[0].xaxis.set_label_coords(.5, -.035)
        ax[0].tick_params(which='both', colors=(0,0,0,0), size = 1)

        ax[1].set_ylabel('X/D')
        ax[1].yaxis.set_label_coords(-0.025, .5)
        ax[1].contourf(Tensor[2, 0, ..., 0], alpha = 0.5)
        ax[1].scatter(z, x, color = 'k')
        ax[1].set_xlabel('Z/D')
        ax[1].grid(True, color='grey')
        ax[1].xaxis.set_label_coords(.5, -.035)
        ax[1].tick_params(which='both', colors=(0,0,0,0), size = 1)

        ax[2].set_ylabel('Y/D')
        ax[2].yaxis.set_label_coords(-0.025, .5)
        ax[2].contourf(Tensor[2, :, 0, :, 0], alpha = 0.5)
        ax[2].scatter(z, y, color = 'k')
        ax[2].set_xlabel('Z/D')
        ax[2].grid(True, color='grey')
        ax[2].xaxis.set_label_coords(.5, -.035)
        ax[2].tick_params(which='both', colors=(0,0,0,0), size = 1)

        cursor(hover=True)
        plt.tight_layout()
        plt.show()

    return sensors, x, y, z, matrix

"""lcSVD for data assimilation (used as a separate function to add noise)"""

def LCSVD_DA(tensor,sensors, Time, sel,Media_tiempo1):
    print(f'High resolution data shape: {tensor.shape}') # This would be the data provided by a DNS, which is the Tensor dataset

    shape = tensor.shape
    dims_prod = np.prod(shape[:-1])
    Tensor = np.reshape(tensor,[nv*nx*ny,nt],order='F')
    

    # dims_prod is the compression of the spatial data, shape[-1] is the shape of the temporal data
    t0 = time.time()
    
    Ured1, Sred1, Vred1 = np.linalg.svd(Tensor, full_matrices = False)
    Stemp1=Sred1[:sel]
    Sred1 = np.diag(Sred1)
    Ured1 = Ured1[:, :sel]
    Sred1 = Sred1[:sel, :sel]
    Vred1 = Vred1.conj().T
    Vred1 = Vred1[:, :sel]

    Q3, R3 = np.linalg.qr(Ured1)
    Ured1 = Ured1 @ np.linalg.inv(R3[:sel, :])
    Q2, R2 = np.linalg.qr(Vred1)
    Vred1 = Vred1 @ np.linalg.inv(R2[:sel, :])

    ss2 = Ured1.conj().T @ Tensor @ Vred1
    ss3 = np.sign(np.diag(np.diag(ss2)))

    Vred1 = Vred1 @ ss3

    # Calculate the original SVD modes using the reduced modes
    U1 = (Tensor[:, :] @ Vred1) @ np.linalg.inv(Sred1)
    V1 = (Tensor[:, :].conj().T @ Ured1) @ np.linalg.inv(Sred1)
    S1 = Sred1

    TensorAprox1 = np.dot(U1,np.dot(S1,V1.T))
    TensorAprox1 = np.reshape(TensorAprox1,[nv,nx,ny,nt],order='F')

    t1 = time.time()
    
    print(f'SVD reconstruction completed in {(t1 - t0):.5f} seconds')

    
    Ared = Tensor[sensors, :]
    Ared = Ared[:, Time]
    
    """ Assigning Ared with experimental """
    
    #Ared=T_h
    n1,n2=np.shape(Ared)
    Ared_noise=np.zeros((n1,n2))

    # Adding noise to the downsampled matrix
    
    for i in range(n1):
        for j in range(nt):
            Ared_noise[i,j]=Ared[i,j]+0.1*random.rand()
    print(f'Low resolution data shape: {Ared.shape}') 

    T0 = time.time()
    
    if user_choice1==3:
        Ared=Ared_noise
    else:
        Ared=Ared

    # SVD applied to the reduced matrix
    Ured, Sred, Vred = np.linalg.svd(Ared_noise, full_matrices = False)
    Stemp=Sred[:sel]
    Sred = np.diag(Sred)
    Ured = Ured[:, :sel]
    Sred = Sred[:sel, :sel]
    Vred = Vred.conj().T
    Vred = Vred[:, :sel]

    Q, R = np.linalg.qr(Ured)
    Ured = Ured @ np.linalg.inv(R[:sel, :])
    Q1, R1 = np.linalg.qr(Vred)
    Vred = Vred @ np.linalg.inv(R1[:sel, :])

    ss = Ured.conj().T @ Ared @ Vred
    ss1 = np.sign(np.diag(np.diag(ss)))

    Vred = Vred @ ss1

    # Calculate the original SVD modes using the reduced modes

    U = (Tensor[:, Time] @ Vred) @ np.linalg.inv(Sred)
    Tensor_exp=np.copy(Tensor[sensors,:])
    if user_choice1==3:
        Tensor_exp=Ared_noise
    else:
        print("DNS tensor used for W and T") 
        Tensor_exp=Tensor[sensors,:]

        
    V = (Tensor[sensors,:].conj().T @ Ured) @ np.linalg.inv(Sred)
    S = Sred
    
    print(np.shape(V))
    print(np.shape(S))
    
    #TensorAprox = np.reshape((U @ S) @ V.conj().T, (shape))
    TensorAprox = np.dot(U,np.dot(S,V.T))
    TensorAprox = np.reshape(TensorAprox,[nv,nx,ny,nt],order='F')


    T1 = time.time()

    print(f'Low Cost SVD reconstruction completed in {(T1 - T0):.5f} seconds')

    
    np.save('lcSVD_tensor.npy',TensorAprox)

    print(f'Reconstructed data shape: {TensorAprox.shape}')
    AML_matrix= np.dot(S,V.T)
    US1=np.dot(U,S)
    test=np.dot(U,AML_matrix)
    test=np.reshape(test, (shape))
    print(AML_matrix.shape)
    
    
    AML_matrix1=np.dot(S1,V1.T)
    US2=np.dot(U1,S1)
    print(AML_matrix1.shape)

    # calling the invert_tensor function for inverting scaled matrix

    t_orig,t_svd,t_lcsvd,t_lcsvd1=invert_tensor(tensor,TensorAprox1,TensorAprox,test,Factor,Media,Media_tiempo)
    
    tensor=t_orig                                         # replace by t_orig when normalised else tensor
    TensorAprox2=t_svd                                    # replace by t_svd when normalised else TensorAprox1
    TensorAprox3=t_lcsvd                                  # replace by t_lcsvd when normalised else TensorAprox
    
    if key==0:
        TensorAprox2[TensorAprox2<0] = 0
        TensorAprox3[TensorAprox3<0] = 0
        
    else:
        print("negative values retained")
        
    Tensor0 = np.reshape(tensor, (dims_prod, shape[-1]))
    
    Norm2V = np.linalg.norm(Tensor0.flatten(), 2)
    diff = (tensor - TensorAprox2).flatten()
    diff1 = (tensor-TensorAprox3).flatten()
    Norm2diff = np.linalg.norm(diff, ord=2)
    Norm2diff1 = np.linalg.norm(diff1, ord=2)
    RelativeErrorRMS = Norm2diff/Norm2V
    RelativeErrorRMS1 = Norm2diff1/Norm2V
    print(f'Low Cost SVD reconstruction error: {(RelativeErrorRMS1 * 100):.5f}%')
    print(f'SVD reconstruction error: {(RelativeErrorRMS * 100):.5f}%')
    
    rrmse_svd=[]
    rrmse_lcsvd =[]
    co=[]
    c=0
    for j in range(nt):                                            # change nt to ntt or nvt
        rrmse_svd.append(RRMSE(tensor[:,:,:,j],TensorAprox2[:,:,:,j]))
        rrmse_lcsvd.append(RRMSE(tensor[:,:,:,j],TensorAprox3[:,:,:,j]))
        c=c+1
        co.append(c)

    rrmse1=np.array(rrmse_svd)
    rrmse2=np.array(rrmse_lcsvd)
    co=np.array(co)
    fig, ax = plt.subplots(figsize=(12,6))
    plt.plot(co,rrmse1,color='b',label='SVD')
    plt.plot(co,rrmse2,color='r',label='LCSVD')
    plt.title("RRMSE (SVD and LCSVD)")
    plt.xlabel("snapshots")
    plt.ylabel("RRMSE")
    plt.legend(loc='upper right')
    plt.show()
    fig, ax = plt.subplots(figsize=(12,6))
    plt.plot(np.arange(1, len(Stemp)+1, 1),Stemp/max(Stemp),'bs')  # 'bo' for blue circles
    plt.plot(np.arange(1, len(Stemp)+1, 1),Stemp1/max(Stemp1),'ro')  # 'ro' for red circles
    #plt.title("Singular values (SVD and lcSVD)")
    plt.xlabel("Singular value index",fontsize=22)
    plt.ylabel("Normalized Magnitude",fontsize=22)
    plt.tick_params(axis='x', labelsize=18)  # Set the font size for x-axis tick labels
    plt.tick_params(axis='y', labelsize=18) 
    #plt.xticks(np.arange(1, len(Stemp)+1, 1))  # Adjust as necessary
    
    #plt.legend(loc='upper right')
    plt.grid(True)
    plt.show()
    if key==0:
        components = ["$T$", "$O$", "$O_2$", "$OH$", "$H_2O$", "$CH_4$", "$CO$", "$CO_2$", "$C_2H_2$", "$N_2$"]
    else:
        components = ['Velocity(u)', 'Velocity(v)']
   
    if tensor.ndim == 3:
        fig, ax = plt.subplots(1, 3, figsize=(12, 4), width_ratios=[25, 25, 1])
        plt.suptitle(f'LCSVD reconstruction results')
        ax[0].contourf(TensorAprox[..., 0])
        ax[0].set_title('Reconstruction')
        # ax[0].set_aspect('equal')
        ima = ax[1].contourf(tensor[..., 0])
        ax[1].set_title('Ground Truth')
        ax[1].set_yticks([])
        # ax[1].set_aspect('equal')
        fig.colorbar(ima, cax=ax[2])
        plt.tight_layout()
        plt.show()

    if tensor.ndim == 4:
        for i in range(len(components)):
            fig, ax = plt.subplots(1, 6, figsize=(24, 4), width_ratios=[25,1,25,1,25, 1])
            plt.suptitle(f'Reconstruction results | {components[i]} ', fontsize=40)
            im1 = ax[0].contourf(TensorAprox3[i, :, :, 100],vmin=tensor[i, :, :, 100].min(),vmax=tensor[i, :, :, 100].max())
            ax[0].set_title('Reconstruction LCSVD',fontsize=32)
            fig.colorbar(im1, cax=ax[1])
            im2 = ax[2].contourf(TensorAprox2[i, :, :, 100],vmin=tensor[i, :, :, 100].min(),vmax=tensor[i, :, :, 100].max())
            ax[2].set_title('Reconstruction SVD',fontsize=32)
            # ax[0].set_aspect('equal')
            fig.colorbar(im2, cax=ax[3])
            im = ax[4].contourf(tensor[i, :, :, 100])
            ax[4].set_title('Ground Truth',fontsize=32)
            ax[4].set_yticks([])
            # ax[1].set_aspect('equal')
            cbar=fig.colorbar(im, cax=ax[5])
            cbar.ax.tick_params(labelsize=20)
            #fig.colorbar(im2, cax=ax[3])
            #fig.colorbar(im1, cax=ax[3])
            
            plt.tight_layout()
            plt.show()
         
        error1=np.abs(tensor-TensorAprox3)    
        for i in range(len(components)):
            fig, ax = plt.subplots(1, 4, figsize=(24, 6), width_ratios=[25,25,25, 1])
            #plt.suptitle(f'Reconstruction results | {components[i]} ', fontsize=40)
            im1 = ax[0].contourf(TensorAprox3[i, :, :, 100])#,vmin=tensor[i, :, :, 100].min(),vmax=tensor[i, :, :, 100].max())
            ax[0].set_title('Reconstruction LCSVD',fontsize=32)
            ax[0].set_xlabel('X', fontsize=26)
            ax[0].set_ylabel('Y', fontsize=26)
            ax[0].set_xticks([])              # Remove x-axis ticks
            ax[0].set_yticks([])  
            #fig.colorbar(im1, cax=ax[1])
            im2 = ax[1].contourf(tensor[i, :, :, 100])#,vmin=tensor[i, :, :, 100].min(),vmax=tensor[i, :, :, 100].max())
            ax[1].set_title('Ground Truth',fontsize=32)
            ax[1].set_xlabel('X', fontsize=26)
            ax[1].set_ylabel('Y', fontsize=26)
            ax[1].set_xticks([])              # Remove x-axis ticks
            ax[1].set_yticks([])  
            # ax[0].set_aspect('equal')
            #fig.colorbar(im2, cax=ax[2])
            im = ax[2].contourf(error1[i, :, :, 100])
            ax[2].set_title('Error',fontsize=32)
            ax[2].set_xlabel('X', fontsize=26)
            ax[2].set_ylabel('Y', fontsize=26)
            ax[2].set_xticks([])              # Remove x-axis ticks
            ax[2].set_yticks([])  
            # ax[1].set_aspect('equal')
            cbar=fig.colorbar(im2, cax=ax[3])
            cbar.ax.tick_params(labelsize=20)

            #fig.colorbar(im2, cax=ax[3])
            #fig.colorbar(im1, cax=ax[3])
            
            plt.tight_layout()
            plt.show()
            
        ## Change the dimension accordingly based on the sensor size. This is required to plot the downsampled matrix. eg if sensor size is 500 then the dim
        # that gives a downsampled contour is, for laminar 10 X 10 X 5 and for turbulent 2 X 25 X 10
         
        if user_choice==1:            
            Tensor_temp = np.reshape(Tensor_exp,[nv,10,5,nt],order='F') 
            Media_tiempo1=np.reshape(Media_tiempo1,[nv,10,5,Tensor.shape[-1]],order='F')

        elif user_choice==2:
            Tensor_temp = np.reshape(Tensor_exp,[nv,25,10,nt],order='F') 
            Media_tiempo1=np.reshape(Media_tiempo1,[nv,25,10,Tensor.shape[-1]],order='F')

    
        
        for i in range(len(components)):
            fig, ax = plt.subplots(1, 4, figsize=(24, 6), width_ratios=[25,25,25,1])
            #plt.suptitle(f'Reconstruction results | {components[i]} ', fontsize=40)
            im1 = ax[0].contourf(TensorAprox3[i, :, :, 100])#,vmin=tensor[i, :, :, 100].min(),vmax=tensor[i, :, :, 100].max())
            #ax[0].set_title('Reconstruction LCSVD',fontsize=32)
            ax[0].set_xlabel('X/D', fontsize=26)
            ax[0].set_ylabel('Y/D', fontsize=26)
            ax[0].set_xticks([])              # Remove x-axis ticks
            ax[0].set_yticks([])  
            #fig.colorbar(im1, cax=ax[1])
            im2 = ax[1].contourf(tensor[i, :, :, 100])#,vmin=tensor[i, :, :, 100].min(),vmax=tensor[i, :, :, 100].max())
            #ax[1].set_title('Ground Truth',fontsize=32)
            ax[1].set_xlabel('X/D', fontsize=26)
            ax[1].set_ylabel('Y/D', fontsize=26)
            ax[1].set_xticks([])              # Remove x-axis ticks
            ax[1].set_yticks([])  
            # ax[0].set_aspect('equal')
            #fig.colorbar(im2, cax=ax[2])
            im3 = ax[2].contourf((Tensor_temp[i, :, :, 100]*(Factor[i])+Media[i])+Media_tiempo1[i,:,:,100])#,vmin=tensor[i, :, :, 100].min(),vmax=tensor[i, :, :, 100].max())
            ax[2].set_xlabel('X/D', fontsize=26)
            ax[2].set_ylabel('Y/D', fontsize=26) 
            ax[2].set_xticks([])              # Remove x-axis ticks
            ax[2].set_yticks([])  
            # ax[1].set_aspect('equal')
            ax[3].set_xticks([])              # Remove x-axis ticks
            ax[3].set_yticks([])  
            cbar=fig.colorbar(im2, cax=ax[3])
            cbar.ax.tick_params(labelsize=20)
            #fig.colorbar(im2, cax=ax[3])
            #fig.colorbar(im1, cax=ax[3])      
            plt.tight_layout()
            plt.show()        

            

    if tensor.ndim == 5:
        comps = tensor.shape[0]
        nz = int(tensor.shape[3] / 2)
        plt.rc('figure', titlesize=20)
        for i in range(comps):
            fig, ax = plt.subplots(1, 3, figsize = (12, 4), width_ratios=[25, 25, 1])
            plt.suptitle(f'OS-lcSVD reconstruction results | {components[i]} velocity | XY Plane at Z = {nz}')
            ax[0].contourf(TensorAprox[i, :, :, nz, 0])
            ax[0].set_title('Reconstruction')
            # ax[0].set_aspect('equal')
            im = ax[1].contourf(tensor[i, :, :, nz, 0])
            ax[1].set_title('Ground Truth')
            ax[1].set_yticks([])
            # ax[1].set_aspect('equal')
            fig.colorbar(im, cax=ax[2])
            plt.tight_layout()
            plt.show()

    return TensorAprox,U,AML_matrix,AML_matrix1,tensor,U1,U,US1,US2,V1,V,TensorAprox3#,RelativeErrorRMS,RelativeErrorRMSU,RelativeErrorRMSST,RelativeErrorRMS
 

def plot_modes(AML_mode_l,AML_mode_nn,AML_mode_o,U_l,U_nn,U_o,US_l,US_nn,US_o,V_l,V_nn,V_o,ten_l,ten_nn,ten_o):
    
    mo=[0,1,4,9,19]
    
    for i in mo:
        nm,nt =np.shape(AML_mode_l)
        temp = AML_mode_l[i,:]
        temp1 =AML_mode_nn[i,:]
        temp2 =AML_mode_o[i,:]
        fig0, ax0 = plt.subplots(1, 3, figsize=(12, 4), width_ratios=[25,25,25])
        plt.suptitle("POD Modes (Temporal) |"+str(i+1),fontsize=44)
        ax0[0].plot(temp,'b',label="lcSVD")
        ax0[0].set_title("POD mode: " + str(i+1)+" (lcSVD)",fontsize = 22)
        ax0[0].set_xlabel("Snapshot Number",fontsize =20 )
        ax0[0].set_ylabel("POD Mode",fontsize = 20)
        ax0[0].legend(loc='best',fontsize=20)
        ax0[1].plot(temp1,'r',label="NN")
        ax0[1].set_title("POD mode: " + str(i+1)+" (NN)",fontsize = 22)  
        ax0[1].legend(loc='best',fontsize=20)
        ax0[1].set_xlabel("Snapshot Number",fontsize = 20)
        ax0[1].set_ylabel("POD Mode",fontsize = 20)
        ax0[2].plot(temp2,'r',label="Original")
        ax0[2].set_title("POD mode: " + str(i+1)+" (Original)",fontsize = 22)  
        ax0[2].legend(loc='best',fontsize=20)
        ax0[2].set_xlabel("Snapshot Number",fontsize = 20)
        ax0[2].set_ylabel("POD Mode",fontsize = 20)
        plt.tight_layout()
        plt.show()  
    
    U_l=np.swapaxes(U_l,1,0)
    U_nn=np.swapaxes(U_nn,1,0)    
    U_o=np.swapaxes(U_o,1,0)                            
    US_l=np.swapaxes(US_l,1,0)                
    US_nn=np.swapaxes(US_nn,1,0) 
    US_o=np.swapaxes(US_o,1,0) 

    
    mo=[0,1,2,3,4]
    components1 = ["$T$","$O$","$O_2$","$OH$","$H_2O$","$CH_4$","$CO$","$CO_2$","$C_2H_2$","$N_2$"]
    components = ['Velocity(u)', 'Velocity(v)']

    for i in mo:
        p=0
        for j in range(len(components1)):
            fig0, ax0 = plt.subplots(1, 3, figsize=(12, 4), width_ratios=[25,25,25])
            plt.suptitle(f"2D POD Modes  | {components[j]}"+" (Mode :"+str(i+1)+")",fontsize=36)
            temp00=US_l[i,:]
            temp00=np.reshape(temp00,[nv,nx,ny,1], order='F')
            #temp00=(temp00[p,:,:,0]*(Factor[p])+Media[p])+Media_tiempo[p,:,:,1]
            temp00[temp00<0]=0
            im1=ax0[0].contourf(temp00[j,:,:,0],label="lcSVD")
            ax0[0].set_title("POD mode: " + str(i+1)+" (lcSVD)",fontsize = 22)
            ax0[0].set_xlabel("U",fontsize = 20)
            ax0[0].set_ylabel("Magnitude",fontsize = 20)
            ax0[0].legend(loc='best',fontsize=20)
            temp01=US_nn[i,:]
            temp01=np.reshape(temp01,[nv,nx,ny,1], order='F')
            #temp01=(temp01[p,:,:,0]*(Factor[p])+Media[p])+Media_tiempo[p,:,:,1]
            temp01[temp01<0]=0
            im2=ax0[1].contourf(temp01[j,:,:,0],label="Autoencoder")
            ax0[1].set_title("POD mode: " + str(i+1)+" (NN)",fontsize = 22)  
            ax0[1].legend(loc='best',fontsize=20)
            ax0[1].set_xlabel("U",fontsize = 20)
            ax0[1].set_ylabel("Magnitude",fontsize = 20)
            temp02=US_o[i,:]
            temp02=np.reshape(temp02,[nv,nx,ny,1], order='F')
            #temp01=(temp01[p,:,:,0]*(Factor[p])+Media[p])+Media_tiempo[p,:,:,1]
            temp01[temp01<0]=0
            im2=ax0[2].contourf(temp02[j,:,:,0],label="Original")
            ax0[2].set_title("POD mode: " + str(i+1)+" (Original)",fontsize = 22)  
            ax0[2].legend(loc='best',fontsize=20)
            ax0[2].set_xlabel("U",fontsize = 20)
            ax0[2].set_ylabel("Magnitude",fontsize = 20)
            plt.tight_layout()
            plt.show()
            p=p+1
            
    mo=[0,1,2,3,4]
    components1 = ["$T$","$O$","$O_2$","$OH$","$H_2O$","$CH_4$","$CO$","$CO_2$","$C_2H_2$","$N_2$"]
               
    components = ['Velocity(u)', 'Velocity(v)']
             

 
    for i in mo:
        p=0
        for j in range(len(components)):
            
            fig0, ax0 = plt.subplots(1, 4, figsize=(24, 6), width_ratios=[25,1,25,1])
            plt.suptitle(f"Reconstruction and Error  | {components[j]}",fontsize=36)
            im1=ax0[0].contourf(np.abs(ten_l[j,:,:,100]-ten_o[j,:,:,100]))
            ax0[0].set_title("Reconstruction error: " + str(i+1)+" (lcSVD)",fontsize = 30)
            ax0[0].set_xlabel("X",fontsize = 28)
            ax0[0].set_ylabel("Y",fontsize = 28)
            fig0.colorbar(im1, cax=ax0[1])

            im2=ax0[2].contourf(np.abs(ten_nn[j,:,:,100]-ten_o[j,:,:,100]))
            ax0[2].set_title("Reconstruction error: " + str(i+1)+" (NN)",fontsize = 30)
            ax0[2].set_xlabel("X",fontsize = 28)
            ax0[2].set_ylabel("Y",fontsize = 28)
            fig0.colorbar(im2, cax=ax0[3])

            plt.tight_layout()
            plt.show()
            p=p+1

    for i in mo:
        p=0
        for j in range(len(components1)):
            
            fig0, ax0 = plt.subplots(1, 4, figsize=(24, 6), width_ratios=[25,1,25,1])
            plt.suptitle(f"Reconstruction and Error  | {components[j]}"+" (Mode :"+str(i+1)+")",fontsize=38)
            temp00 = US_o[i,:]
            temp00=np.reshape(temp00,[nv,nx,ny,1], order='F')
            temp00[temp00<0]=0

            temp01=US_l[i,:]
            temp01=np.reshape(temp01,[nv,nx,ny,1], order='F')
            #temp00=(temp00[p,:,:,0]*(Factor[p])+Media[p])+Media_tiempo[p,:,:,1]
            temp01[temp01<0]=0
            im1=ax0[0].contourf(np.abs(temp01[j,:,:,0]-temp00[j,:,:,0]),label="lcSVD")
            ax0[0].set_title("POD mode " + str(i+1)+"error (lcSVD)",fontsize = 32)
            ax0[0].set_xlabel("X",fontsize = 28)
            ax0[0].set_ylabel("Y",fontsize = 28)
            ax0[0].legend(loc='best',fontsize=22)
            fig0.colorbar(im1, cax=ax0[1])

            temp02=US_nn[i,:]
            temp02=np.reshape(temp02,[nv,nx,ny,1], order='F')
            temp02[temp02<0]=0
            im2=ax0[2].contourf(np.abs(temp02[j,:,:,0]-temp00[j,:,:,0]),label="Autoencoder")
            ax0[2].set_title("POD mode " + str(i+1)+" error (Autoencoder)",fontsize = 32)  
            ax0[2].legend(loc='best',fontsize=22)
            ax0[2].set_xlabel("X",fontsize = 28)
            ax0[2].set_ylabel("Y",fontsize = 28)
            fig0.colorbar(im2, cax=ax0[3])
            plt.tight_layout()
            plt.show()
            p=p+1        



def UQ(Tensor, Reconst, modes, points):
    import numpy as np
    import matplotlib.pyplot as plt
    
    tok=key
    plt.rc('axes', labelsize=18)
    plt.rc('axes', titlesize=18)
    plt.rc('legend', fontsize=18)
    plt.rc('figure', titlesize=20)
    plt.rc('xtick', labelsize=16)
    plt.rc('ytick', labelsize=16)

    Uinf = 1

    Tensor = Tensor / Uinf
    Reconst = Reconst / Uinf

    if Tensor.ndim == 3:
        nv = 1
    else:
        nv = Tensor.shape[0]



    # Epsilon Error (normalized)

    if tok==0:
        components = ["$T$", "$OH$", "$CH_4$",  "$CO_2$",  "$N_2$"]
        bi=10000
        colors = ['red', 'blue', 'green', 'black', 'black']
        indices = [0, 3, 5, 7, 9]


    else:
        components = ['Velocity(u)', 'Velocity(v)']
        bi=20
        colors = ['red', 'blue']
        indices = [0, 1]


    
    
    fig, ax = plt.subplots(figsize=(10, 6))
    
    
    # Loop over each component to plot histograms

    for idx, color, component in zip(indices, colors, components):
        eps = (Tensor[idx, ...] - Reconst[idx, ...]) / np.abs(Tensor[idx, ...] - Reconst[idx, ...]).max()
        sns.histplot(data=eps.flatten(), stat='probability', bins=bi, ax=ax, kde=False, fill=False, common_norm=False, element='poly', color=color, label=component)
    
    plt.xlabel('Error')
    plt.ylabel('Probability')
    plt.legend()
    # plt.title('Distribution of $\\epsilon$ for all components')
    
    # Adjust x-limits based on the value of 'tok'

    if tok == 0:
        plt.xlim([-0.005, 0.005])
    else:
        plt.xlim([-0.25, 0.25])
    
    plt.show()
    
def evaluate_rrmse(US_svd, US_lcsvd):
    if user_choice == 1:
        components1 = ["$T$", "$O$", "$O_2$", "$OH$", "$H_2O$", "$CH_4$", "$CO$", "$CO_2$", "$C_2H_2$", "$N_2$"]
    else:
        components1 = ['Velocity(u)', 'Velocity(v)']
    
    temp_mode = int(datapoint_s / sam)
    
    # Reshape US_svd and US_lcsvd into the appropriate shapes

    US_svd = np.reshape(US_svd, [nv, nx, ny, temp_mode], order='F')
    US_lcsvd = np.reshape(US_lcsvd, [nv, nx, ny, temp_mode], order='F')
    
    print("Shape of US_svd:", np.shape(US_svd))
    print("Shape of US_lcsvd:", np.shape(US_lcsvd))
    
    for j in range(len(components1)):
        print(f"Evaluating component: {components1[j]}")

        # Normalize using US_svd as the reference
        reference_max = max(np.abs(US_svd[j, :, :, :5]).max(),np.abs(US_lcsvd[j, :, :, :5]).max())
        US_svd1 = US_svd[j, :, :, :5] / reference_max
        US_lcsvd1 = US_lcsvd[j, :, :, :5] / reference_max
        
        US_svd2=US_svd1
        US_lcsvd2=US_lcsvd1

        
        # Take the absolute value of the modes for RRMSE comparison

        US_svd1 = np.abs(US_svd1)
        US_lcsvd1 = np.abs(US_lcsvd1)
        
        # Compute RRMSE

        tem = RRMSE(US_svd1, US_lcsvd1)
        print(f"RRMSE for {components1[j]}: {tem}")
        
        tem = RRMSE(US_svd2, US_lcsvd2)
        print(f"RRMSE_orig for {components1[j]}: {tem}")
    

""" Different sections to perform lcsvd (optimum sensors, equally spaced and data assimilation)"""

def section1(tensor3):

    tensor=tensor3
    mode_val=[sam]
    sensor_set=[datapoint_s]

    for j in mode_val:
        for i in sensor_set:
            Time_step = list(np.arange(0, tensor.shape[-1], 1))
            print(Time_step)
            modes = j
            points = i
            
            n_modes = int(points / modes)
            print(n_modes)
            Data_step = list(np.linspace(0, np.prod(tensor.shape[:-1]) - 1, points).astype(int))  # Selected data points 
            print(Data_step)
            if user_choice==1 or user_choice==2:
                Media_tiempo1 = np.reshape(Media_tiempo, (np.prod(Media_tiempo.shape[:-1]), Media_tiempo.shape[-1]))
                Media_tiempo1=Media_tiempo1[Data_step,:]
            TensorAprox, U_1,AML_mat_lcsvd,AML_mat_svd,tens,U_svd,U_lcsvd,US_lcsvd,US_svd,V_svd,V_lcsvd,T_hat= LCSVD_DA(tensor, Data_step, Time_step, n_modes,Media_tiempo1)
    plot_modes_lcsvd(AML_mat_svd, AML_mat_lcsvd,U_svd,U_lcsvd,US_lcsvd,US_svd,V_svd,V_lcsvd) 
    evaluate_rrmse(US_svd,US_lcsvd)
    UQ(tens, T_hat, f'{int(100 / modes)}% of 'r"$\bar J$", points)

def section2(tensor1):
    tensor = tensor1 
    mode_val=[sam]
    sensor_set=[datapoint_s]

    for j in mode_val:
        for i in sensor_set:
    
            n_sensors = i
            modes = j # This is the proportion of n_sensors from which the number of retained svd values is selected (1 = 100%, 5 = 20%, 2 = 50%, ...)
        
            n_modes = int(n_sensors / modes)

        
            sensors, x, y, z, matrix = lcsvd_sensors(tensor, n_sensors, n_modes)
            print(sensors)
            print(n_modes)
            if user_choice==1 or user_choice==2:
                Media_tiempo1 = np.reshape(Media_tiempo, (np.prod(Media_tiempo.shape[:-1]), Media_tiempo.shape[-1]))
                Media_tiempo1=Media_tiempo1[sensors,:]
        
            Time = list(np.arange(0, tensor.shape[-1], 1)) # To select certain snapshots (Every snapshot). Time can also be downsampled and reconstructed     
            TensorAprox, U_1,AML_mat_lcsvd,AML_mat_svd,tens,U_svd,U_lcsvd,US_lcsvd,US_svd,V_svd,V_lcsvd,T_hat = LCSVD_DA(tensor, sensors, Time, n_modes, Media_tiempo1)
      
    plot_modes_lcsvd(AML_mat_svd, AML_mat_lcsvd,U_svd,U_lcsvd,US_lcsvd,US_svd,V_svd,V_lcsvd) 
    evaluate_rrmse(US_svd,US_lcsvd)

    UQ(tens, T_hat, f'{int(100 / modes)}% of 'r"$\bar J$", n_sensors)

def section3(tensor3):

    tensor=tensor3
    mode_val=[sam]
    sensor_set=[datapoint_s]

    for j in mode_val:
        for i in sensor_set:
            Time_step = list(np.arange(0, tensor.shape[-1], 1))
            print(Time_step)
            modes = j
            points = i
            

            n_modes = int(points / modes)
            print(n_modes)
            Data_step = list(np.linspace(0, np.prod(tensor.shape[:-1]) - 1, points).astype(int))  # Selected data points 
            print(Data_step)
            if user_choice==1 or user_choice==2:
                Media_tiempo1 = np.reshape(Media_tiempo, (np.prod(Media_tiempo.shape[:-1]), Media_tiempo.shape[-1]))
                Media_tiempo1=Media_tiempo1[Data_step,:]
            TensorAprox, U_1,AML_mat_lcsvd,AML_mat_svd,tens,U_svd,U_lcsvd,US_lcsvd,US_svd,V_svd,V_lcsvd,T_hat= LCSVD_DA(tensor, Data_step, Time_step, n_modes,Media_tiempo1)

    plot_modes_lcsvd(AML_mat_svd, AML_mat_lcsvd,U_svd,U_lcsvd,US_lcsvd,US_svd,V_svd,V_lcsvd) 
    evaluate_rrmse(US_svd,US_lcsvd)
    UQ(tens, T_hat, f'{int(100 / modes)}% of 'r"$\bar J$", points)

# Main function to choose the lcsvd process based on user input.
    
def main():
    tensor = dataset1_final
    if user_choice1==1:
        section1(tensor)
    elif user_choice1==2:
        section2(tensor)
    else:
        section3(tensor)
            

if __name__ == '__main__':
    main()
