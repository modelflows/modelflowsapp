# Load dataset and preprocessing.

# region Import libraries
from sklearn import preprocessing
import os
from glob import glob

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import numpy as np
import PIL

import cv2

# endregion


# region Load dataset (with splitting data as input); case using as input the path root
def load_dataset_organized_sequences_different_sources(img_dirs, img_size=(256, 256), num_channels=1, label_encoder=None, depth_final_data = np.float32, excluded_classes = []):

    # First count the total number of samples in the set
    total_num_samples = 0

    # region Get the information about the test samples (filenames, class names, and labels)
    all_database_images_filenames = []
    all_database_images_class_names = []
    class_names = []
    output_label_encoder = None

    for img_dir_idx, img_dir in enumerate(img_dirs):

        database_images_directory = glob(os.path.join(img_dir, '*'))

        # Case if we have folders with the class names
        if os.path.isdir(database_images_directory[0]):

            database_as_directories = True

        if database_as_directories:

            print('Situation of samples with known classes')

            # Just in case
            database_images_directory.sort()

            for idx_class, database_class_name_fullpath in enumerate(database_images_directory):

                if not(os.path.basename(database_class_name_fullpath) in excluded_classes):

                    all_sequence_filenames_class = glob(os.path.join(database_class_name_fullpath, '*'))
                    all_sequence_filenames_class.sort()

                    if img_dir_idx == 0:

                        class_names = class_names + [os.path.basename(database_class_name_fullpath)]

                    for idx_sequence_class, sequence_filename_class in enumerate(all_sequence_filenames_class):

                        samples_sequence_class_filenames = glob(os.path.join(sequence_filename_class, '*'))
                        samples_sequence_class_filenames.sort()

                        all_database_images_filenames = all_database_images_filenames + samples_sequence_class_filenames

                        all_database_images_class_names = all_database_images_class_names + [
                            os.path.basename(database_class_name_fullpath)] * len(samples_sequence_class_filenames)

    total_num_samples = total_num_samples + len(all_database_images_filenames)

    print('Database with ' + str(total_num_samples) + ' samples and ' + str(len(database_images_directory)) + ' classes')

    if database_as_directories:

        if label_encoder is None:

            le = preprocessing.LabelEncoder()
            # Assume we have the same classes as in training, but if we do not have test samples in a certain class, the corresponding folder would be empty
            le.fit(all_database_images_class_names)

            all_database_images_class_labels = le.transform(all_database_images_class_names)

            output_label_encoder = le


        else:

            all_database_images_class_labels = label_encoder.transform(all_database_images_class_names)

            output_label_encoder = label_encoder

        print('Loading data...')


        for img_idx, img_path in enumerate(all_database_images_filenames):

            if '.npy' in img_path:

                if img_idx == 0:
                    print('Numpy format')

                image = np.load(img_path)

                if num_channels == 1:

                    # NOTE: THIS SEEMS TO WORK WITH OTHER AMPLITUDES OUT FROM 0-255
                    image = np.expand_dims(cv2.resize(image.astype(depth_final_data), img_size), axis=2)

                if num_channels == 3:

                    image = cv2.resize(image.astype(depth_final_data), img_size)

            else:

                if num_channels == 1:
                    image = np.expand_dims(np.array(PIL.ImageOps.grayscale(PIL.Image.open(img_path)).resize(img_size)),
                                           axis=2)

                if num_channels == 3:
                    image = np.array(PIL.Image.open(img_path).resize(img_size))

            if img_idx == 0:


                all_images = np.zeros((total_num_samples, img_size[0], img_size[1], num_channels),dtype=image.dtype)


            all_images[img_idx] = image

            if img_idx % 20 == 0:
                print('Number of loaded images: ' + str(img_idx))

        print('Data loaded!')


    # endregion

    return all_images, all_database_images_class_labels, all_database_images_filenames, all_database_images_class_names, class_names, output_label_encoder

# endregion


# region Data Augmentation module for default CNN and ViT for small datasets

def data_augmentation_pipeline(target_size):


    data_augmentation = keras.Sequential(
        [
            layers.Normalization(),
            layers.Resizing(target_size[0], target_size[1]),
            layers.RandomFlip("horizontal"),
            layers.RandomRotation(factor=0.02),
            layers.RandomZoom(height_factor=0.2, width_factor=0.2),
        ],
        name="data_augmentation",
    )


    return data_augmentation


# endregion