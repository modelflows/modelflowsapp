import matplotlib.pyplot as plt
import numpy as np

try:
    import seaborn as sns
except ImportError:
    import subprocess
    import sys
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'seaborn'])
    import seaborn as sns

import os
path0 = os.getcwd()

# Configure the plot appearance
plt.rc('axes', labelsize=23)
plt.rc('axes', titlesize=23)
plt.rc('legend', fontsize=35)
plt.rc('figure', titlesize=24)
plt.rc('xtick', labelsize=16)
plt.rc('ytick', labelsize=16)

def probDistFunc(ground_truth: np.ndarray, reconstruction: np.ndarray, save: bool = False, path: str = path0, filename: str = "PDF_plot") -> None:
    '''
    Plot the probability distribution functions for the reconstruction error between a ground truth and reconstructed
    tensor. Thought for velocity fields.

    Expected input shapes:
        - 3D tensor: [nx, ny, nt]
        - 4D tensor: [nv, nx, ny, nt]
        - 5D tensor: [nv, nx, ny, nz, nt]

    Args:
         - ground_truth: ground truth tensor.
         - reconstruction: reconstructed tensor
         - save: save figures or not. Default is False
         - path: path to save the plot. Default is current working directory
         - filename: filename for the saved plot. Default is "PDF_plot"
    '''

    # Calculate the reconstruction error (epsilon) for each component, scaled using the max absolute error
    if ground_truth.ndim <= 3:
        epsilon_U = (ground_truth - reconstruction) / np.abs(ground_truth - reconstruction).max()
    if ground_truth.ndim >= 4:
        nv = ground_truth.shape[0]
        epsilon_U = (ground_truth[0, ...] - reconstruction[0, ...]) / np.abs(ground_truth[0, ...] - reconstruction[0, ...]).max()
        epsilon_V = (ground_truth[1, ...] - reconstruction[1, ...]) / np.abs(ground_truth[1, ...] - reconstruction[1, ...]).max()
        if nv > 2:
            epsilon_W = (ground_truth[2, ...] - reconstruction[2, ...]) / np.abs(ground_truth[2, ...] - reconstruction[2, ...]).max()

    # Plot the probability distribution functions
    fig, ax = plt.subplots(figsize=(10, 10))  # Corrected here

    sns.histplot(data=epsilon_U.flatten(), stat='probability', bins=50, legend=True, ax=ax,
                 label=r'$\frac{\epsilon_u}{|\epsilon_{u, max}|}$', kde=False, fill=False,
                 common_norm=False, element='poly', color="red")

    if ground_truth.ndim > 3:
        sns.histplot(data=epsilon_V.flatten(), stat='probability', bins=50, legend=True, ax=ax,
                     label=r'$\frac{\epsilon_v}{|\epsilon_{v, max}|}$', kde=False, fill=False,
                     common_norm=False, element='poly', color="green")

        if nv > 2:
            sns.histplot(data=epsilon_W.flatten(), stat='probability', bins=50, legend=True, ax=ax,
                         label=r'$\frac{\epsilon_w}{|\epsilon_{w, max}|}$', kde=False, fill=False,
                         common_norm=False, element='poly', color="blue")

    ax.legend(loc='best')

    ax.set(xlabel=None, ylabel=None)

    ax.set_xlabel('Error', fontsize=30)
    ax.set_ylabel('Probability', fontsize=30)
    ax.tick_params(axis='both', which='major', labelsize=20)
    

    ax.vlines(0, ymin=0, ymax=0.82, colors="gray", alpha=0.8, lw=2, linestyles="dashed")
    
    ax.set_xlim(left=-0.80, right=0.80)

    plt.tight_layout()

    if save:
        plt.savefig(f'{path}/{filename}.png')

    plt.show()

    return

# Example of how to use the function probDistFunc
if __name__ == "__main__":
    # Generate random data for ground_truth and reconstruction
    nx, ny, nt = 50, 50, 10
    ground_truth = np.random.rand(nx, ny, nt)
    reconstruction = ground_truth + np.random.normal(0, 0.1, (nx, ny, nt))

    # Call the function to plot the probability distribution functions
    probDistFunc(ground_truth, reconstruction, save=False)

def uncertaintyEvol(ground_truth: np.ndarray, reconstruction_cases: list, cases: list, save: bool = False, path: str = '.') -> None:
    '''
    Plot the probability distribution functions for the reconstruction error between a ground truth and reconstructed
    tensor. Thought for velocity fields.

    Expected input shapes:
        - 3D tensor: [nx, ny, nt]
        - 4D tensor: [nv, nx, ny, nt]
        - 5D tensor: [nv, nx, ny, nz, nt]

    Args:
         - ground_truth: ground truth tensor.
         - reconstruction_cases: list containing different reconstructed tensors
         - cases: list of different cases, in the same order as the reconstruction_cases. (i.e. SVD modes, number of sensors, etc. -> [1, 2, 3, ...])
         - save: save figures or not. Default is False
         - path: path to save the plot. Default is current working directory
    '''
    epsU_list = []
    epsV_list = []
    epsW_list = []

    stdU_list = []
    stdV_list = []
    stdW_list = []

    nv = 1 if ground_truth.ndim == 3 else ground_truth.shape[0]

    # Calculate the reconstruction error (epsilon) for each component of each reconstruction case, scaled using the max absolute error
    for reconstruction in reconstruction_cases:
        if ground_truth.ndim == 3:
            epsilon_U = (ground_truth - reconstruction) / np.abs(ground_truth - reconstruction).max()
            epsU_list.append(epsilon_U)
        if ground_truth.ndim >= 4:
            epsilon_U = (ground_truth[0, ...] - reconstruction[0, ...]) / np.abs(ground_truth[0, ...] - reconstruction[0, ...]).max()
            epsU_list.append(epsilon_U)
            epsilon_V = (ground_truth[1, ...] - reconstruction[1, ...]) / np.abs(ground_truth[1, ...] - reconstruction[1, ...]).max()
            epsV_list.append(epsilon_V)
            if nv > 2:
                epsilon_W = (ground_truth[2, ...] - reconstruction[2, ...]) / np.abs(ground_truth[2, ...] - reconstruction[2, ...]).max()
                epsW_list.append(epsilon_W)

    # Calculate the uncertainty
    for i in range(len(reconstruction_cases)):
        if nv >= 1:
            stdU_list.append(np.std(epsU_list[i]) * 100)
        if nv >= 2:
            stdV_list.append(np.std(epsV_list[i]) * 100)
        if nv > 2:
            stdW_list.append(np.std(epsW_list[i]) * 100)

    fig, ax = plt.subplots(1, nv, figsize=(15, 7))

    if ground_truth.ndim <= 3:
        ax.set_title('Streamwise velocity')
        ax.set_ylabel(r'$\frac{\sigma_u}{|\epsilon_{u, max}|} \; \% $')
        ax.set_xlabel('Case')
        ax.plot(cases, stdU_list, marker='o')
    else:
        ax[0].set_title('Streamwise velocity')
        ax[0].set_ylabel(r'$\frac{\sigma_u}{|\epsilon_{u, max}|} \; \% $')
        ax[0].set_xlabel('Case')
        ax[0].plot(cases, stdU_list, marker='o')
        if nv >= 2:
            ax[1].set_title('Normal velocity')
            ax[1].set_ylabel(r'$\frac{\sigma_v}{|\epsilon_{v, max}|} \; \% $')
            ax[1].set_xlabel('Case')
            ax[1].plot(cases, stdV_list, marker='o')
        if nv > 2:
            ax[2].set_title('Spanwise velocity')
            ax[2].set_ylabel(r'$\frac{\sigma_w}{|\epsilon_{w, max}|} \; \% $')
            ax[2].set_xlabel('Case')
            ax[2].plot(cases, stdW_list, marker='o')

    plt.tight_layout()

    if save:
        plt.savefig(f'{path}/uncertainty_plot.png')

    plt.show()

    return

