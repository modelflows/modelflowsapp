# -*- coding: utf-8 -*-
"""
Demonstration of the EnKF method using the 2D Flow Past Cylinder system
"""

import matplotlib as mpl
mpl.use('Agg')
from h import h
from observation import Dh, h
from kalman import EnKF
from Reconstructor import superresolution
from add_noise import add_noise_to_tensor
from Downsampler import downsample_function
from MultiDimInterpolatorFunction import MDI
from UncertQuant import uncertaintyEvol, probDistFunc
from memory_profiler import profile, LogFile
from pointEvol import plot_velocity_evolution, find_original_coordinates

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.mlab as mlab
import sys
import hdf5storage  # now we can import this library
import os
import time
import imageio
import pickle

def main(j, n_points):

    print(n_points)
    filename = f'memory_profiler_{n_points}.dat'
    with open(filename, 'w') as fp:
        @profile(stream=fp)
        def inner_main():

# %% Application: 2D Flow Past Cylinder
# USING DATA ONLY

# %% DATA LOADING + TENSOR TO MATRIX

            start_time = time.time()
            
            path0 = os.getcwd()
            
            wantedfile = f'{path0}/Tensor_cylinder_Re100.mat'
            
            DA_time = []
            
            loop_DA = 1 #computations number of loop. Practical when comparing computational ressources
        
            for k in range(0,loop_DA):
                
                noise_level=0.05 #noise level applied to u_b and w
                
                cases = []
                
                ua_reconstruction_cases = []
                
                print("Computation number: ", k)
                
                Tensor = hdf5storage.loadmat(wantedfile)
                
                start_time = time.time()
            
                # extract tensor values as number
                Tensor = list(Tensor.values())[-1]
                Tensor = Tensor.swapaxes(1, 2)  # x and y coordinates were swapped
                Tensor = Tensor[:, :350, :, :151] # here I have limited the time snapshots due to memory constraints
                n_variables, nx, ny, nt = Tensor.shape
                print('Original dimensions:', n_variables, nx, ny, nt)
                n_variables_i, nx_i, ny_i, nt_i = n_variables, nx, ny, nt

                coeff = (j + 1)
                
                # ----------------------------------------------------------------------------------------
# %% DOWNSAMPLING
                
                # Don't call the downsampled tensor the same as the input HR tensor, since it will be overwritten
                
                # 'sensors' for pysensors and 'equi' for equidistant
                loaded_data_true, sx, sy, sz = downsample_function(Tensor, n_points, type='equi')
                
                # only 'equi' is available, n_points is a list with the number of datapoints per dimension:
                #                   downsample_function(Tensor, n_points = [40, 40], type = 'equi')
                
                # Info about each variable can be found in "Downsampler.py"
                
# %% time and dimensions of the domain
                
                n_variables, nx, ny, nt = loaded_data_true.shape
                print('New [reduced] dimensions:', n_variables, nx, ny, nt)
                
                tm = Tensor.shape[-1]  # final time 
                dt = tm/(nt-1)
                t = np.linspace(0, tm, nt)
                
                #length
                lx = 1 
                ly = 1
                #meshgrid
                x = np.linspace(0, lx, nx)
                xi = np.linspace(0, lx, nx_i)
                y = np.linspace(0, ly, ny)
                yi = np.linspace(0, ly, ny_i)
                X, Y = np.meshgrid(x, y, indexing='ij')
                Xi, Yi = np.meshgrid(xi, yi, indexing='ij')

# %% reshape data into 1D column vectors for each time snapshot

                data_reshaped = np.reshape(loaded_data_true, [n_variables*nx*ny, nt])
                n_state = data_reshaped.shape[0]  # dimension of state
                
                u0true = data_reshaped[:, 0].copy()  # True initial condition
                utrue = data_reshaped.copy()  # True data
                
# %% collect measurement data
                # here we use given true data to mimic observations
                # assume we measure the whole data field
        
                m = n_state  # dimension of measurement
                
                np.random.seed(seed=1)
                sig_m = 0.05 * np.mean(np.abs(u0true))  # standard deviation for measurement noise
                R = sig_m**2*np.eye(m)  # covariance matrix for measurement noise
                
                # here, I assume that measurements are collected every 1 second
 
                dt_m = 1  # time period between observations
                tm_m = Tensor.shape[-1]  # maximum time for observations
                nt_m = int(tm_m/dt_m)  # number of observation instants
                
                # the (time) indices for which observational data ara available
                ind_m = (np.linspace(int(dt_m/dt), int(tm_m/dt), nt_m)).astype(int)
                t_m = t[ind_m]  # the time instants for which observational data ara available
                
                
                #---------------------W with a fixed shape-------------------------------
                
                n_points_W = (10,22)
                
                utrueWi, sxw, syw, szw = downsample_function(Tensor, n_points_W, type='equi') #downsmapling w
                print("uWi", utrueWi)
                data_reshapedW = np.reshape(utrueWi, [n_variables*n_points_W[1]*n_points_W[0], nt_m])
                print("DRW", data_reshapedW)
                n_stateW = data_reshapedW.shape[0]  # dimension of state
                
                u0trueW = data_reshapedW[:, 0].copy()  # True initial condition
                utrueW = data_reshapedW.copy()

                w = np.zeros([440, Tensor.shape[-1]])  # Initialize w with the desired shape
                for km in range(nt_m):
                    time_index = ind_m[km]
                    w[:, km] = h(utrueW[:, time_index]) 
                w = add_noise_to_tensor(w, noise_level)
                print('w',w.shape)

# %% Data Assimilation
                print('Start DA initialise')
                # u0b should be our best guess for the initial condition
                # it can be the initial condition at coarse grid, some previous predictions, etc
                # here I assume u0b is equal to the true initial condition plus some random error to mimic the imperfection in simulation
                
                # we need to define the errors in initial condition/coarse simulation
                sig_b = 0.05 * np.mean(np.abs(u0true)) #5% de la moyenne des valeurs absolues de u0true
                # initialize the background error covariance matrix
                B = sig_b**2*np.eye(n_state)
                u0b = u0true + np.random.normal(0, sig_b, [n_state,])
                
                # time integration
                # array for (background) CFD predictions -- e.g., coarse solver that contains some errors
                ub = np.zeros([n_state, nt])
                ub[:, 0] = u0b.copy()
                # array for corrected predictions using data assimilation (CFD + measurements)
                ua = np.zeros([n_state, nt])
                # this is the best we know at time zero (assuming u0True is unknown)
                ua[:, 0] = u0b.copy()
                
                # ensemble size
                # start at small value (e.g., 5) and see if it is working, then increase gradually
                N = 25
                
                # initialize ensemble
                uai = np.zeros([n_state, N])  # ensemble of states for each time step
                for i in range(N):
                    uai[:, i] = u0b #+ np.random.normal(0, sig_b, size=(n_state,))
                uai = add_noise_to_tensor(uai, noise_level)
                
                    # % ASHTON-- mete estas dos opciones en un if (pues el CFD no tiene por q ser igual q la condicion inicial CFD de arriba)
                print('Start data assimilation')
                
                
                CFD_data = add_noise_to_tensor(Tensor, noise_level)
        
                
                km = 0
                for k in range(nt-1):
                    print(100+(k/nt-1)*100, '%')
                    # Forecast Step
                    # background trajectory [without correction] - for comparison
                    # the CFD solver should be called here to update values of ub
                    # For now, I will just assume that CFD prediction is equal to the true state plus some error (noise)
                    ub[:, k+1] = utrue[:, k+1].copy() #+ np.random.normal(0, sig_b, [n_state,])
                    ub = add_noise_to_tensor(ub, noise_level)
                    
                    samePoints = True  # Use the same points as the initial condition to downsample the CFD data (True/False)

                    # High res CFD data is called "CFD_data, and the downsampled version is called "downsampled_CFD"
                
                    CFDdims = ub.ndim
                    if samePoints == True:
                
                        if CFDdims == 3:
                            ub = ub[sy, ...].copy()
                            ub = ub[:, sx, ...].copy()
                
                        elif CFDdims == 4:
                            ub = ub[:, sy, ...].copy()
                            ub = ub[..., sx, :]
                
                        elif CFDdims == 5:
                            ub = ub[:, sy, ...].copy()
                            ub = ub[:, :, sx, ...]
                            ub = ub[..., sz, :]
                
                        ssx = sx
                        ssy = sy
                        ssz = sz
                
                    elif samePoints == False:
                        # Call the downsampling function
                        ub, ssx, ssy, ssz = downsample_function(
                            CFD_data, n_points=10, type='sensors')
                
                    # ----------------------------------------------------------------------------------------
                
                    # EnKF trajectory [with correction at observation times]
                    for i in range(N):  # forecast ensemble
                        # the CFD solver should be called here to update values of uai
                        # For now, I will just assume that CFD prediction is equal to the true state plus some error (noise)
                        uai[:, i] = utrue[:, k+1].copy() + np.random.normal(0,sig_b, size=(n_state,))
                    uai = add_noise_to_tensor(uai, noise_level)
                    # compute the mean of forecast ensemble
                    ua[:, k+1] = np.mean(uai, 1)
                    # compute forecast error covariance matrix
                    B = (1/(N-1)) * (uai - ua[:, k+1].reshape(-1, 1)
                                     ) @ (uai - ua[:, k+1].reshape(-1, 1)).T
                
                    # check if measurement is available at this time instant
                    if (km < nt_m) and (k+1 == ind_m[km]):
                        # Analysis Step
                        # correct predictions using EnKF
                        uai, B = EnKF(uai, w[:, km], h, Dh, R, B)
                        # compute the mean of analysis ensemble
                        ua[:, k+1] = np.mean(uai, 1)
                        km = km+1
                        
# %% reshape 1D vectors back to fields
                ua_field = ua.reshape([n_variables, nx, ny, nt])
                
                np.save('ua_field.npy', ua_field)
                np.save('ua.npy', ua)
                
#%% Coordinates saving
                
                coords = {'X': sx, 'Y': sy, 'Z': sz}
                
                with open('coordinates.pckl', 'wb') as handle:
                  pickle.dump(coords, handle, protocol = pickle.HIGHEST_PROTOCOL)
                
                # ----------------------------------------------------------------------------------------
#%% Reconstruct the DA
                # SVD superresolution is used to enhance the resolution of he under resolved datasets

                # Real data optimal positions: sx, sy, (sz). CFD data optimal: ssx, ssy, (ssz)

                print(Tensor.shape)
                print(loaded_data_true.shape)
                print(ua.shape)

                print('Computing DA recomstruction...')
                reconsMet = 'SuperRes' #SuperRes or MDI
                if reconsMet == "SuperRes":
                    
                    #SVD reconstruction
                    modes = int(n_variables*nx*ny*0.2)
                    print("Modes", modes)
                    ua_reconstruction, RRMSEua = superresolution(Tensor, ua_field, sx, sy, sz, modes)
                    print(ua_reconstruction.shape)
                    
                else: 
                    #MDI reconstruction
                    ua_reconstruction, RRMSEua = MDI(Tensor, ua_field)
                    print(ua_reconstruction.shape)
                
                ua_reconstruction_cases.append(ua_reconstruction)
                print(type(ua_reconstruction))
                
                print('ua_rec',ua_reconstruction_cases)
                print(type(ua_reconstruction_cases))
                
                # cases.append("{}".format(n_points))
                cases.append("{}".format(n_points))
                print(type(cases))
                
                
#%% DIRECTORY PLOT SAVE
                os.chdir(path0)
                
                # Chemin du répertoire MDI
                res_directory = str(reconsMet)
                
                # Chemin du répertoire n_points
                n_points_directory = os.path.join(res_directory, str(n_points))
                
                # Vérifier si le répertoire existe, sinon le créer
                if not os.path.exists(n_points_directory):
                    os.makedirs(n_points_directory)
                
                # Changer de répertoire
                os.chdir(n_points_directory)
                
                end_time = time.time()
                
                elapsed_time = end_time - start_time
                print("Computation time:", elapsed_time, "seconds")
                
                DA_time.append(elapsed_time)
                    
                
                    # ----------------------------------------------------------------------------------------
                time_lc_mean = np.round(sum(DA_time) / len(DA_time), 3)
# %% PLOTTING
                print('Creation of plots')

                # Save the reconstructed data for future use
                np.save('ua_reconstructed.npy', ua_reconstruction)
                
                # Reshape the data for plotting
                utrue_field = Tensor.reshape([n_variables_i, nx_i, ny_i, nt_i])
                CFD_field = CFD_data.reshape([n_variables_i, nx_i, ny_i, nt_i])
                print(CFD_field.shape)
                print(CFD_field[(1, 106, 22, 75)])
                w_field = w.reshape([n_variables, n_points_W[1], n_points_W[0], nt_m])  # w_const
                print(w_field.shape)
                print(w_field[(1, 5, 3, 2)])

                
                # Define coordinates of points to follow
                coordinates_W_X = [(5, 1), (5, 7), (8, 13)]  # w_const
                selected_points_X = find_original_coordinates(coordinates_W_X, Tensor.shape, w_field.shape)
                coordinates_W_Y = [(5, 1), (9, 8), (4, 13)]  # w_const
                selected_points_Y = find_original_coordinates(coordinates_W_Y, Tensor.shape, w_field.shape)
                
                # Create a figure with subplots
                fig, ax = plt.subplots(nrows=7, ncols=2, figsize=(25, 20), gridspec_kw={'height_ratios': [1, 1, 1, 0.05, 1, 0.05, 1]})
                
                cmap = 'viridis'
                frames = []
                
                # Adjust vertical space between subplots
                fig.subplots_adjust(hspace=1.0)
                
                # Plot data for specific time frames
                for wtime in range(0, 151, 50):
                    time_index = ind_m[wtime]
                    for i in range(2):
                        im = ax[0, i].contourf(utrue_field[i, :, :, time_index].T, cmap=cmap)
                        ax[1, i].contourf(CFD_field[i, :, :, time_index].T, cmap=cmap)
                        ax[2, i].contourf(ua_reconstruction[i, :, :, time_index].T, cmap=cmap)
                        
                        # Adjust colorbars to avoid overlap
                        fig.colorbar(im, cax=ax[3, i], orientation='horizontal')
                        
                        err = ax[4, i].contourf(abs(utrue_field[i, :, :, time_index] - ua_reconstruction[i, :, :, time_index]).T,
                                                cmap='plasma')
                        
                        fig.colorbar(err, cax=ax[5, i], orientation='horizontal', cmap='plasma')
                        
                        ax[6, i].contourf(w_field[i, :, :, wtime].T, cmap=cmap)
                
                        # Use mathtext for labels and titles
                        ax[0, i].set_title(r'True')
                        ax[1, i].set_title(r'HR CFD')
                        ax[2, i].set_title(r'Data Assimilation (ua) | RRMSE: ' + str(RRMSEua * 100) + r' %', weight='bold')
                        ax[4, i].set_title(r'Absolute error (ua - True)')
                        ax[6, i].set_title(r'W (experiments)')
                
                        fig.suptitle(r'Tensor cylinder Re100 | t =' + str(time_index) +
                                     r'| N_points =' + str(n_points) +
                                     r'| Computation time (mean of ' + str(loop_DA) +
                                     r' loops):' + str(time_lc_mean) + r'seconds',
                                     fontsize=30, y=1.05)
            
                    # Scatter selected points on the plots
                    for point in selected_points_X:
                        ax[0, 0].scatter(point[1], point[0], color='red', s=50, edgecolors='red')
                
                    for point in coordinates_W_X:
                        ax[6, 0].scatter(point[1], point[0], color='red', s=50, edgecolors='red')
                
                    for point in selected_points_Y:
                        ax[0, 1].scatter(point[1], point[0], color='red', s=50, edgecolors='red')
                
                    for point in coordinates_W_Y:
                        ax[6, 1].scatter(point[1], point[0], color='red', s=50, edgecolors='red')
                
                    # Set labels for the plots
                    for i in range(3):
                        for k in range(2):
                            ax[i, k].set_xlabel(r'x', fontsize=22)
                            ax[i, k].set_ylabel(r'y', fontsize=22)
                
                    # Use tight_layout to adjust subplot parameters
                    fig.tight_layout(rect=[0, 0.03, 1, 0.95])
                    
                    # Save and store frames for animation
                    plt.savefig('N' + str(n_points) + '_t=' + str(int(time_index)) + '.png', dpi=100, bbox_inches='tight')
                    image = imageio.v2.imread('N' + str(n_points) + '_t=' + str(int(time_index)) + '.png')
                    frames.append(image)
                
                # Change the directory if needed
                os.chdir('../../')
                
                snapshot = 0
                point1 = selected_points_X[1]
                point_reduced = coordinates_W_X[1]
                
                
                plot_velocity_evolution(utrue_field, CFD_field, w_field, ua_reconstruction, point1, point_reduced, snapshot, n_points)
                
                for p in range(0,len(selected_points_X)):
                    plot_velocity_evolution(utrue_field, CFD_field, w_field, ua_reconstruction, selected_points_X[p], coordinates_W_X[p], snapshot, n_points)
                    
                snapshot = 1
                for q in range(0,len(selected_points_Y)):
                    plot_velocity_evolution(utrue_field, CFD_field, w_field, ua_reconstruction, selected_points_Y[q], coordinates_W_Y[q], snapshot, n_points)
                    
                probDistFunc(Tensor, ua_reconstruction, save=True, filename=f'PDF_plot_{n_points}')
                
                absolute_error = np.mean(np.abs(utrue - ua))
                print("Absolute error:", absolute_error)
            
#%% SAVE TO .XLS FILE
                
            # Calculate dimensions
            dim_CFD = ub.size
            dim_experiment = ua.size
            SpeedUp = 0
            
            # Calculate compression factors
            comp_factor_CFD = dim_CFD / utrue_field.size
            comp_factor_experiment = w_field.size / utrue_field.size
            
            # Create a DataFrame
            data = {
                'Dimensions of CFD (ub)': [dim_CFD],
                'Dimensions of experiment (w)': [dim_experiment],
                'Computation Time': [time_lc_mean],
                'Speed Up' : [SpeedUp],
                'Compression factor CFD': [comp_factor_CFD],
                'Compression factor experiment': [comp_factor_experiment]
            }
            df = pd.DataFrame(data)
            
            # Save to Excel
            file_name = f'dimensions_and_compression_factors_{n_points}.xlsx'
            df.to_excel(file_name, index=False)
            
            # Create a DataFrame
            data = {
                'Noise': [noise_level],
                'Mean Error Epsilon': [absolute_error],
                'RRMSE': [RRMSEua],
                
            }
            df = pd.DataFrame(data)
            
            # Save to Excel
            file_name = f'error_{n_points}.xlsx'
            df.to_excel(file_name, index=False)
            
            np.save('ua_field_{}.npy'.format(n_points), ua_field)
            np.save('w_field_{}.npy'.format(n_points), w_field)
            np.save('CFD_field_{}.npy'.format(n_points), CFD_field)
            np.save('Tensor_{}.npy'.format(n_points), Tensor)
            np.save('ua_rec_cases_{}.npy'.format(n_points), ua_reconstruction_cases)
            np.save('cases_{}.npy'.format(n_points), cases)
            
                
            return Tensor, ua_reconstruction_cases, cases
        
        l_Tensor, ua_reconstruction_cases, cases = inner_main()
        
    return l_Tensor, ua_reconstruction_cases, cases

#%% LOOP PARAMETERS    
if __name__ == '__main__':
    ua_reconstruction_cases_list = []
    cases_list = []
    n_points = [(10,22), (20,40)] #number of downsampling points in y and x axis. I advise to put multiple combinaisons, in order to compare different results and select one of them.
    for j in range(len(n_points)):
       Tensor, ua_reconstruction_cases, cases = main(j, n_points[j])
       ua_reconstruction_cases_list.extend(ua_reconstruction_cases)
       cases_list.extend(cases)

    # Convert to numpy arrays if needed
    ua_reconstruction_cases_list_flat = np.array(ua_reconstruction_cases_list)
    cases_list_flat = np.array(cases_list)
    
    uncertaintyEvol(Tensor, ua_reconstruction_cases_list_flat, cases_list_flat, save=True)
    
    
 
    