import numpy as np
import matplotlib.pyplot as plt
import os

def find_original_coordinates(reduced_points, original_shape, reduced_shape):
    """
    Function to find the original coordinates in the high-resolution tensor given
    points in the downsampled tensor.
    
    Args:
        - reduced_points: list of tuples of indices in the reduced tensor [(x', y'), ...]
        - original_shape: shape of the high-resolution tensor (v, x, y, t)
        - reduced_shape: shape of the downsampled tensor (v, x', y', t')
    
    Returns:
        - original_points: list of tuples of indices in the original tensor [(x, y), ...]
    """
    # Unpack shapes, ignoring the first dimension (v) and possibly last dimension (t)
    v_orig, y_orig, x_orig, t_orig = original_shape
    v_red, y_red, x_red, t_red = reduced_shape
    
    # Calculate intervals
    x_interval = (x_orig - 1) / (x_red - 1)
    y_interval = (y_orig - 1) / (y_red - 1)

    original_points = []
    for reduced_point in reduced_points:
        # Unpack reduced point
        x_red_index, y_red_index = reduced_point
        
        # Find original indices
        x_orig_index = int(x_red_index * x_interval)
        y_orig_index = int(y_red_index * y_interval)
        
        original_points.append((x_orig_index, y_orig_index))
    
    return original_points

# Example usage
reduced_points = [(5, 1), (5, 7), (9, 13)]
original_shape = (2, 449, 199, 151)
reduced_shape = (2, 22, 10, 5)

original_coordinates = find_original_coordinates(reduced_points, original_shape, reduced_shape)
print("Original coordinates:", original_coordinates)


def plot_velocity_evolution(field_true, field_cfd, field_w, field_DA, point_index, point_reduced_index, velocity_component, DSpoints):
    """
    Plot the evolution of a specific velocity component at a specified point over time.

    Parameters:
        point_index (tuple): Indices of the point in the tensor, e.g., (i, j).
        point_reduced_index (tuple): Indices of the point in the reduced tensor, e.g., (i', j').
        velocity_component (int): Index of the velocity component (0 for x, 1 for y, etc.).
        DSpoints (int): Number of downsample points.
    """
    
    # Extract velocity data for the specified point and component
    velocity_at_point1 = field_true[velocity_component, point_index[1], point_index[0], :]
    velocity_at_point2 = field_cfd[velocity_component, point_index[1], point_index[0], :]
    velocity_at_point3 = field_w[velocity_component, point_reduced_index[1], point_reduced_index[0], :]
    velocity_at_point4 = field_DA[velocity_component, point_index[1], point_index[0], :]
    # print("W", field_w)
    # Extract time axis
    nt1 = velocity_at_point1.shape[0]
    time1 = np.arange(nt1)
    
    nt2 = velocity_at_point2.shape[0]
    time2 = np.arange(nt2)
    
    nt3 = velocity_at_point3.shape[0]
    time3 = np.arange(nt2)
    print(time3)
    
    nt4 = velocity_at_point4.shape[0]
    time4 = np.arange(nt4)
    

    # Plot the velocity evolution
    plt.figure(figsize=(8, 4))
    plt.plot(time1, velocity_at_point1, linestyle='-', color='blue', label=r'True ${}$'.format(velocity_component + 1))
    plt.plot(time2, velocity_at_point2, linestyle=':',linewidth=1.5, color='orange', label=r'CFD ${}$'.format(velocity_component + 1))
    plt.plot(time3, velocity_at_point3, linestyle='None', marker='x', markersize=2, color='green', label=r'W ${}$'.format(velocity_component + 1))
    plt.plot(time4, velocity_at_point4, linestyle='--', color='red', label=r'DA ${}$'.format(velocity_component + 1))
    
    # Add labels and title
    plt.xlabel(r'Time', fontsize=12)
    plt.ylabel(r'Velocity', fontsize=12)
    plt.title(r'Velocity Evolution at Point {} - Component snapshot {}'.format(point_index, velocity_component + 1), fontsize=14)
    
    # Adjust legend placement and appearance
    plt.legend(loc='best', fontsize=10, frameon=False)
    
    # Enable grid
    plt.grid(True, linestyle='--', alpha=0.7)
    
    # Set x-axis limits to start from 0 and extend to the last time point
    plt.xlim(0, nt1 - 1)
    
    # Save the figure with coordinates as filename
    filename = f"pointEvoVel/PointVelEvo_{point_index[0]}_{point_index[1]}_{velocity_component + 1}_{DSpoints}.png"
    plt.tight_layout()
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    plt.show()

# Example of using the function
# field_true, field_cfd, w, field_DA should be loaded from your data
# point_index = (80, 270)
# point_reduced_index = (5, 7)  # example reduced index
# velocity_component = 1  # for example, the second component
# plot_velocity_evolution(field_true, field_cfd, w, field_DA, point_index, point_reduced_index, velocity_component, DSpoints)
