import numpy as np
import matplotlib.pyplot as plt
import pysensors as ps

def downsample_function(Tensor, n_points, type = 'sensors'):
    """
    Function that downsamples a high resolution dataset
    Args:
        - Tensor: high resolution input dataset
        - points: number of data points used to form the under-resolved dataset
        - Time: number of snapshots selected to form the under-resolved dataset
        - type: type of downsampling (equi, sensors)
            + equi: equidistant data points are selected
            + sensors (default): pysensors is used to select the optimal data points (sensors)
    Returns:
        - tensor: under-resolved version of the input dataset
        - x: list with sensors / data position "x" coordinate values
        - y: list with sensors / data position "y" coordinate values
        - z: list with sensors / data position "z" coordinate values
    """

    def sensor_opt(Tensor0, n_sensors):

        shape = Tensor0.shape

        if Tensor0.ndim == 3:
            Matrix = np.reshape(Tensor0, (np.prod(shape[:-1]), shape[-1]))

            mesh_size = shape[:-1]

        else:
            norm = np.linalg.norm(Tensor0.reshape(shape[0], np.prod(shape[1:])), axis = 0)

            norm = np.reshape(norm, (1, *shape[1:]))

            Matrix = np.reshape(norm, (np.prod(shape[1:-1]), shape[-1])) 

            mesh_size = shape[1:-1]

        X_train = np.transpose(Matrix, (1, 0))

        n_samples, n_features = X_train.shape
        print('Number of samples:', n_samples)
        print('Number of possible sensors:', n_features)

        model = ps.SSPOR(basis = ps.basis.SVD(n_basis_modes = 2), n_sensors=n_sensors)

        model.fit(X_train)
        sensors = model.get_selected_sensors() # Sensor positions refering to the flattened out spatial mesh

        sens = np.zeros(n_features)
        sens[sensors] = 1
        matrix = np.array(np.reshape(sens, mesh_size)) # Matrix for zeros shaped Nx, Ny which contains 1 in the sensor positions

        x = []
        y = []
        z = []

        if len(shape) == 3: # For 2D data with only 1 component (Nx, Ny, Nt)
            for i in range(shape[1]):
                for j in range(shape[0]):
                    if matrix[j, i] == 1:
                        x.append(i) # X coordinates of the sensors
                        y.append(j) # Y coordinates of the sensors

        elif len(shape) in [4, 5]: # 2D data with more than 1 component, and 3D data
            for i in range(shape[2]):
                for j in range(shape[1]):
                    if matrix.ndim == 2:
                        if matrix[j, i] == 1:
                            x.append(i) # X coordinates of the sensors
                            y.append(j) # Y coordinates of the sensors
                    elif matrix.ndim == 3:
                        for k in range(shape[3]):
                            if matrix[j, i, k] == 1:
                                x.append(i) # X coordinates of the sensors
                                y.append(j) # Y coordinates of the sensors
                                z.append(k) # Z coordinates of the sensors

        if matrix.shape == 2:
            z = None

        return sensors, x, y, z
    
    dims = Tensor.ndim
    shape = Tensor.shape
    
    if type == 'equi':
        if dims == 3:
            nx, ny = n_points
            y = list(np.linspace(0, np.prod(Tensor.shape[0]) - 1, ny).astype(int))
            x = list(np.linspace(0, np.prod(Tensor.shape[1]) - 1, nx).astype(int))
            z = None
        elif dims == 4:
            nx, ny = n_points
            y = list(np.linspace(0, np.prod(Tensor.shape[1]) - 1, ny).astype(int))
            x = list(np.linspace(0, np.prod(Tensor.shape[2]) - 1, nx).astype(int))
            z = None
        elif dims == 5:
            nx, ny, nz = n_points
            y = list(np.linspace(0, np.prod(Tensor.shape[1]) - 1, ny).astype(int))
            x = list(np.linspace(0, np.prod(Tensor.shape[2]) - 1, nx).astype(int))
            z = list(np.linspace(0, np.prod(Tensor.shape[3]) - 1, nz).astype(int))

    
    elif type == 'sensors':
        sensors, x, y, z = sensor_opt(Tensor, n_points)

    if dims == 3:
        tensor = Tensor[y, ...].copy()
        tensor = tensor[:, x, ...].copy()

    elif dims == 4:
        tensor = Tensor[:, y, ...].copy()
        tensor = tensor[..., x, :]

    elif dims == 5:
        tensor = Tensor[:, y, ...].copy()
        tensor = tensor[:, :, x, ...]
        tensor = tensor[..., z, :]

    # Note: Tensor is hi-res and tensor is low-res, hence the upper or lower case "t"

    return tensor, x, y, z