import numpy as np 
import hdf5storage
import matplotlib.pyplot as plt
import os
import pickle

#! pip install pykrige 

from pykrige.ok3d import OrdinaryKriging3D # Lo dejo por si lo implemento con los tensores de 4to orden
from pykrige.uk3d import UniversalKriging3D

from scipy.interpolate import RegularGridInterpolator, CloughTocher2DInterpolator, LinearNDInterpolator


def MDI(Tensor, Downsampled):

    # Downsampled = Tensor[:, ::8, ...].copy()
    # Downsampled = Downsampled[:, :, ::8, ...]
    
    # IMPORTANT: Can't downsample Z since that means there are slices with no data.
    
    Tsr = np.full(Tensor.shape, np.nan)
    
    DSshape = Downsampled.shape
    
    TenShape = Tensor.shape
    
    dy, dx = DSshape[1], DSshape[2]
    
    y, x = TenShape[1], TenShape[2]
    
    dY_coords = np.linspace(0, dy - 1, dy).astype(int)
    dX_coords = np.linspace(0, dx - 1, dx).astype(int)
    # Y_coords = np.linspace(0, y - 1, dy).astype(int)
    # X_coords = np.linspace(0, x - 1, dx).astype(int)
    # In this case, we aren't evenly distributing the data, because you have SSX, SSY and SSZ
    
    with open('coordinates.pckl', 'rb') as pckl:
        coordinates = pickle.load(pckl)
    
    # Accéder aux valeurs pour la clé 'Y'
    Y_coords = coordinates['Y']
    
    # Accéder aux valeurs pour la clé 'X'
    X_coords = coordinates['X']
    
    
    if Tensor.ndim == 4:
        nv, ny, nx, nt = Tensor.shape
    
    if Tensor.ndim > 4:
        nv, ny, nx, nz, nt = Tensor.shape
        dz, z = DSshape[3], TenShape[3]
        dZ_coords = np.linspace(0, dz - 1, dz).astype(int)
        # Z_coords = np.linspace(0, z - 1, dz).astype(int)
        Z_coords = coordinates('Z')
    
    for i in range(len(dY_coords)):
        for j in range(len(dX_coords)):
            if Tensor.ndim == 4:
                Tsr[:, Y_coords[i], X_coords[j], :] = Downsampled[:, dY_coords[i], dX_coords[j], :]
            elif Tensor.ndim == 5:
                for k in range(len(dZ_coords)):
                    Tsr[:, Y_coords[i], X_coords[j], Z_coords[k], :] = Downsampled[:, dY_coords[i], dX_coords[j], dZ_coords[k], :]
    
    X_grid1, Y_grid1 = np.meshgrid(np.arange(ny), np.arange(nx), indexing='ij')
    
    if Tensor.ndim > 4:
        Y_grid2, Z_grid2 = np.meshgrid(np.arange(ny), np.arange(nz), indexing='ij')
        X_grid3, Z_grid3 = np.meshgrid(np.arange(nx), np.arange(nz), indexing='ij')
    
    interp_tsr = Tsr.copy()
    
    M = sum(np.isnan(interp_tsr.flatten()))
    
    print(f'Downsampled dataset shape: {Downsampled.shape}')
    print(f'High resolution dataset shape: {Tsr.shape}')
    print(f'Number of data points to complete: {M}')
    
    if Tensor.ndim == 5:
        fig, ax = plt.subplots(3, 2, figsize = (10, 5))
        ax[0, 0].contourf(Downsampled[0, ...,32, 0])
        ax[1, 0].contourf(Downsampled[1, ...,32, 0])
        ax[2, 0].contourf(Downsampled[2, ..., 32, 0])
        ax[0, 1].imshow(Tsr[0, ..., 32, 0])
        ax[1, 1].imshow(Tsr[1, ..., 32, 0])
        ax[2, 1].imshow(Tsr[2, ..., 32, 0])
        ax[0, 0].set_title('Downsampled data')
        ax[0, 1].set_title('Pre-processed data')
    
    elif Tensor.ndim == 4:
        fig, ax = plt.subplots(2, 2, figsize = (10, 5))
        ax[0, 0].contourf(Downsampled[0, ..., 0])
        ax[1, 0].contourf(Downsampled[1, ..., 0])
        ax[0, 1].imshow(Tsr[0, ..., 0])
        ax[1, 1].imshow(Tsr[1, ..., 0])
        ax[0, 0].set_title('Downsampled data')
        ax[0, 1].set_title('Pre-processed data')
    
    plt.tight_layout()
    plt.show()
    
    import time
    
    T0 = time.time()
    
    if Tensor.ndim == 4:
        for i in range(nv):
            for j in range(nt):
                # XY PLANE
                Tsr_copyXY = Tsr[i, ..., j].copy()
    
                if np.isnan(Tsr_copyXY).any():
                    non_nan_coordsXY = np.argwhere(~np.isnan(Tsr_copyXY))
                    nan_coordsXY = np.argwhere(np.isnan(Tsr_copyXY))
    
                    non_nan_valuesXY = Tsr_copyXY[~np.isnan(Tsr_copyXY)]
    
                    interpXY = LinearNDInterpolator(list(zip(non_nan_coordsXY[:, 0], non_nan_coordsXY[:, 1])), non_nan_valuesXY, fill_value = non_nan_valuesXY.mean())
    
                    interpolated_dataXY = interpXY(X_grid1, Y_grid1)
                    """
                    for k in range(Tensor.shape[1]):
                        for l in range(Tensor.shape[2]):
                            if np.isnan(Tsr_copyXY[k, l]):
                                interpolated_valueXY = interpXY((k, l)) 
                                interp_tsr[i, k, l, n, j] = interpolated_valueXY
                    """
                    interp_tsr[i, ..., j] = interpolated_dataXY
    
                if nt <= 500:
                    if j % 10 == 0:
                        print(f'vel: {i+1} - snap: {j}')
                else:
                    if j % 100 == 0:
                        print(f'vel: {i+1} - snap: {j}')
    
    elif Tensor.ndim > 4:
        for i in range(nv):
            for j in range(nt):
    
                # XY PLANE
                for n in range(nz):
                    Tsr_copyXY = Tsr[i, ..., n, j].copy()
    
                    if np.isnan(Tsr_copyXY).any():
                        non_nan_coordsXY = np.argwhere(~np.isnan(Tsr_copyXY))
                        nan_coordsXY = np.argwhere(np.isnan(Tsr_copyXY))
    
                        non_nan_valuesXY = Tsr_copyXY[~np.isnan(Tsr_copyXY)]
    
                        interpXY = LinearNDInterpolator(list(zip(non_nan_coordsXY[:, 0], non_nan_coordsXY[:, 1])), non_nan_valuesXY, fill_value = non_nan_valuesXY.mean())
    
                        interpolated_dataXY = interpXY(X_grid1, Y_grid1)
                        """
                        for k in range(Tensor.shape[1]):
                            for l in range(Tensor.shape[2]):
                                if np.isnan(Tsr_copyXY[k, l]):
                                    interpolated_valueXY = interpXY((k, l)) 
                                    interp_tsr[i, k, l, n, j] = interpolated_valueXY
                        """
                        interp_tsr[i, ..., n, j] = interpolated_dataXY
    
                # YZ PLANE
                for m in range(nx):
                    Tsr_copyYZ = interp_tsr[i, :, m, :, j].copy()
    
                    if np.isnan(Tsr_copyYZ).any():
    
                        non_nan_coordsYZ = np.argwhere(~np.isnan(Tsr_copyYZ))
                        nan_coordsYZ = np.argwhere(np.isnan(Tsr_copyYZ))
    
                        non_nan_valuesYZ = Tsr_copyYZ[~np.isnan(Tsr_copyYZ)]
    
                        interpYZ = LinearNDInterpolator(list(zip(non_nan_coordsYZ[:, 0], non_nan_coordsYZ[:, 1])), non_nan_valuesYZ, fill_value = non_nan_valuesYZ.mean())
    
                        interpolated_dataYZ = interpYZ(Y_grid2, Z_grid2)
                        """
                        for k in range(Tensor.shape[1]):
                            for l in range(Tensor.shape[3]):
                                if np.isnan(Tsr_copyYZ[k, l]):
                                    interpolated_valueYZ = interpYZ((k, l)) 
                                    interp_tsr[i, k, m, l, j] = interpolated_valueYZ
                        """
                        interp_tsr[i, :, m, :, j] = interpolated_dataYZ        
    
                # XZ PLANE
                for d in range(ny):
                    Tsr_copyXZ = interp_tsr[i, d, ..., j].copy()
    
                    if np.isnan(Tsr_copyXZ).any():
    
                        non_nan_coordsXZ = np.argwhere(~np.isnan(Tsr_copyXZ))
                        nan_coordsXZ = np.argwhere(np.isnan(Tsr_copyXZ))
    
                        non_nan_valuesXZ = Tsr_copyXZ[~np.isnan(Tsr_copyXZ)]
    
                        interpXZ = LinearNDInterpolator(list(zip(non_nan_coordsXZ[:, 0], non_nan_coordsXZ[:, 1])), non_nan_valuesXZ, fill_value = non_nan_valuesXZ.mean())
    
                        interpolated_dataXZ = interpXZ(X_grid3, Z_grid3)
                        """
                        for k in range(Tensor.shape[2]):
                            for l in range(Tensor.shape[3]):
                                if np.isnan(Tsr_copyXZ[k, l]):
                                    interpolated_valueXZ = interpXZ((k, l)) 
                                    interp_tsr[i, d, k, l, j] = interpolated_valueXZ
                        """
                        interp_tsr[i, d, ..., j] = interpolated_dataXZ
    
                if nt <= 500:
                    if j % 10 == 0:
                        print(f'vel: {i+1} - snap: {j}')
                else:
                    if j % 100 == 0:
                        print(f'vel: {i+1} - snap: {j}')
    
    T1 = time.time()
    
    I = sum(np.isnan(interp_tsr.flatten()))
    print(f'Remaining NaN points: {I}')
    
    fig, ax = plt.subplots(nv, 3, figsize = (10, 10))
    
    components = []
    plane = []
    #max_error:
    if Tensor.ndim == 4:
        for i in range(nv):
            error = Tensor[i, ...] - interp_tsr[i, ...]
            error_coord = np.argmax(error)
            error_coords = np.unravel_index(error_coord,  error.shape)
            components.append(error_coords[-1])
    
    if Tensor.ndim == 5:
        for i in range(nv):
            error = Tensor[i, ...] - interp_tsr[i, ...]
            error_coord = np.argmax(error)
            error_coords = np.unravel_index(error_coord,  error.shape)
            components.append(error_coords[-1])
            plane.append(error_coords[-2])
    print(nv)
    print(components)
    for i in range(nv):
        if Tensor.ndim == 4:
            ax[i, 0].contourf(Tensor[i, ..., components[i]])
            ax[i, 1].contourf(interp_tsr[i, ..., components[i]])
            ax[i, 2].contourf(Tensor[i, ..., components[i]] - interp_tsr[i, ..., components[i]])
    
            plt.colorbar(ax[i, 0].contourf(Tensor[i, ..., components[i]]), ax = ax[i, 1])
            plt.colorbar(ax[i, 2].contourf(Tensor[i, ..., components[i]] - interp_tsr[i, ..., components[i]]), ax = ax[i, -1])
    
        elif Tensor.ndim == 5:
            ax[i, 0].contourf(Tensor[i, ..., plane[i], components[i]])
            ax[i, 1].contourf(interp_tsr[i, ..., plane[i], components[i]])
            ax[i, 2].contourf(Tensor[i, ..., plane[i], components[i]] - interp_tsr[i, ..., plane[i], components[i]])
    
            plt.colorbar(ax[i, 0].contourf(Tensor[i, ..., plane[i], components[i]]), ax=ax[i, 1])
            plt.colorbar(ax[i, 2].contourf(Tensor[i, ..., plane[i], components[i]] - interp_tsr[i, ..., plane[i], components[i]]), ax=ax[i, -1])
    
    ax[0, 0].set_title(f'Original')
    ax[0, 1].set_title(f'Reconstructed')
    ax[0, 2].set_title(f'Error')

    
    for axs in ax.flatten():
        axs.set(yticks = [], xticks = [])
    
    RRMSE= np.linalg.norm(np.reshape(Tensor - interp_tsr, newshape=(np.size(Tensor), 1)), ord=np.inf) / np.linalg.norm(
        np.reshape(Tensor, newshape=(np.size(Tensor), 1)), ord=np.inf)
    
    plt.suptitle(f'Interpolation results | RRMSE: {np.round(RRMSE, 3)*100}% | Elapsed time: {np.round(T1 - T0, 3)} seconds')
    
    plt.tight_layout()
    plt.show()
    
    print(f'RRMSE error after interpolation is: {np.round(RRMSE, 3)*100}%')
    
    return interp_tsr, RRMSE
