#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb 10 17:17:49 2024

@author: paul
"""

def h(u):
    w = u 
    return w