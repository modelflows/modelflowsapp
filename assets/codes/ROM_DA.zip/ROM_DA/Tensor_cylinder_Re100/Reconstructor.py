import numpy as np
import scipy
import hosvd
import matplotlib.pyplot as plt
import os
from scipy.interpolate import griddata, LinearNDInterpolator
import hdf5storage

path0 = os.getcwd()

def superresolution(Tensor, Downsampled, x, y, z, modes):
    '''
    SVD superresolution function that reconstructs a low resolution dataset to create a high resolution version of the same
    Args:
        - Tensor: high resolution dataset. Only used to extract the high resolution dataset dimensions
        - Downsampled: low resolution dataset to amplify
        - x: x coordinates of the optimal sensors or data points 
        - y: y coordinates of the optimal sensors or data points
        - z: z coordinates of the optimal sensors or data points
        - modes: number of SVD modes to retain during reconstruction

    Returns:
        - A_reconst: high resolution version of the Downsampled tensor
    '''

    Tsr = np.full(Tensor.shape, np.nan)

    if Tensor.ndim == 3:
        ny, nx, nt = Tensor.shape

    if Tensor.ndim == 4:
        nv, ny, nx, nt = Tensor.shape

    if Tensor.ndim > 4:
        nv, ny, nx, nz, nt = Tensor.shape

    if Tensor.ndim == 3:
        for i in range(len(y)):
            for j in range(len(x)):
                Tsr[y[i], x[j], :] = Downsampled[i, j, :]

    if Tensor.ndim > 3:
        for i in range(len(y)):
            for j in range(len(x)):
                if Tensor.ndim == 4:
                    Tsr[:, y[i], x[j], :] = Downsampled[:, i, j, :]
                elif Tensor.ndim == 5:
                    for k in range(len(z)):
                        Tsr[:, y[i], x[j], z[k], :] = Downsampled[:, i, j, k, :]

    X_grid1, Y_grid1 = np.meshgrid(np.arange(ny), np.arange(nx), indexing='ij')

    if Tensor.ndim > 4:
        Y_grid2, Z_grid2 = np.meshgrid(np.arange(ny), np.arange(nz), indexing='ij')
        X_grid3, Z_grid3 = np.meshgrid(np.arange(nx), np.arange(nz), indexing='ij')

    interp_tsr = Tsr.copy()

    N = sum(np.isnan(Tsr.flatten()))

    print(f'Downsampled dataset shape: {Downsampled.shape}')
    print(f'High resolution dataset shape: {Tsr.shape}')
    print(f'Number of data points to complete: {N}')

    if Tensor.ndim == 3:
        for j in range(nt):
            # XY PLANE
            Tsr_copyXY = Tsr[..., j].copy()

            if np.isnan(Tsr_copyXY).any():
                non_nan_coordsXY = np.argwhere(~np.isnan(Tsr_copyXY))
                nan_coordsXY = np.argwhere(np.isnan(Tsr_copyXY))

                non_nan_valuesXY = Tsr_copyXY[~np.isnan(Tsr_copyXY)]

                interpXY = LinearNDInterpolator(list(zip(non_nan_coordsXY[:, 0], non_nan_coordsXY[:, 1])), non_nan_valuesXY, fill_value = non_nan_valuesXY.mean())

                interpolated_dataXY = interpXY(X_grid1, Y_grid1)

                interp_tsr[..., j] = interpolated_dataXY

    elif Tensor.ndim == 4:
        for i in range(nv):
            for j in range(nt):
                # XY PLANE
                Tsr_copyXY = Tsr[i, ..., j].copy()

                if np.isnan(Tsr_copyXY).any():
                    non_nan_coordsXY = np.argwhere(~np.isnan(Tsr_copyXY))
                    nan_coordsXY = np.argwhere(np.isnan(Tsr_copyXY))

                    non_nan_valuesXY = Tsr_copyXY[~np.isnan(Tsr_copyXY)]

                    interpXY = LinearNDInterpolator(list(zip(non_nan_coordsXY[:, 0], non_nan_coordsXY[:, 1])), non_nan_valuesXY, fill_value = non_nan_valuesXY.mean())

                    interpolated_dataXY = interpXY(X_grid1, Y_grid1)

                    interp_tsr[i, ..., j] = interpolated_dataXY

    elif Tensor.ndim > 4:
        for i in range(nv):
            for j in range(nt):

                # XY PLANE
                for n in range(nz):
                    Tsr_copyXY = Tsr[i, ..., n, j].copy()

                    if np.isnan(Tsr_copyXY).any():
                        non_nan_coordsXY = np.argwhere(~np.isnan(Tsr_copyXY))
                        nan_coordsXY = np.argwhere(np.isnan(Tsr_copyXY))

                        non_nan_valuesXY = Tsr_copyXY[~np.isnan(Tsr_copyXY)]

                        interpXY = LinearNDInterpolator(list(zip(non_nan_coordsXY[:, 0], non_nan_coordsXY[:, 1])), non_nan_valuesXY, fill_value = non_nan_valuesXY.mean())

                        interpolated_dataXY = interpXY(X_grid1, Y_grid1)
 
                        interp_tsr[i, ..., n, j] = interpolated_dataXY

                # YZ PLANE
                for m in range(nx):
                    Tsr_copyYZ = interp_tsr[i, :, m, :, j].copy()

                    if np.isnan(Tsr_copyYZ).any():

                        non_nan_coordsYZ = np.argwhere(~np.isnan(Tsr_copyYZ))
                        nan_coordsYZ = np.argwhere(np.isnan(Tsr_copyYZ))

                        non_nan_valuesYZ = Tsr_copyYZ[~np.isnan(Tsr_copyYZ)]

                        interpYZ = LinearNDInterpolator(list(zip(non_nan_coordsYZ[:, 0], non_nan_coordsYZ[:, 1])), non_nan_valuesYZ, fill_value = non_nan_valuesYZ.mean())

                        interpolated_dataYZ = interpYZ(Y_grid2, Z_grid2)

                        interp_tsr[i, :, m, :, j] = interpolated_dataYZ

                # XZ PLANE
                for d in range(ny):
                    Tsr_copyXZ = interp_tsr[i, d, ..., j].copy()

                    if np.isnan(Tsr_copyXZ).any():

                        non_nan_coordsXZ = np.argwhere(~np.isnan(Tsr_copyXZ))
                        nan_coordsXZ = np.argwhere(np.isnan(Tsr_copyXZ))

                        non_nan_valuesXZ = Tsr_copyXZ[~np.isnan(Tsr_copyXZ)]

                        interpXZ = LinearNDInterpolator(list(zip(non_nan_coordsXZ[:, 0], non_nan_coordsXZ[:, 1])), non_nan_valuesXZ, fill_value = non_nan_valuesXZ.mean())

                        interpolated_dataXZ = interpXZ(X_grid3, Z_grid3)

                        interp_tsr[i, d, ..., j] = interpolated_dataXZ

    A_s = interp_tsr.copy()
    MSE_gaps = np.zeros(500)

    for ii in range(500):

        n = modes * np.ones(np.shape(A_s.shape))

        A_reconst = hosvd.HOSVD_function(A_s, n)[0]

        MSE_gaps[ii] = np.linalg.norm(A_reconst[np.isnan(Tsr)] - A_s[np.isnan(Tsr)]) / N

        if ii > 3 and MSE_gaps[ii] >= MSE_gaps[ii - 1]:
            break
        else:
            A_s[np.isnan(Tsr)] = A_reconst[np.isnan(Tsr)]

    rrmse = np.linalg.norm(np.reshape(Tensor - A_reconst, newshape=(np.size(Tensor), 1)), ord=np.inf) / np.linalg.norm(
        np.reshape(Tensor, newshape=(np.size(Tensor), 1)), ord=np.inf)
    print(f'SVD modes: {modes} | RRMSE: {np.round(rrmse * 100, 3)}%')

    # Results plots for the max error snapshot
    if Tensor.ndim == 3:
        error = Tensor[...] - A_reconst[...]
        error_coord = np.argmax(error)
        error_coords = np.unravel_index(error_coord, error.shape)
        components = error_coords[-1]

        plt.ioff()
        fig, ax = plt.subplots(1, 3, figsize=(10, 10))
        ax[0].contourf(Tensor[..., components])
        ax[1].contourf(A_reconst[..., components])
        ax[2].contourf(Tensor[..., components] - A_reconst[..., components])

        plt.colorbar(ax[0].contourf(Tensor[..., components]), ax=ax[1])
        plt.colorbar(ax[2].contourf(Tensor[..., components] - A_reconst[..., components]),
                        ax=ax[2])
        
        ax[0].set_title(f'Original')
        ax[1].set_title(f'Reconstructed')
        ax[2].set_title(f'Error')

        for axs in ax.flatten():
            axs.set(yticks=[], xticks=[])

        plt.tight_layout()
        plt.show(block=False)
        plt.close()
    
    if Tensor.ndim > 3:
        plt.ioff()
        fig, ax = plt.subplots(nv, 3, figsize=(10, 10))

        components = []
        plane = []
        if Tensor.ndim == 4:
            for i in range(nv):
                error = Tensor[i, ...] - A_reconst[i, ...]
                error_coord = np.argmax(error)
                error_coords = np.unravel_index(error_coord, error.shape)
                components.append(error_coords[-1])

        if Tensor.ndim == 5:
            for i in range(nv):
                error = Tensor[i, ...] - A_reconst[i, ...]
                error_coord = np.argmax(error)
                error_coords = np.unravel_index(error_coord, error.shape)
                components.append(error_coords[-1])
                plane.append(error_coords[-2])

        for i in range(nv):
            if Tensor.ndim == 4:
                ax[i, 0].contourf(Tensor[i, ..., components[i]])
                ax[i, 1].contourf(A_reconst[i, ..., components[i]])
                ax[i, 2].contourf(Tensor[i, ..., components[i]] - A_reconst[i, ..., components[i]])

                plt.colorbar(ax[i, 0].contourf(Tensor[i, ..., components[i]]), ax=ax[i, 1])
                plt.colorbar(ax[i, 2].contourf(Tensor[i, ..., components[i]] - A_reconst[i, ..., components[i]]),
                                ax=ax[i, -1])

            elif Tensor.ndim == 5:
                ax[i, 0].contourf(Tensor[i, ..., plane[i], components[i]])
                ax[i, 1].contourf(A_reconst[i, ..., plane[i], components[i]])
                ax[i, 2].contourf(Tensor[i, ..., plane[i], components[i]] - A_reconst[i, ..., plane[i], components[i]])

                plt.colorbar(ax[i, 0].contourf(Tensor[i, ..., plane[i], components[i]]), ax=ax[i, 1])
                plt.colorbar(ax[i, 2].contourf(
                    Tensor[i, ..., plane[i], components[i]] - A_reconst[i, ..., plane[i], components[i]]), ax=ax[i, -1])

        ax[0, 0].set_title(f'Original')
        ax[0, 1].set_title(f'Reconstructed')
        ax[0, 2].set_title(f'Error')

        for axs in ax.flatten():
            axs.set(yticks=[], xticks=[])



    return A_reconst, rrmse
