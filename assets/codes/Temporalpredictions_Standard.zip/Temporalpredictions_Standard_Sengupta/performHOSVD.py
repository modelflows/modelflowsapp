import hosvd
import numpy as np
import time
import scipy.io
import mat73
import matplotlib.pyplot as plt
################################################################################
# Auxiliary functions
################################################################################

def perform_hosvd(tensor, tolerance):
    #
    ##  Configuration (that do not depend on the user):
    #
    SNAP = tensor.shape[-1]

    TimePos = tensor.ndim

    Tensor0 = tensor.copy()
    shapeTens = list(np.shape(tensor))
    shapeTens[-1] = SNAP
    Tensor = np.zeros(shapeTens)

    Tensor[..., :] = Tensor0[..., 0:SNAP]

    nn0 = np.array(Tensor.shape)
    nn = np.array(nn0)
    nn[1:np.size(nn)] = 0

    #
    ##  Perform HOSVD on input data set using the tolerance specified:
    #
    return hosvd.HOSVD(Tensor, tolerance, nn, nn0, TimePos)


################################################################################
# Load data
################################################################################

#
##  Load downsampled data set:
#
tensorOrig = mat73.loadmat('/home/rodrigo/Downloads/Tensor_CylinderPIV_SteadyState1.mat')['Tensor']
# tensorOrig = mat73.loadmat('cilind2D_adri_multRe.mat')['tensor']
print(f"Tensor orig shape: {tensorOrig.shape}")

################################################################################
# HOSVD
################################################################################
t0 = time.time()
varepsilon1 = 1e-2

print('\nPerforming HOSVD. Please wait...\n')
hatT, Udens_train, S_train, sv_train, nn1_train, n, TT = perform_hosvd(
    tensorOrig, varepsilon1)
t1 = time.time()

print((t1 - t0) / 60)