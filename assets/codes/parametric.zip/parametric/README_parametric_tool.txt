******************************READ FIRST***************************************
CONTENT OF THE FOLDER 
This compressed folder contains 6 different files, including this readme file.
Which are: 
- hosvd.py 
- tfhosvd.py 
- main_orecasting.ipynb 
- main_parameter_interpolation.ipybn
- main_interpolation_forecasting.ipynb 
- tensor_7_128_250.npy 
- tensor_8_128_250.npy 
*******************************************************************************
*******************************************************************************
/////////////////////////////// hosvd.py ////////////////////////////////////
This '.py' file contains the functions related to the Higher-order singular va-
lue decomposition. The hosvd function is the main one, while the fold, unfold, 
etc. are operations performed inside. *Be careful* the fucntion tprod is the 
inverse of hosvd, so it takes all de decomposed components and reconstructs the
tensor to its original shape. 
*******************************************************************************
*******************************************************************************
/////////////////////////// tfhosvd.py ////////////////////////////////////////
This '.py' file contains the funcions related to the Higher-order singular va-
lue decomposition using Tensorflow/Keras math toolkit. This was performed in 
order to overcome the limitations of numpy working with symbolic data. Same as 
the 'hosvd.py', this file contains the 'hosvd' function, the inverse 'tprod' 
function and all the operations needed.     
*******************************************************************************
*******************************************************************************
////////////////////////// main_forecasting.ipynb /////////////////////////////
This '.ipynb' file is a Jupiter notebook, suited to work in google colab, or to 
run it in local. In order to run it in google collab, it is required to follow 
the instructions inside collab step by step and add a 'one-drive' address. If it
is runnning in local it is needed to locate this file together with: 'hosvd.py' 
and the 'tensor_7_128_250.npy' or 'tensor_8_128_250.npy' numerical databases.
This tool is capable of predicting over time the behavior of a flow.   
*******************************************************************************
*******************************************************************************
///////////////////// main_interpolation_forecasting.ipynb /////////////////////
This '.ipynb' file is a Jupiter notebook, suited to work in google colab, or to 
run it in local. In order to run it in google collab, it is required to follow 
the instructions inside collab step by step and add a 'one-drive' address. If it
is runnning in local it is needed to locate this file together with: 'hosvd.py' 
and the 'tensor_7_128_250.npy' or 'tensor_8_128_250.npy' numerical databases.
This tool is capable of generating a new database for an unseen parameter and 
predict over time.
*******************************************************************************
*******************************************************************************
///////////////////// main_parameter_interpolation.ipynb /////////////////////
This '.ipynb' file is a Jupiter notebook, suited to work in google colab, or to 
run it in local. In order to run it in google collab, it is required to follow 
the instructions inside collab step by step and add a 'one-drive' address. If it
is runnning in local it is needed to locate this file together with: 'hosvd.py' 
and the 'tensor_7_128_250.npy' or 'tensor_8_128_250.npy' numerical databases.
This tool is capable of generating databases for different new flow parameters
by using Krigage/ GPR / interpolation techniques. 
*******************************************************************************
*******************************************************************************
//////////////////////////// tensor_7_128_250.npy ////////////////////////////
This file contains a two dimensional square cylinder with AoA between -5° and 5°
with step of 0.5°. In order to compare the accuracy of the prediction, it must be
sliced. If it is intended to generate new datasets, do not slice the tensor. This
database contains 4 components ('X velocity', 'Y velocity', 'Z velocity' and 
'Pressure'. The CFD simulation has been interpolated into a structured grid with 
128 x 128 elements. It contains 250 snapshots.
*******************************************************************************
*******************************************************************************
//////////////////////////// tensor_8_128_250.npy ////////////////////////////
This file contains a two dimensional square cylinder with Re between 200 and 400
with step of 20. In order to compare the accuracy of the prediction, it must be
sliced. If it is intended to generate new datasets, do not slice the tensor. This
database contains 4 components ('X velocity', 'Y velocity', 'Z velocity' and 
'Pressure'. The CFD simulation has been interpolated into a structured grid with 
128 x 128 elements. It contains 250 snapshots.
*******************************************************************************
*******************************************************************************
////////////////////////////// IMPORTANT NOTES ////////////////////////////////

Both jupiter notebooks are set do print the current tensorflow version, and to 
install the packages needed to perform all the operations. It is recommended to
create a virtual envirnonment or run it in an isolated virtual environment. 

********************************************************************************
