import tensorflow as tf 
import numpy as np 
from sklearn.utils.extmath import randomized_svd 
 
def matlen(var): 
    '''Equivalent to Matlab's length()''' 
    if tf.size(tf.shape(var)) == 1: 
        x = tf.size(var) 
    else: 
        x = tf.reduce_max(tf.shape(var)) 
    return x 
def unfold(A, dim):  
    '''Turns tensor into matrix keeping the columns on dim'''  
    ax = tf.range(tf.rank(A))  
    return tf.reshape(tf.transpose(A, perm=tf.roll(ax, shift=-dim, axis=0)), (tf.shape(A)[dim], -1))  
  
def fold(B, dim, shape):  
    '''Reverse operation to the unfold function'''  
      
    ax = tf.range(len(shape))  
      
    shape = tf.roll(shape, shift=-dim, axis=0)  
       
    A = tf.reshape(B, shape)  
    return tf.transpose(A, perm=tf.roll(ax, shift=dim, axis=0))  
  
def tprod(S, U):  
    '''Tensor product of an ndim-array and multiple matrices'''  
    print(S.shape)
    T = tf.squeeze(S)  
    shap = list(S.shape[1:])  
    print(shap) 
      
    for i in range(0,len(U)):  
      
 
            shap[i] = list((U[i]).shape)[1]  
            H = unfold(T, i)  
              
            print(U[i].shape)        
            print(H)        
            print(shap)  
            T = fold(tf.matmul(tf.squeeze(U[i]), H), i, shap)  
            print(T.shape)  
            print(shap)  
    return T 

def tprod_1(S, U):  
    '''Tensor product of an ndim-array and multiple matrices'''  
    print(S.shape)
    T = tf.squeeze(S)  
    shap = list(S.shape[1:])  
    print(shap) 
      
    for i in range(0,len(U)-1):  
      
 
            shap[i] = list((U[i]).shape)[1]  
            H = unfold(T, i)  
              
            print(U[i].shape)        
            print(H)        
            print(shap)  
            T = fold(tf.linalg.matvec(tf.squeeze(U[i], H)), i, shap)  
            print(T.shape)  
            print(shap)  
    return T 
 
def svdtrunc(A, n): 
    '''Truncated svd''' 
    _, s, U = tf.linalg.svd(A) 
    Utrunc = U[:, :n] 
    strunc = s[:n] 
    return Utrunc, strunc 
 
def HOSVD_function(T, n): 
    '''Perform hosvd to tensor''' 
    P = T.ndim 
    U = [None] * P 
    UT = [None] * P 
    sv = [None] * P 
    producto = n[0] 
 
    for i in range(1, P): 
        producto = producto * n[i] 
 
    n = list(n)  # to be able to assign values 
 
    for i in range(P): 
        n[i] = int(np.amin((n[i], producto / n[i]))) 
        A = unfold(T, i) 
        Uaux = [] 
        # SVD based reduction of the current dimension (i): 
        Ui, svi = svdtrunc(A, n[i]) 
        if n[i] < 2: 
            Uaux = tf.zeros((tf.shape(Ui)[0], 2)) 
            Uaux[:, 0].assign(Ui[:, 0]) 
            U[i] = Uaux 
        else: 
            U[i] = Ui[:, :n[i]] 
        UT[i] = tf.transpose(U[i]) 
        sv[i] = svi 
 
    S = tprod(T, UT) 
    TT = tprod(S, U) 
    return TT, S, U, sv, n 
 
def HOSVD(Tensor, varepsilon1, nn, n, TimePos): 
    '''Perform hosvd to input data and retain all the singular values''' 
    if np.iscomplex(Tensor.any()) == False: 
        Tensor = Tensor.astype(np.float32) 
 
    [TT, S, U, sv, n] = HOSVD_function(Tensor, n) 
 
    ## Set the truncation of the singular values using varepsilon1 
    # (automatic truncation) 
    for i in range(1, len(nn)): 
        count = 0 
        for j in range(tf.shape(sv[i])[0]): 
            if sv[i][j] / sv[i][0] <= varepsilon1: 
                pass 
            else: 
                count = count + 1 
 
        nn[i] = count 
 
    print(f'Initial number of singular values: {n}') 
    print(f'Number of singular values retained: {nn}') 
 
    ## Perform HOSVD retaining n singular values: reconstruction of the modes 
    [TT, S2, U, sv2, nn2] = HOSVD_function(Tensor, nn) 
 
    ## Construct the reduced matrix containing the temporal modes: 
    UT = [tf.transpose(u) for u in U] 
    hatT = [] 
    for pp in range(len(nn2)): 
        for kk in range(nn2[TimePos - 1]): 
            hatT.append(tf.multiply(sv2[TimePos - 1][kk], UT[TimePos - 1][kk, :])) 
 
    hatT = tf.reshape(hatT, (len(hatT), tf.size(hatT[0]))) 
    return hatT, U, S2, sv, nn2, n, TT