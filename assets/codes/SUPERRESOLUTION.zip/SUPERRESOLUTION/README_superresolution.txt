******************************READ FIRST***************************************
CONTENT OF THE FOLDER 
This compressed folder contains 6 different files, including this readme file.
Which are: 
- hosvd.py 
- tfhosvd.py 
- main_superresolution.ipynb 
*******************************************************************************
*******************************************************************************
/////////////////////////////// hosvd.py ////////////////////////////////////
This '.py' file contains the functions related to the Higher-order singular va-
lue decomposition. The hosvd function is the main one, while the fold, unfold, 
etc. are operations performed inside. *Be careful* the fucntion tprod is the 
inverse of hosvd, so it takes all de decomposed components and reconstructs the
tensor to its original shape. 
*******************************************************************************
*******************************************************************************
/////////////////////////// tfhosvd.py ////////////////////////////////////////
This '.py' file contains the funcions related to the Higher-order singular va-
lue decomposition using Tensorflow/Keras math toolkit. This was performed in 
order to overcome the limitations of numpy working with symbolic data. Same as 
the 'hosvd.py', this file contains the 'hosvd' function, the inverse 'tprod' 
function and all the operations needed.     
*******************************************************************************
*******************************************************************************
//////////////////////// main_superresolution.ipynb ///////////////////////////
This '.ipynb' file is a Jupiter notebook, suited to work in google colab, or to 
run it in local. In order to run it in google collab, it is required to follow 
the instructions inside collab step by step and add a 'one-drive' address. If it
is runnning in local it is needed to locate this file together with: 'hosvd.py' 
and the 'tensor_7_128_250.npy' or 'tensor_8_128_250.npy' numerical databases.
This tool is capable of predicting over time the behavior of a flow.   
********************************************************************************
*******************************************************************************
/////////////////////////////////// Databases /////////////////////////////////
The dabases can be found in this same webpage repository, with its corresponding
citation to the author's paper. The databases are:   
Two dimensional laminar flow through a circular cylinder. 
Three dimensional laminar flow through a circula cylinder. 
Large-eddy simulation of a JET. 

*******************************************************************************
*******************************************************************************
////////////////////////////// IMPORTANT NOTES ////////////////////////////////

Both jupiter notebooks are set do print the current tensorflow version, and to 
install the packages needed to perform all the operations. It is recommended to
create a virtual envirnonment or run it in an isolated virtual environment. 

********************************************************************************
