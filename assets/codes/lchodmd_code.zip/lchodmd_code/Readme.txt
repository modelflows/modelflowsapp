Run the lchodmd_main.py file
