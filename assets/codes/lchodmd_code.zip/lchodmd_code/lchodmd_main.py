
import os
import csv
import sys
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import time
import pysensors as ps
from mplcursors import cursor
from numpy.linalg import norm, svd, inv, qr


import warnings
warnings.filterwarnings('ignore')

# Matplotlib plot parameters:
plt.rc('axes', labelsize=18)
plt.rc('axes', titlesize=18)
plt.rc('legend', fontsize=18)
plt.rc('figure', titlesize=20)
plt.rc('xtick', labelsize=16)
plt.rc('ytick', labelsize=16)



'''
This code includes lcDMD and lcHODMD when using equdistant data points, or sensors which are optimally placed using OS_lcSVD

'''
np.random.seed(42)

#  Functions

def cleaning_spectrum(amp_temp,freq_temp,DMDmode,d1,tol1,cs):
    temp01=[]
    temp02=[]
    temp03=[]   
    DMDmode=np.squeeze(DMDmode)
    amp_temp=np.squeeze(amp_temp)
    freq_temp=np.squeeze(freq_temp)
    print(DMDmode.shape)

    print(amp_temp.shape)
    
             
    for i in range(amp_temp.shape[0]):
        value= freq_temp[i]
        mode=amp_temp[i]
        modescases1=DMDmode[:,:,:,i]
        if value >= 0:
            temp01.append(value)
            temp02.append(mode)
            temp03.append(modescases1)

        else:
            print("ok")
    

    # Combine temp01 and temp02, sort by the absolute values of temp01
    combined = list(zip(temp01,temp02,temp03))  # Combine the two lists
    sorted_combined = sorted(combined, key=lambda x: abs(x[0]))  # Sort by magnitude of temp01
    

    sorted_temp01 = [item[0] for item in sorted_combined]
    sorted_temp02 = [item[1] for item in sorted_combined]
    sorted_temp03 = [item[2] for item in sorted_combined]
    
    
    # Create a folder named "results" if it doesn't exist
    results_folder = 'results'
    os.makedirs(results_folder, exist_ok=True)
    
    d=d1
    tol=tol1

    # Generate filenames dynamically
    csv_filename = f"d{d}_tol{tol}_frequency{cs}.csv"
    figure_filename = f"d{d}_tol{tol}_freqvsamp{cs}.png"
    
    # Save sorted_temp01 to CSV in the "results" folder
    csv_path = os.path.join(results_folder, csv_filename)
    with open(csv_path, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['Frequency (omega_n)'])  # Write header if needed
        writer.writerows([[value] for value in sorted_temp01])  # Save each item in a new row
    
    # Output the plot
    plt.figure(num='CLOSE TO CONTINUE RUN - Frequency/Amplitude', figsize=(10, 10))
    plt.plot(sorted_temp01, sorted_temp02 / np.amax(sorted_temp02), 'bs', markersize=14)
    
    # Check if any of sorted_temp01 are greater than 0 to apply logarithmic scale
    if any(val > 0 for val in sorted_temp01):
        plt.yscale('log')  # Logarithmic scale in y axis
    
    plt.xlabel(r'Frequency ($\omega_{n}$)')
    plt.ylabel(r'Amplitude divided by max. amplitude ($a_{n}$)')
    
    # Save the figure to the "results" folder
    plot_path = os.path.join(results_folder, figure_filename)
    plt.savefig(plot_path)  # Save the plot as PNG (you can change the format)
    
    plt.close()


    DMDmode=np.array(sorted_temp03)
    a1=np.array(sorted_temp01)
    a2=np.array(sorted_temp02)
    DMDmode=np.squeeze(DMDmode)
    a1=np.squeeze(a1)
    a2=np.squeeze(a2)


    if DMDmode.ndim == 5:
        nz = int(DMDmode.shape[-2] / 2)

    check=len(a1)
    DMDm=DMDmode
    print(DMDm.shape)
    if DMDm.ndim <= 4:
        for i in range(DMDm.shape[1]):
            for j in range(check):
                
                fig, ax = plt.subplots(1, 3, gridspec_kw={'width_ratios': [25, 25, 1]}, figsize=(10, 5))
                #fig.suptitle(f'{tc} - DMD mode {j + 1} (Slice {i + 1})')
        
                # Titles for subplots
                #ax[0].set_title('Real part')
                #ax[1].set_title('Imaginary part')
        
                # Plot the real part
                if user_choice==4 or user_choice==5:
                    im = ax[0].contourf(DMDm[j,i, ...].real)#*(Factor[i])+Media[i])+Media_tiempo[i,:,:,j]
                else:
                    im = ax[0].contourf(DMDm[j,i, ...].real)
    
                # Plot the imaginary part
                if user_choice==4 or user_choice==5:
                    ax[1].contourf(DMDm[j,i, ...].imag)#*(Factor[i])+Media[i])+Media_tiempo[i,:,:,j])
                else:
                    ax[1].contourf(DMDm[j,i, ...].imag)
                # Add colorbar
                plt.colorbar(im, cax=ax[2])
        
                # Remove axis ticks
                ax[0].set(xticks=[], yticks=[])
                ax[1].set(xticks=[], yticks=[])
        
                # Set axis labels
                ax[0].set_ylabel('Y')
                ax[0].set_xlabel('X')
                ax[1].set_xlabel('X')
        
                # Show the plot for each slice
                freq2=a1[j]
                figure_filename1 = f"d{d}_tol{tol}_freq{freq2}_case{cs}_var{i}.png"
                plot_path = os.path.join(results_folder, figure_filename1)
                plt.savefig(plot_path)  # Save the plot as PNG (you can change the format)
    
                
            
    else:
    
        for i in range(DMDm.shape[0]):
            # Create a new figure and set of subplots for each slice
            fig, ax = plt.subplots(1, 3, gridspec_kw={'width_ratios': [25, 25, 1]}, figsize=(10, 5))
            #fig.suptitle(f'{tc} - DMD mode {j + 1} (Slice {i + 1})')
    
            # Titles for subplots
            #ax[0].set_title('Real part')
            #ax[1].set_title('Imaginary part')
    
            # Plot the real part
            im = ax[0].contourf(DMDm[i, ..., nz, j].real)
            # Plot the imaginary part
            ax[1].contourf(DMDm[i, ..., nz, j].imag)
            # Add colorbar
            plt.colorbar(im, cax=ax[2])
    
            # Remove axis ticks
            ax[0].set(xticks=[], yticks=[])
            ax[1].set(xticks=[], yticks=[])
    
            # Set axis labels
            ax[0].set_ylabel('Y')
            ax[0].set_xlabel('X')
            ax[1].set_xlabel('X')
    
            # Show the plot for the current slice
            plt.show()
    
    
def centering_scaling(data):
    """### Centering and scaling"""

    Tensor_orig = data
    Factor = np.zeros(data.shape[0])
    Media = np.zeros(data.shape[0])
    Media_tiempo = np.zeros(np.shape(Tensor_orig))
    
    for iter in range(data.shape[3]):
        Media_tiempo[:,:,:,iter] = np.mean(Tensor_orig,axis=3)
        
    Tensor_orig1 = Tensor_orig-Media_tiempo
    
    for p in range(data.shape[0]):
        variable = Tensor_orig1[p,:,:,:]
        Factor[p] = np.std(variable) #Auto scaling
        Media[p] = np.mean(variable)
        Tensor_orig[p,:,:,:] = (variable-Media[p])/(Factor[p])
    
    return Tensor_orig,Factor,Media,Media_tiempo

def truncatedSVD(A,esvd):
    '''Decomposition into singular values, truncated on esvd'''
    U,s,Wh=np.linalg.svd(A,full_matrices=False)
    n=0
    norm=np.linalg.norm(s)
    for i in range(s.size):
        if np.linalg.norm(s[i:])/norm<=esvd:
            break
        else:
            n+=1
    return U[:,:n],s[:n],Wh[:n,:]

def OS_lcSVD(Tensor, n_sensors, esvd):
    '''Optimal sensor low-cost SVD:
        Input:
            - tensor (IxJ): snapshot matrix.
            - n_sensors: number of sensors to be used.
        Output:
            - sensors (1xn_sensors): vector of indexes for the optimal sensors.
            '''
    def sensor_opt(Tensor0, n_sensors):

        shape = Tensor0.shape

        if Tensor0.ndim == 3:
            Matrix = np.reshape(Tensor0, (np.prod(shape[:-1]), shape[-1]))

            mesh_size = shape[:-1]

        else:
            norm = np.linalg.norm(Tensor0.reshape(shape[0], np.prod(shape[1:])), axis = 0)

            norm = np.reshape(norm, (1, *shape[1:]))

            Matrix = np.reshape(norm, (np.prod(shape[1:-1]), shape[-1])) # Matrix loses 1 dimensions since there is now only 1 vel component (the norm)

            mesh_size = shape[1:-1]

        X_train = np.transpose(Matrix, (1, 0))

        n_samples, n_features = X_train.shape
        print('Number of samples:', n_samples)
        print('Number of possible sensors:', n_features)

        model = ps.SSPOR(basis = ps.basis.SVD(n_basis_modes = 2), n_sensors=n_sensors)

        model.fit(X_train)
        sensors = model.get_selected_sensors() # Sensor positions refering to the flattened out spatial mesh

        sens = np.zeros(n_features)
        sens[sensors] = 1
        matrix = np.array(np.reshape(sens, mesh_size)) # Matrix for zeros shaped Nx, Ny which contains 1 in the sensor positions

        x = []
        y = []
        z = []

        if len(shape) == 3: # For 2D data with only 1 component (Nx, Ny, Nt)
            for i in range(shape[1]):
                for j in range(shape[0]):
                    if matrix[j, i] == 1:
                        x.append(i) # X coordinates of the sensors
                        y.append(j) # Y coordinates of the sensors

        elif len(shape) in [4, 5]: # 2D data with more than 1 component, and 3D data
            for i in range(shape[2]):
                for j in range(shape[1]):
                    if matrix.ndim == 2:
                        if matrix[j, i] == 1:
                            x.append(i) # X coordinates of the sensors
                            y.append(j) # Y coordinates of the sensors
                    elif matrix.ndim == 3:
                        for k in range(shape[3]):
                            if matrix[j, i, k] == 1:
                                x.append(i) # X coordinates of the sensors
                                y.append(j) # Y coordinates of the sensors
                                z.append(k) # Z coordinates of the sensors

        if matrix.shape == 2:
            z = None

        return sensors, x, y, z


    def SVD_sensorChecker(tensor, sensors, esvd):

        shape = tensor.shape
        dims_prod = np.prod(shape[:-1])
        Tensor = np.reshape(tensor, (dims_prod, shape[-1])) # dims_prod is the compression of the spatial data, shape[-1] y the shape of the spatial data
        Ared = Tensor[sensors, :]

        Ured, Sred, Vred = np.linalg.svd(Ared, full_matrices = False)

        sel = 0
        norm = np.linalg.norm(Sred)
        for i in range(Sred.size):
            if np.linalg.norm(Sred[i:]) / norm <= esvd:
                pass
            else:
                sel += 1

        Sred = np.diag(Sred)
        Ured = Ured[:, :sel]
        Sred = Sred[:sel, :sel]
        Vred = Vred.conj().T
        Vred = Vred[:, :sel]

        Q, R = np.linalg.qr(Ured)
        Ured = Ured @ np.linalg.inv(R[:sel, :])
        Q1, R1 = np.linalg.qr(Vred)
        Vred = Vred @ np.linalg.inv(R1[:sel, :])

        ss = Ured.conj().T @ Ared @ Vred
        ss1 = np.sign(np.diag(np.diag(ss)))

        Vred = Vred @ ss1

        # Calculate the original SVD modes using the reduced modes
        U = (Tensor @ Vred) @ np.linalg.inv(Sred)
        V = (Tensor[sensors, :].conj().T @ Ured) @ np.linalg.inv(Sred)
        S = Sred

        TensorCheck = np.reshape((U @ S) @ V.conj().T, (shape))

        return TensorCheck

    RelativeErrorRMS = 1

    i = 1

    while RelativeErrorRMS * 100 > 50: # 1 for Cyl2D, BL and JET, 2.5 for Cyl3D

        print(f'Iteration number {i}')

        i += 1

        t0 = time.time()

        sensors, x, y, z = sensor_opt(Tensor, n_sensors)

        TensorCheck = SVD_sensorChecker(Tensor, sensors, esvd)

        t1 = time.time()

        print(f'Optimal sensor low-cost SVD execution time: {(t1 - t0):.5f} seconds')

        Norm2V = np.linalg.norm(Tensor.flatten(), 2)
        diff = (Tensor - TensorCheck).flatten()
        Norm2diff = np.linalg.norm(diff, ord=2)
        RelativeErrorRMS = Norm2diff/Norm2V

        print(f'OS-lcSVD reconstruction error for the sensors combination: {(RelativeErrorRMS * 100):.5f}%')

    print(f'OS-lcSVD reconstruction error for the optimal sensors combination: {(RelativeErrorRMS * 100):.5f}%')

    if Tensor.ndim == 3:
        fig, ax = plt.subplots(1, 1, figsize = (10, 4))
        plt.suptitle('Sensor positions')
        ax.contourf(Tensor[..., 0], alpha = 0.5)
        ax.scatter(x, y, color = 'k')
        cursor(hover=True)
        plt.grid(color = 'grey')
        # ax.set_aspect('equal')
        plt.tight_layout()
        #plt.show()
        plt.close()

    if Tensor.ndim == 4:
        comps = Tensor.shape[0]
        fig, ax = plt.subplots(1, comps, figsize = (12, 4), sharey = True)
        plt.suptitle('Sensor positions')
        for col in range(comps):
            ax[col].contourf(Tensor[col, ..., 0], alpha = 0.5)
            ax[col].scatter(x, y, color = 'k')
            # ax[col].set_aspect('equal')
            ax[col].grid(color='grey')
        cursor(hover=True)
        plt.tight_layout()
        # plt.show()
        plt.close()

    if Tensor.ndim == 5:
        comps = Tensor.shape[0]
        nz = int(Tensor.shape[3] / 2)
        fig, ax = plt.subplots(1, comps, figsize = (14, 4), sharey = True)
        plt.suptitle('Sensor positions | XY plane')
        for col in range(comps):
            ax[col].contourf(Tensor[col, ..., nz, 0], alpha = 0.5)
            ax[col].scatter(x, y, color = 'k')
            # ax[col].set_aspect('equal')
            ax[col].grid(color='grey')
        cursor(hover=True)
        plt.tight_layout()
        # plt.show()
        plt.close()

    return sensors

def reconstruct(u, t, mu):
    '''Reconstructs original data from DMD-d results:
        Input:
            - u (Ixn): Mode matrix (columns).
            - t (J): Time vector.
            - delta (n): vector de ratios de crecimiento.
            - omega (n): vector de frecuencias.
            - mu: np.exp(np.dot((t[1]-t[0]),delta[iii]+np.dot(complex(0,1),omega[iii])))
        Output:
            - TensorRec (IxJ): reconstructed snapshots'''

    TensorRec = np.zeros((u.shape[0], t.size), dtype=np.complex64)
    for i in range(t.size):
        for j in range(mu.shape[0]):
            TensorRec[:, i] += u[:, j] * mu[j]**i
    return TensorRec

def lcSVD(Ared, tensor, esvd, Time, points, case):
    """ Low-cost singular value decomposition
        Input:
          - Inputs are explained in lcHODMD

          Output:
          - U: mxm matrix of the orthonormal eigenvectors of AA.T
          - S: diagonal matrix with r elements equal to the root of the positive eigenvalues of AA.T
          - V: transpose of a nxn matrix containing the orthonormal eigenvectors of A.TA
    """
    shape = tensor.shape
    dims_prod = np.prod(shape[:-1])
    Tensor = np.reshape(tensor, (dims_prod, shape[-1]))

    # SVD applied to the reduced matrix
    Ured, S, Vred = np.linalg.svd(Ared, full_matrices = False)

    n_modes = 0
    norm = np.linalg.norm(S)
    for i in range(S.size):
        if np.linalg.norm(S[i:]) / norm <= esvd:
            pass
        else:
            n_modes += 1

    Sred = np.diag(S)
    Ured = Ured[:, :n_modes]
    Sred = Sred[:n_modes, :n_modes]
    Vred = Vred.conj().T
    Vred = Vred[:, :n_modes]

    Vcase1 = Vred.copy()

    Q, R = np.linalg.qr(Ured)
    Ured = Ured @ np.linalg.inv(R[:n_modes, :])
    Q1, R1 = np.linalg.qr(Vred)
    Vred = Vred @ np.linalg.inv(R1[:n_modes, :])

    ss = Ured.conj().T @ Ared @ Vred
    ss1 = np.sign(np.diag(np.diag(ss)))

    Vred = Vred @ ss1

    # Calculate the original SVD modes using the reduced modes
    U = (Tensor[:, Time] @ Vred) @ np.linalg.inv(Sred)
    V = (Tensor[points, :].conj().T @ Ured) @ np.linalg.inv(Sred)

    # In case 1 the temporal resolution is not enhanced
    if case == 1:
        V = V[Time, :]

    newshape = []
    newshape.append(shape[:-1])
    newshape.append(V.shape[0])
    newshape = list(newshape[0]) + [newshape[1]]

    TensorAprox = np.reshape((U @ Sred) @ V.conj().T, np.array(newshape))
    if case == 1:
        RRMSE = np.linalg.norm(np.reshape(tensor[..., Time] - TensorAprox, newshape=(np.size(tensor[..., Time] ), 1)), ord=2) / np.linalg.norm(
        np.reshape(tensor[..., Time] , newshape=(np.size(tensor[..., Time]), 1)))
        print(f'\nRRMS error made in the during lcSVD: {np.round(RRMSE * 100, 3)}%\n')

    elif case in [0, 2]:
        RRMSE = np.linalg.norm(np.reshape(tensor - TensorAprox, newshape=(np.size(tensor), 1)), ord=2) / np.linalg.norm(
        np.reshape(tensor, newshape=(np.size(tensor), 1)))
        print(f'\nRRMS error made in the during lcSVD: {np.round(RRMSE * 100, 3)}%\n')

    return U, S[:n_modes], V, n_modes, TensorAprox

def dmd1(Ared, tensorA, deltaT, esvd, edmd, Time, points, case):
    '''First order dynamic modal decomposition:
        Input:
            - tensor (IxJ): Snapshot matrix.
            - deltaT: time step
            - n_modes: number of retained SVD modes.
            - edmd: DMD tolerance (DMD modes).
            - Time: array of selected equidistant snapshot indexes.
            - points: array of selected equidistant datapoint indexes.
            - Case: 0) if time isn't downsampled, 1) V from lcSVD is not reconstructed, 2) V from lcSVD is reconstructed.
        Output:
            -u (Ixn): mode matrix (columns) sorted from biggest to smallest amplitude, put to scale.
            -areal (n): amplitude vector (sorted) used to put u to scale.
            -eigval: eigenvalues
            -delta (n): growth rate vector.
            -omega (n): frequency vector.
            -DMDmode: Modes'''

    # Reduced snapshots:
    if Ared.shape != tensorA.shape:
        U, s, Wh, kk, tensor = lcSVD(Ared, tensorA, esvd, Time, points, case)

        virTensor = np.diag(s) @ Wh.T

    else:
        U, s, Wh = truncatedSVD(Ared, esvd)

        virTensor = np.diag(s) @ Wh
        n = s.size

        NormS = np.linalg.norm(s, ord=2)
        kk = 0

        for k in range(0, n):
            if np.linalg.norm(s[k:n], 2) / NormS > esvd:
                kk = kk + 1

    print(f'Spatial complexity: {kk}')

    # Koopman matrix reconstruction:
    Uvir, svir, Wvirh = np.linalg.svd(virTensor[:, :-1], full_matrices = False)
    Rvir = virTensor[:, 1:] @ Wvirh.conj().T @ np.diag(svir**-1) @ Uvir.conj().T
    eigval, eigvec = np.linalg.eig(Rvir)

    # Frequencies and Growthrate:
    delta = np.log(eigval).real/deltaT
    omega = np.log(eigval).imag/deltaT

    # Amplitudes:
    A = np.zeros((Uvir.shape[0] * virTensor.shape[1], Uvir.shape[1]), dtype = np.complex64)
    b = np.zeros(Uvir.shape[0] * virTensor.shape[1], dtype=virTensor.dtype)
    for i in range(virTensor.shape[1]):
        A[i*eigvec.shape[0]:(i+1) * eigvec.shape[0], :] = eigvec @ np.diag(eigval**i)
        b[i*eigvec.shape[0]:(i+1) * eigvec.shape[0]] = virTensor[:, i]

    Ua, sa, Wa = np.linalg.svd(A, full_matrices = False)
    a = Wa.conj().T @ np.diag(sa**-1) @ Ua.conj().T @ b

    # Modes:
    uvir = eigvec @ np.diag(a)
    u = U @ uvir
    areal = np.linalg.norm(u, axis=0) / np.sqrt(np.prod(tensor.shape[:-1]))

    # Spectral complexity:
    kk3 = 0
    for m in range(np.size(areal)):
        if areal[m] / np.max(areal) <= edmd:
            pass
        else:
            kk3 += 1

    print(f'Spectral complexity: {kk3}')
    
    spectr_min.append(kk3)
    print(spectr_min)

    idx = np.flip(np.argsort(areal))
    u=u[:, idx]
    areal = areal[idx]
    eigval = eigval[idx]
    delta = delta[idx]
    omega = omega[idx]

    # Filter important ones:
    mask = (areal / areal[0]) > edmd

    #Mode Matrix:
    ModeMatr = np.zeros((kk3, 4))
    for i in range(kk3):
        ModeMatr[i, 0] = i + 1
        ModeMatr[i, 1] = delta[mask][i]
        ModeMatr[i, 2] = omega[mask][i]
        ModeMatr[i, 3] = areal[mask][i]

    #Calculate modes:
    u = u[:, mask]
    U = U[:, :kk]
    DMDmode = np.zeros((np.prod(tensor.shape[:-1]), kk3), dtype=np.complex64)
    Amplitude0 = np.zeros(kk3)

    """
    for m in range(kk3):
        NormMode = np.linalg.norm(np.dot(U, u[:, m]), ord=2) / np.sqrt(np.prod(tensor.shape[:-1])
        Amplitude0[m] = NormMode
        DMDmode[:, m] = np.dot(U, u[:, m]) / NormMode
    """
    Amplitude0[:kk3] = np.linalg.norm(np.dot(U.T, u[:, :kk3]), ord=2) / np.sqrt(np.prod(tensor.shape[:-1]))
    DMDmode[:, :kk3] = u[:, :kk3] / Amplitude0[:kk3]

    return u, areal[mask], eigval[mask], delta[mask], omega[mask], DMDmode


from sklearn.utils.extmath import randomized_svd


def matlen(var):
    '''
    Equivalent to Matlab's length()
    Args:
        - var: input tensor
    Returns:
        - x: value of the maximum length dimension
    '''
    if np.size(np.shape(var)) == 1:
        x = np.size(var)
    else:
        x = max(np.shape(var))
    return x


def unfold(A, dim):
    '''
    Turns tensor into matrix keeping the columns on dim
    Args:
        - A: input tensor
        - dim: dimensions of the input tensor
    Returns:
        - The unfolded tensor
    '''
    ax = np.arange(A.ndim)
    return np.reshape(np.moveaxis(A, ax, np.roll(ax, dim)), (A.shape[dim], A.size // A.shape[dim]))


def fold(B, dim, shape):
    '''
    Reverse operation to the unfold function
    Input:
        - B; input tensor
        - dim: dimensions of the input tensor
        - shape: shape of the input tensor
    Returns:
        - The folded tensor
    '''
    ax = np.arange(len(shape))
    shape = np.roll(shape, -dim)
    A = np.reshape(B, shape)
    return np.moveaxis(A, ax, np.roll(ax, -dim))


def tprod(S, U):
    '''
    Tensor product of an ndim-array and multiple matrices
    Args:
        - S: first input tensor (singular values)
        - U: second input tensor (POD modes)
    Returns:
        T: the product between both tensors
    '''
    T = S
    shap = list(np.shape(S))
    for i in range(0, np.size(U)):
        x = np.count_nonzero(U[0][i])
        if not x == 0:
            shap[i] = np.shape(U[0][i])[0]
            H = unfold(T, i)
            T = fold(np.dot(U[0][i], H), i, shap)
    return T


def svdtrunc(A, n):
    '''
    Truncated svd
    Args:
        - A: input tensor
        - n: number of modes to retain
    Returns:
        - U: POD modes
        - S: singular values
    '''
    U, S, _ = randomized_svd(A, n_components=n)
    return U, S


def func_svd(i, producto, n, U, T, UT, sv):
    n[i] = int(np.amin((n[i], producto / n[i])))
    A = unfold(T, i)
    Uaux = []

    # SVD based reduction of the current dimension (i):
    Ui, svi = svdtrunc(A, n[i])

    if n[i] < 2:
        Uaux = np.zeros((np.shape(Ui)[0], 2))
        Uaux[:, 0] = Ui[:, 0]
        U[0][i] = Uaux

    else:
        U[0][i] = Ui[:, 0:n[i]]

    UT[0][i] = np.transpose(U[0][i])
    sv[0][i] = svi


def run_parallel(*functions):
    from multiprocessing import Process
    processes = []
    for function in functions:
        proc = Process(target=function)
        proc.start()
        processes.append(proc)
    for proc in processes:
        proc.join()


def HOSVD_function(T, n):
    '''Perform hosvd to tensor'''
    P = T.ndim
    U = np.zeros(shape=(1, P), dtype=object)
    UT = np.zeros(shape=(1, P), dtype=object)
    sv = np.zeros(shape=(1, P), dtype=object)
    producto = n[0]

    for i in range(1, P):
        producto = producto * n[i]

    n = list(n)

    run_parallel([func_svd(i, producto, n, U, T, UT, sv) for i in range(0, P)])

    S = tprod(T, UT)

    Reconst = tprod(S, U)

    return S, U, sv, n, Reconst


def HOSVD(Tensor, varepsilon1, nn, n, TimePos):
    '''Perform hosvd to input data and retain all the singular values'''
    if np.iscomplex(Tensor.any()) == False:
        Tensor = Tensor.astype(np.float32)

    S, U, sv, n, Reconst = HOSVD_function(Tensor, n)

    # (automatic truncation)
    for i in range(1, np.size(nn)):
        count = 0
        for j in range(0, np.shape(sv[0][i])[0]):
            if sv[0][i][j] / sv[0][i][0] <= varepsilon1:
                pass
            else:
                count = count + 1

        nn[i] = count

    ## Perform HOSVD retaining n singular values: reconstruction of the modes
    S2, U, sv2, nn2, Reconst = HOSVD_function(Tensor, nn)

    ## Construct the reduced matrix containing the temporal modes:
    UT = np.zeros(shape=np.shape(U), dtype=object)
    hatT = []

    for pp in range(0, np.size(nn2)):
        UT[0][pp] = np.transpose(U[0][pp])

    for kk in range(0, nn2[TimePos - 1]):
        hatT.append(np.dot(sv2[0][TimePos - 1][kk], UT[0][TimePos - 1][kk, :]))

    hatT = np.reshape(hatT, newshape=(len(hatT), np.size(hatT[0])))

    return Reconst, hatT, U, S2, sv, nn2, n, U[0][-1]


def LCHOSVD(TensorRed, Tensor, esvd, nn, nn0, TimePos):
    A = Tensor.reshape((np.prod(Tensor.shape[:-1]), -1))

    Reconst, _, U, S, sv, nn1, n, _ = HOSVD(TensorRed, esvd, nn, nn0, TimePos)

    TensorReconst_hosvd = tprod(S, U)

    # Reduce dimension and perform SVD in the reduced matrix
    Ared = TensorReconst_hosvd.reshape((np.prod(TensorReconst_hosvd.shape[:-1]), -1))

    Ured, sigmared, Vred = svd(Ared, full_matrices=False)

    n = sigmared.size

    NormS = np.linalg.norm(sigmared, ord = 2)

    PODmodes = 0

    for k in range(0, n):
        if np.linalg.norm(sigmared[k:n], 2) / NormS > esvd:
            PODmodes = PODmodes + 1

    sigmared = sigmared[:PODmodes]
    Sigma = sigmared
    sigmared = np.diag(sigmared)

    Ured = Ured[:, :PODmodes]

    Vred = Vred.T
    Vred = Vred[:, :PODmodes]

    R = qr(Ured, mode='r')

    Ured = Ured @ inv(R[:PODmodes, :])
    R1 = qr(Vred, mode='r')
    Vred = Vred @ inv(R1[:PODmodes, :])

    ss = Ured.conj().T @ (Ared @ Vred)
    ss1 = np.sign(np.diag(np.diag(ss)))
    Vred = Vred @ ss1

    U = A @ (Vred @ inv(sigmared))
    V = Vred

    # Reconstruction and comparison
    Aapprox = U @ (sigmared @ V.conj().T)
    Tensor_Aapprox = Aapprox.reshape((Tensor.shape))

    return U, Sigma, V, PODmodes, Tensor_Aapprox

def compute_MSE(y_true, y_pred):
    '''
    Relative mean squared error function
    Args:
        y_true: ground truth values
        y_pred: predicted values
    Return:
        Root Mean Squared Error (RMSE)
    '''  
    return np.mean((y_true - y_pred) ** 2)

def dmd1(Ared, tensorA, deltaT, esvd, edmd, Time, points, case):
    '''First order dynamic modal decomposition:
        Input:
            - tensor (IxJ): Snapshot matrix.
            - deltaT: time step
            - n_modes: number of retained SVD modes.
            - edmd: DMD tolerance (DMD modes).
            - Time: array of selected equidistant snapshot indexes.
            - points: array of selected equidistant datapoint indexes.
            - Case: 0) if time isn't downsampled, 1) V from lcSVD is not reconstructed, 2) V from lcSVD is reconstructed.
        Output:
            -u (Ixn): mode matrix (columns) sorted from biggest to smallest amplitude, put to scale.
            -areal (n): amplitude vector (sorted) used to put u to scale.
            -eigval: eigenvalues
            -delta (n): growth rate vector.
            -omega (n): frequency vector.
            -DMDmode: Modes'''

    # Applying iterative LCHOSVD   
    if len(Ared.flatten()) < len(tensorA.flatten()):
        nn0 = Ared.shape
        nn = [nn0[0]] + [0] * (len(nn0) - 1)
        MSE_gaps = np.zeros(500)
        A_s = tensorA.copy()

        for ii in range(500):
            print(f'\nIteration number: {ii + 1}')

            U, s, Wh, kk, tensor = LCHOSVD(Ared, A_s, esvd, nn, nn0, TimePos=Ared.ndim)

            MSE_gaps[ii] = compute_MSE(tensorA, tensor)

            print(f'- Reconstruction error: {MSE_gaps[ii]:.2e}')
            if ii > 0:  
                print(f'- Error between iterations: {np.abs(MSE_gaps[ii] - MSE_gaps[ii-1]):.2e}')

            if ii >= 1:  
                if MSE_gaps[ii] >= MSE_gaps[ii-1]:  
                    A_s = tensor
                    break
                elif (MSE_gaps[ii] - MSE_gaps[ii-1]) <= 0.02*ii:  
                    break

            A_s = tensor 
        
        virTensor = np.diag(s) @ Wh.T

    else:
        U, s, Wh = truncatedSVD(tensorA.reshape(-1, tensorA.shape[-1]), esvd)
        tensor = U @ (np.diag(s) @ Wh)
        tensorA = tensorA.reshape(-1, tensorA.shape[-1])
        virTensor = np.diag(s) @ Wh

    tensor = tensor.reshape(-1, tensorA.shape[-1])

    n = s.size

    NormS = np.linalg.norm(s, ord = 2)

    kk = 0

    for k in range(0, n):
        if np.linalg.norm(s[k:n], 2) / NormS > esvd:
            kk = kk + 1

    print(f'Spatial complexity: {kk}')

    # Koopman matrix reconstruction:
    Uvir, svir, Wvirh = np.linalg.svd(virTensor[:, :-1], full_matrices = False)
    Rvir = virTensor[:, 1:] @ Wvirh.conj().T @ np.diag(svir**-1) @ Uvir.conj().T
    eigval, eigvec = np.linalg.eig(Rvir)

    # Frequencies and Growthrate:
    delta = np.log(eigval).real/deltaT
    omega = np.log(eigval).imag/deltaT

    # Amplitudes:
    A = np.zeros((Uvir.shape[0] * virTensor.shape[1], Uvir.shape[1]), dtype = np.complex64)
    b = np.zeros(Uvir.shape[0] * virTensor.shape[1], dtype=virTensor.dtype)
    for i in range(virTensor.shape[1]):
        A[i*eigvec.shape[0]:(i+1) * eigvec.shape[0], :] = eigvec @ np.diag(eigval**i)
        b[i*eigvec.shape[0]:(i+1) * eigvec.shape[0]] = virTensor[:, i]

    Ua, sa, Wa = np.linalg.svd(A, full_matrices = False)
    a = Wa.conj().T @ np.diag(sa**-1) @ Ua.conj().T @ b

    # Modes:
    uvir = eigvec @ np.diag(a)
    u = U @ uvir
    areal = np.linalg.norm(u, axis=0) / np.sqrt(np.prod(tensor.shape[:-1]))

    # Spectral complexity:
    kk3 = 0
    for m in range(np.size(areal)):
        if areal[m] / np.max(areal) <= edmd:
            pass
        else:
            kk3 += 1

    print(f'Spectral complexity: {kk3}')

    idx = np.flip(np.argsort(areal))
    u=u[:, idx]
    areal = areal[idx]
    eigval = eigval[idx]
    delta = delta[idx]
    omega = omega[idx]

    # Filter important ones:
    mask = (areal / areal[0]) > edmd

    #Mode Matrix:
    ModeMatr = np.zeros((kk3, 4))
    for i in range(kk3):
        ModeMatr[i, 0] = i + 1
        ModeMatr[i, 1] = delta[mask][i]
        ModeMatr[i, 2] = omega[mask][i]
        ModeMatr[i, 3] = areal[mask][i]

    #Calculate modes:
    u = u[:, mask]
    U = U[:, :kk]
    DMDmode = np.zeros((np.prod(tensor.shape[:-1]), kk3), dtype=np.complex64)
    Amplitude0 = np.zeros(kk3)

    """
    for m in range(kk3):
        NormMode = np.linalg.norm(np.dot(U, u[:, m]), ord=2) / np.sqrt(np.prod(tensor.shape[:-1])
        Amplitude0[m] = NormMode
        DMDmode[:, m] = np.dot(U, u[:, m]) / NormMode
    """
    Amplitude0[:kk3] = np.linalg.norm(np.dot(U.T, u[:, :kk3]), ord=2) / np.sqrt(np.prod(tensor.shape[:-1]))
    DMDmode[:, :kk3] = u[:, :kk3] / Amplitude0[:kk3]

    return u, areal[mask], eigval[mask], delta[mask], omega[mask], DMDmode

def lcHODMD1(Ared, tensorA, d, deltaT, T, esvd, edmd, Time, points, case):
    '''Low-cost Higher order dynamic mode decomposition (lcHODMD):
        Input:
            - tensor (IxJ): snapshot matrix.
            - d: parameter of DMD-d, higher order Koopman assumption (int>=1).
            - deltaT: time step.
            - n_modes: number of retained singular values.
            - edmd: DMD tolerance (DMD-d modes).
            - Time: array of selected equidistant snapshot indexes.
            - points: array of selected equidistant datapoint indexes.
            - Case: 0) if time isn't downsampled, 1) V from lcSVD is not reconstructed, 2) V from lcSVD is reconstructed.
        Output:
            -u (Ixn): mode matrix (columns) sorted from biggest to smallest amplitude. Scaled.
            -areal (n): amplitude vector (sorted) used to scale u.
            -eigval: eigenvalues
            -delta (n): growth rate vector.
            -omega (n): frequency vector.
            -DMDmode: Modes'''

    # Applying iterative LCHOSVD   
    if len(Ared.flatten()) < len(tensorA.flatten()):
        nn0 = Ared.shape
        nn = [nn0[0]] + [0] * (len(nn0) - 1)
        MSE_gaps = np.zeros(500)
        A_s = tensorA.copy()

        for ii in range(500):
            print(f'\nIteration number: {ii + 1}')

            U, s, Wh, kk, tensor = LCHOSVD(Ared, A_s, esvd, nn, nn0, TimePos=Ared.ndim)

            MSE_gaps[ii] = compute_MSE(tensorA, tensor)

            print(f'- Reconstruction error: {MSE_gaps[ii]:.2e}')
            if ii > 0:  
                print(f'- Error between iterations: {np.abs(MSE_gaps[ii] - MSE_gaps[ii-1]):.2e}')

            if ii >= 10:  
                if MSE_gaps[ii] >= MSE_gaps[ii-1]:  
                    A_s = tensor
                    break
                elif (MSE_gaps[ii] - MSE_gaps[ii-1]) <= 0.02*ii:  
                    break

            # if ii >= 3:  
            #     if abs(MSE_gaps[ii] - MSE_gaps[ii-1]) <= 1e-7:  
            #         break

            A_s = tensor 
        
        virTensor = np.diag(s) @ Wh.T

    else:
        U, s, Wh = truncatedSVD(tensorA.reshape(-1, tensorA.shape[-1]), esvd)
        tensor = U @ (np.diag(s) @ Wh)
        tensorA = tensorA.reshape(-1, tensorA.shape[-1])
        virTensor = np.diag(s) @ Wh

    tensor = tensor.reshape(-1, tensorA.shape[-1])

    n = s.size

    NormS = np.linalg.norm(s, ord = 2)

    kk = 0

    for k in range(0, n):
        if np.linalg.norm(s[k:n], 2) / NormS > esvd:
            kk = kk + 1

    print(f'Spatial complexity: {kk}')

    # Reduced and grouped snapshots:
    dotTensor = np.zeros((d * n, virTensor.shape[1] - d + 1), dtype = virTensor.dtype)
    for j in range(d):
        dotTensor[j * n:(j + 1) * n, :] = virTensor[:, j:virTensor.shape[1] - d + j + 1]

    # Reduced, grouped and again reduced snapshots:
    Udot, sdot, Whdot = np.linalg.svd(dotTensor, full_matrices = False)
    n_modes = 0
    norm_ = np.linalg.norm(sdot)

    for i in range(sdot.size):
        if np.linalg.norm(sdot[i:]) / norm_ <= esvd:
            pass
        else:
            n_modes += 1

    Udot = Udot[:, :n_modes]
    sdot = sdot[:n_modes]
    Whdot = Whdot[:n_modes, :]

    vdTensor = np.diag(sdot) @ Whdot

    # Spatial dimension reduction:
    print(f'Spatial dimension reduction: {np.size(sdot)}')

    # Koopman matrix reconstruction:
    Uvd, svd, Whvd = np.linalg.svd(vdTensor[:, :-1], full_matrices=False)
    Rvd = vdTensor[:, 1:] @ Whvd.conj().T @ np.diag(svd**-1) @ Uvd.conj().T
    eigval, eigvec = np.linalg.eig(Rvd)

    # Frequencies and growthrate:
    delta = np.log(eigval).real / deltaT
    omega = np.log(eigval).imag / deltaT

    # Modes
    q = (Udot @ eigvec)[(d - 1) * n:d * n, :]
    Uvir = q / np.linalg.norm(q, axis=0)

    # Amplitudes:
    A = np.zeros((Uvir.shape[0] * virTensor.shape[1], Uvir.shape[1]), dtype = np.complex64)
    b = np.zeros(Uvir.shape[0] * virTensor.shape[1], dtype=virTensor.dtype)
    for i in range(virTensor.shape[1]):
        A[i * Uvir.shape[0]:(i + 1) * Uvir.shape[0], :] = Uvir @ np.diag(eigval**i)
        b[i * Uvir.shape[0]:(i + 1) * Uvir.shape[0]] = virTensor[:, i]
    Ua, sa, Wa = np.linalg.svd(A, full_matrices=False)
    a = Wa.conj().T @ np.diag(sa**-1) @ Ua.conj().T @ b

    # Modes
    uvir = Uvir @ np.diag(a)
    u = U @ uvir
    areal = np.linalg.norm(u, axis=0) / np.sqrt(np.prod(tensor.shape[:-1]))

    #Spectral complexity:
    kk3 = 0
    for m in range(0, np.size(areal)):
        if areal[m] / np.max(areal) <= edmd:
            pass
        else:
            kk3 += 1
    print(f'Spectral complexity: {kk3}')
    spectr_min1.append(kk3)
    print(spectr_min1)

    idx = np.flip(np.argsort(areal))
    u = u[:, idx]
    areal = areal[idx]
    eigval = eigval[idx]
    delta = delta[idx]
    omega = omega[idx]
    # Filter important ones:
    mask = (areal / areal[0]) > edmd

    # Mode Matrix:
    ModeMatr = np.zeros((kk3, 4))
    for i in range(kk3):
        ModeMatr[i, 0] = i + 1
        ModeMatr[i, 1] = delta[mask][i]
        ModeMatr[i, 2] = omega[mask][i]
        ModeMatr[i, 3] = areal[mask][i]

    # Calculate DMD modes:
    u = u[:, mask]
    U = U[:, :kk]
    DMDmode = np.zeros((np.prod(tensor.shape[:-1]), kk3), dtype=np.complex64)

    Amplitude0 = np.zeros(kk3)
    Amplitude0[:kk3] = np.linalg.norm(np.dot(U.T, u[:, :kk3]), ord=2) / np.sqrt(np.prod(tensor.shape[:-1]))
    DMDmode[:, :kk3] = u[:, :kk3] / Amplitude0[:kk3]

    return u, areal[mask], eigval[mask], delta[mask], omega[mask], DMDmode

def lcHODMD(Ared, tensorA, d, deltaT, T, esvd, edmd, Time, points, case):
    '''Low-cost Higher order dynamic mode decomposition (lcHODMD):
        Input:
            - tensor (IxJ): snapshot matrix.
            - d: parameter of DMD-d, higher order Koopman assumption (int>=1).
            - deltaT: time step.
            - n_modes: number of retained singular values.
            - edmd: DMD tolerance (DMD-d modes).
            - Time: array of selected equidistant snapshot indexes.
            - points: array of selected equidistant datapoint indexes.
            - Case: 0) if time isn't downsampled, 1) V from lcSVD is not reconstructed, 2) V from lcSVD is reconstructed.
        Output:
            -u (Ixn): mode matrix (columns) sorted from biggest to smallest amplitude. Scaled.
            -areal (n): amplitude vector (sorted) used to scale u.
            -eigval: eigenvalues
            -delta (n): growth rate vector.
            -omega (n): frequency vector.
            -DMDmode: Modes'''

    # Applying lcSVD
    print()
    if Ared.reshape(-1, 1).shape != tensorA.reshape(-1, 1).shape:
        U, s, Wh, kk, tensor = lcSVD(Ared, tensorA, esvd, Time, points, case)

        virTensor = np.diag(s) @ Wh.T

        n = s.size

    else:
        U, s, Wh = truncatedSVD(Ared, esvd)

        tensor = tensorA.reshape(-1, tensorA.shape[-1])

        virTensor = np.diag(s) @ Wh

        n = s.size

        NormS = np.linalg.norm(s, ord=2)
        kk = 0
        for k in range(0, n):
            if np.linalg.norm(s[k:n], 2) / NormS > esvd:
                kk = kk + 1

    print(f'Spatial complexity: {kk}')

    # Reduced and grouped snapshots:
    dotTensor = np.zeros((d * n, virTensor.shape[1] - d + 1), dtype = virTensor.dtype)
    for j in range(d):
        dotTensor[j * n:(j + 1) * n, :] = virTensor[:, j:virTensor.shape[1] - d + j + 1]

    # Reduced, grouped and again reduced snapshots:
    Udot, sdot, Whdot = np.linalg.svd(dotTensor, full_matrices = False)
    n_modes = 0
    norm_ = np.linalg.norm(sdot)
    for i in range(sdot.size):
        if np.linalg.norm(sdot[i:]) / norm_ <= esvd:
            pass
        else:
            n_modes += 1

    Udot = Udot[:, :n_modes]
    sdot = sdot[:n_modes]
    Whdot = Whdot[:n_modes, :]

    vdTensor = np.diag(sdot) @ Whdot

    # Spatial dimension reduction:
    print(f'Spatial dimension reduction: {np.size(sdot)}')

    # Koopman matrix reconstruction:
    Uvd, svd, Whvd = np.linalg.svd(vdTensor[:, :-1], full_matrices=False)
    Rvd = vdTensor[:, 1:] @ Whvd.conj().T @ np.diag(svd**-1) @ Uvd.conj().T
    eigval, eigvec = np.linalg.eig(Rvd)

    # Frequencies and growthrate:
    delta = np.log(eigval).real / deltaT
    omega = np.log(eigval).imag / deltaT

    # Modes
    q = (Udot @ eigvec)[(d - 1) * n:d * n, :]
    Uvir = q / np.linalg.norm(q, axis=0)

    # Amplitudes:
    A = np.zeros((Uvir.shape[0] * virTensor.shape[1], Uvir.shape[1]), dtype = np.complex64)
    b = np.zeros(Uvir.shape[0] * virTensor.shape[1], dtype=virTensor.dtype)
    for i in range(virTensor.shape[1]):
        A[i * Uvir.shape[0]:(i + 1) * Uvir.shape[0], :] = Uvir @ np.diag(eigval**i)
        b[i * Uvir.shape[0]:(i + 1) * Uvir.shape[0]] = virTensor[:, i]
    Ua, sa, Wa = np.linalg.svd(A, full_matrices=False)
    a = Wa.conj().T @ np.diag(sa**-1) @ Ua.conj().T @ b

    # Modes
    uvir = Uvir @ np.diag(a)
    u = U @ uvir
    areal = np.linalg.norm(u, axis=0) / np.sqrt(np.prod(tensor.shape[:-1]))

    #Spectral complexity:
    kk3 = 0
    for m in range(0, np.size(areal)):
        if areal[m] / np.max(areal) <= edmd:
            pass
        else:
            kk3 += 1
    print(f'Spectral complexity: {kk3}')
    spectr_min1.append(kk3)
    print(spectr_min1)

    idx = np.flip(np.argsort(areal))
    u = u[:, idx]
    areal = areal[idx]
    eigval = eigval[idx]
    delta = delta[idx]
    omega = omega[idx]
    # Filter important ones:
    mask = (areal / areal[0]) > edmd

    # Mode Matrix:
    ModeMatr = np.zeros((kk3, 4))
    for i in range(kk3):
        ModeMatr[i, 0] = i + 1
        ModeMatr[i, 1] = delta[mask][i]
        ModeMatr[i, 2] = omega[mask][i]
        ModeMatr[i, 3] = areal[mask][i]

    # Calculate DMD modes:
    u = u[:, mask]
    U = U[:, :kk]
    DMDmode = np.zeros((np.prod(tensor.shape[:-1]), kk3), dtype=np.complex64)

    Amplitude0 = np.zeros(kk3)
    Amplitude0[:kk3] = np.linalg.norm(np.dot(U.T, u[:, :kk3]), ord=2) / np.sqrt(np.prod(tensor.shape[:-1]))
    DMDmode[:, :kk3] = u[:, :kk3] / Amplitude0[:kk3]

    return u, areal[mask], eigval[mask], delta[mask], omega[mask], DMDmode

# 1. HODMD parameters

# 1.1. Load the high-res tensor

def display_options_and_get_choice():
    options = [
        " 1: Laminar 2D cylinder (Re=100)",
        " 2: Laminar 3D cylinder (Re=280)",
        " 3: Turbulent cylinder (Re=4000)",
        " 4: Laminar co flow flame",
        " 5: Turbulent bluff body stabilized hydrogen flame",
        " 6: Exit"
    ]

    # Display the options
    for i, option in enumerate(options, start=1):
        print(f"{i}. {option}")

    # Get user input 
    while True:
        try:
            choice = int(input("Please enter the number of your choice: "))
            if 1 <= choice <= len(options):
                return choice
            else:
                print(f"Please enter a number between 1 and {len(options)}.")
        except ValueError:
            print("Invalid input. Please enter a valid number.")

user_choice = display_options_and_get_choice()

""" Loading 3d laminar cylinder dataset"""
import h5py

if user_choice==2:
    filename = 'C:/Users/praji/OneDrive/Desktop/Spain/Encoding/combustion/data_assimilation/Tensor.mat'
    with h5py.File(filename, 'r') as mat_file:
        # List all available variables in the file
        print("Available variables:", list(mat_file.keys()))
    
        # Access the specific variable (e.g., 'DeltasOmegAmplTemporal')
        #data = mat_file['DeltasOmegAmplTemporal'][:]
    
        # Convert the extracted data to a NumPy array (tensor)
        tensor_n = np.array(mat_file['Tensor'][...])
    
    
    
        tensor_n= np.swapaxes(tensor_n,0,4)
        tensor_n= np.swapaxes(tensor_n,1,3)
        tensor_n= np.swapaxes(tensor_n,1,2)
        tensor_pp=tensor_n[ :, :, :, :, -99:] 
    deltaT=1

elif user_choice==1:

    """ Loading 2d laminar cylinder dataset"""
    
    
    from scipy.io import loadmat
    
    file_path = 'C:/Users/praji/OneDrive/Desktop/Spain/Encoding/combustion/other_datasets/Tensor_cylinder_Re100.mat'
    data = loadmat(file_path)
    print(data.keys())
    tensor_n1 = np.array(data['Tensor'][...])
    tensor_pp=tensor_n1
    deltaT=0.2

elif user_choice==3:
# Tensor = loadVKIcyl()[..., ::3].astype(np.complex64)
    #Tensor = loadJetsLES()
    """ Loading 2d turbulent cylinder dataset"""
    
    from scipy.io import loadmat
    
    file_path = 'C:/Users/praji/OneDrive/Desktop/Spain/Encoding/combustion/other_datasets/VKI_Re4000.mat'
    with h5py.File(file_path, 'r') as mat_file:
        # List all available variables in the file
        print("Available variables:", list(mat_file.keys()))
    
        # Access the specific variable (e.g., 'DeltasOmegAmplTemporal')
        #data = mat_file['DeltasOmegAmplTemporal'][:]
    
        # Convert the extracted data to a NumPy array (tensor)
        tensor_n2 = np.array(mat_file['Tensor'][...])
        print(tensor_n2.shape)
        tensor_n2=np.swapaxes(tensor_n2,1,2)
        tensor_n2=np.swapaxes(tensor_n2,0,3)
        tensor_pp = tensor_n2[:, :, :, -400:]
    deltaT=0.33

elif user_choice==4:
    tensor_orig_temp = np.load('C:/Users/praji/OneDrive/Desktop/Spain/Encoding/combustion/work_directory/data.npy')
    data=np.array(tensor_orig_temp)
    unscaled_data=data   
    data=unscaled_data
    nva,nxa,nya,nta=np.shape(data)
    components1 = ["$T$","$O$","$O_2$","$OH$","$H_2O$","$CH_4$","$CO$","$CO_2$","$C_2H_2$","$N_2$"]
    # swapping axes to change shape from (nv,nx,ny,nt) to (nt,ny,nx,nv)
    #data=np.swapaxes(data,3,0)                
    #data=np.swapaxes(data,1,2)
    key=0
    nv, ny, nx, nt = np.shape(data)
    print(f'No of timesteps: {nt}')
    print(f'No of points in grid (Y): {ny}')
    print(f'No of points in grid (X): {nx}')
    print(f'No of variables: {nv}')
    for i in range(nva):
        contour=plt.contourf(data[i,:,:,100])
        colorbar = plt.colorbar(contour)
        plt.xlabel('X')
        plt.ylabel('Y')
        plt.title(f"{components1[i]}")
        plt.show()
    #data = np.swapaxes(data,0,3)
    #data = np.swapaxes(data,1,2) 
    data=data[:,:,:,-201:]
    tensor_pp,Factor,Media,Media_tiempo=centering_scaling(data)
    #tensor_pp=data
    deltaT=2.5e-4
   
elif user_choice==5:
    hf=h5py.File('C:/Users/praji/OneDrive/Desktop/Spain/Encoding/combustion/lcsvd/Data.h5', 'r')
    data0 = hf.get('Flow/Hot/u')
    data01 = hf.get('Flow/Hot/v')
    data0=np.array(data0[:,25:,25:105])
    data0=np.reshape(data0,(2000,84,80,1))
    data01=np.array(data01[:,25:,25:105])
    data01=np.reshape(data01,(2000,84,80,1))
    data_fin0 = np.concatenate([data0,data01],axis=3)  
    data=data_fin0
    nta,nxa,nya,nva=np.shape(data)
    components = ['Velocity(u)', 'Velocity(v)']
    key=1

    for i in range(nva):
        contour=plt.contourf(data[100,:,:,i])
        colorbar = plt.colorbar(contour)
        plt.xlabel('X')
        plt.ylabel('Y')
        plt.title(f"{components[i]}")
        plt.show()
    #data1=data_fin
    data_fin0 = np.swapaxes(data_fin0,0,3)
    data_fin0=np.swapaxes(data_fin0,1,2)                # uncomment for turbulent without normalisation
    print(np.shape(data_fin0))
    nv, ny, nx, nt = np.shape(data_fin0)
    print(f'No of timesteps: {nt}')
    print(f'No of points in grid (Y): {ny}')
    print(f'No of points in grid (X): {nx}')
    print(f'No of variables: {nv}')
    data=data_fin0
    data=data[:,:,:,-200:]
    tensor_pp,Factor,Media,Media_tiempo=centering_scaling(data)
    #tensor_pp=data
    deltaT=0.01
   
else: 
   exit()




""" Change to use different dataset"""

#Tensor=tensor_n[ :, :, :, :, -99:]                 
Tensor=tensor_pp              



print(np.shape(Tensor))

# 1.2. Select the number of snapshots to use
# n_snap = 1294
n_snap = Tensor.shape[-1]

# 1.3. Select the window size (tested and OK with d = 1)
def display_options_and_get_choice3():
    options = [
        " 1: Calibrate",
        " 2: Dont Calibrate (Use inbuit d)"
    ]

    # Display the options
    for i, option in enumerate(options, start=1):
        print(f"{i}. {option}")

    # Get user input 
    while True:
        try:
            choice = int(input("Please enter the number of your choice: "))
            if 1 <= choice <= len(options):
                return choice
            else:
                print(f"Please enter a number between 1 and {len(options)}.")
        except ValueError:
            print("Invalid input. Please enter a valid number.")

user_choice3=display_options_and_get_choice3()
if user_choice3==1:
    calibrate = True
else:
    calibrate = False

if calibrate:
    #d_list = [int(n_snap / i) for i in range(2, 21)]
    #case_d = [f'd / {i}' for i in range(2, 21)]
    d_list = [10,20,30, 50, 75,100,150,200]
    case_d = [10,20,30, 50, 75,100, 150,200]

else:
    if user_choice==1:
    #d = int(n_snap / 20) # or d = int(snap / 2)
        d = 30
    elif user_choice==2:
        d=30
    elif user_choice==3:
        d=100
    elif user_choice==4:
        d=30
    else:
        d=10

def get_tolerance():
    # Display the prompt to enter the tolerance value
    print("Enter the tolerance:")
    
    # Get user input and validate as a float
    while True:
        try:
            tol = float(input("Tolerance: "))
            return tol
        except ValueError:
            print("Invalid input. Please enter a decimal value.")

# Assign the tolerance value to `tol`
tol = get_tolerance()
print("The tolerance value is:", tol)

# 1.4. Select the SVD tolerance (used for lcSVD and truncated SVD) (Spatial complexity)
esvd = tol

# 1.5. Select the DMD tolerance (Spectral complexity)
edmd = tol

# 1.6. Select the time step between snapshots

print("The timestep value is:", deltaT)

# 1.8. Reshaping the input tensor into a JxK matrix, where J = j1, j2, ..., jn, is the spatial data (j1 = nv, j2 = ny, j3 = nx, ...), and K is the total number of snapshots
shape = Tensor.shape
dims = Tensor.ndim

# 1.9 Other parameters
def get_sensor_size():
    # Display the prompt to enter the sensor (downsample) size
    print("Enter the sensor size (downsampled) :")
    
    # Get user input and validate as a float
    while True:
        try:
            datapoints = int(input("Sensor (downsample) size: "))
            return datapoints
        except ValueError:
            print("Invalid input. ")

# Assign the sensor (downsample) size to `datapoints`
datapoints = get_sensor_size()
print("The sensor (downsample) size is:", datapoints)

# snapshots = n_snap
snapshots = n_snap

def display_options_and_get_choice1():
    options = [
        " 1: Equally spaced",
        " 2: Optimum sensors"
    ]

    # Display the options
    for i, option in enumerate(options, start=1):
        print(f"{i}. {option}")

    # Get user input 
    while True:
        try:
            choice = int(input("Please enter the number of your choice: "))
            if 1 <= choice <= len(options):
                return choice
            else:
                print(f"Please enter a number between 1 and {len(options)}.")
        except ValueError:
            print("Invalid input. Please enter a valid number.")

dataOption = display_options_and_get_choice1()

"""
Option 1. Data points are equidistantly distributed

Option 2. Data points set using optimal sensor placement
"""

# NEW TEST
if dataOption == 1:
    points = list(np.linspace(0, np.prod(Tensor.shape[:-1]) - 1, datapoints).astype(int))  # Selected "points" equidistant data points from J

else:
    points = OS_lcSVD(Tensor, datapoints, esvd)

Time = list(np.linspace(0, Tensor.shape[-1] - 1, snapshots).astype(int)) # Selects "snapshots" equidistant snapshots from the temporal data K

Ared = np.reshape(Tensor, (np.prod(Tensor.shape[:-1]), Tensor.shape[-1]))
Ared = Ared[points, :]

if user_choice==4 or user_choice==5:
    Media_tiempo1 = np.reshape(Media_tiempo, (np.prod(Media_tiempo.shape[:-1]), Media_tiempo.shape[-1]))
    Media_tiempo1=Media_tiempo1[points,:]
else:
    print("NO CENTERING AND SCALING")


if len(Time) < Tensor.shape[-1]:
    Ared = Ared[:, Time]

recons = []
modescases = []
amps = []
freqs = []
grs = []
spectr_min=[]
spectr_min1=[]



Ten = Tensor.reshape((-1, Tensor.shape[-1]))

compare = True

def display_options_and_get_choice5():
    options = [
        " 1: lcHODMD(lcsvd inside)",
        " 2: Multi-dimensional iterative lcHODMD (lchosvd inside)"
    ]

    # Display the options
    for i, option in enumerate(options, start=1):
        print(f"{i}. {option}")

    # Get user input 
    while True:
        try:
            choice = int(input("Please enter the number of your choice: "))
            if 1 <= choice <= len(options):
                return choice
            else:
                print(f"Please enter a number between 1 and {len(options)}.")
        except ValueError:
            print("Invalid input. Please enter a valid number.")

user_choice5 = display_options_and_get_choice5()

def display_options_and_get_choice6():
    options = [
        " 1: Clean spectrum",
        " 2: Complete spectrum"
    ]

    # Display the options
    for i, option in enumerate(options, start=1):
        print(f"{i}. {option}")

    # Get user input 
    while True:
        try:
            choice = int(input("Please enter the number of your choice: "))
            if 1 <= choice <= len(options):
                return choice
            else:
                print(f"Please enter a number between 1 and {len(options)}.")
        except ValueError:
            print("Invalid input. Please enter a valid number.")

user_choice6 = display_options_and_get_choice6()

if compare:
    data = [Ten, Ared]
    case_data = ['Downsampled tensor', 'Original tensor']
    numSnaps = [Tensor.shape[-1], n_snap]

else:
    data = [Ared]
    case_data = ['Downsampled tensor']
    numSnaps = [n_snap]

cs=0


if not calibrate:
    if compare:
        for i, Ared, n_snap in zip(range(len(data)), data, numSnaps):
            print(case_data[i])

            # Reconstruction case
            """
            Case 0. K is not reduced, meaning all snapshots are available
            
            Case 1. When applying lcSVD inside lcHODMD on a tensor with snapshots < K, then lcSVD returns Vred, which is V for the downsampled dataset
                        """

            caseList = ['Case 0: Time component has not been downsampled', 'Case 1: Time component downsampled. V not reconstructed when applying lcSVD',
                        'Case 1: Time component downsampled. V has not been reconstructed when applying lcSVD']

            if n_snap == Tensor.shape[-1]:
                case = 0

            else:
                case = 1 # 1 o 2

            if case == 0:
                T = np.linspace(0, Tensor.shape[-1] - 1, num = Tensor.shape[-1]) * deltaT

            elif case == 1:
                T = np.linspace(0, n_snap - 1, num = n_snap) * deltaT

            print(caseList[case])

            # 2. Applying lcHODMD (if the window size is 1 -> lcDMD, else -> lcHODMD)
            if d == 1:
                t0 = time.time()
                u, Amplitude, Eigval, GrowthRate, Frequency, DMDmode = dmd1(Ared, Tensor, deltaT, esvd, edmd, Time, points, case)
                icomp = complex(0, 1)
                mu=np.zeros(np.size(GrowthRate), dtype=np.complex64)
                for i in range(np.size(GrowthRate)):
                    mu[i] = np.exp(np.dot(deltaT, GrowthRate[i] + np.dot(icomp, Frequency[i])))
                Reconst = reconstruct(u, T, mu)
                t1 = time.time()

                print(f'lcDMD completed in {np.round(t1 - t0, 3)} seconds')

            else:
                if user_choice5==1:
                    t0 = time.time()
                    u, Amplitude, Eigval, GrowthRate, Frequency, DMDmode = lcHODMD(Ared, Tensor, d, deltaT, T, esvd, edmd, Time, points, case)
                    icomp = complex(0, 1)
                    mu = np.zeros(np.size(GrowthRate), dtype = np.complex64)
                    for i in range(np.size(GrowthRate)):
                        mu[i] = np.exp(np.dot(deltaT, GrowthRate[i] + np.dot(icomp, Frequency[i])))
                    Reconst = reconstruct(u, T, mu)
                    t1 = time.time()
    
                    print(f'lcHODMD completed in {np.round(t1 - t0, 3)} seconds')
                else:
                    t0 = time.time()
                    u, Amplitude, Eigval, GrowthRate, Frequency, DMDmode = lcHODMD1(Ared, Tensor, d, deltaT, T, esvd, edmd, Time, points, case)
                    icomp = complex(0, 1)
                    mu = np.zeros(np.size(GrowthRate), dtype = np.complex64)
                    for i in range(np.size(GrowthRate)):
                        mu[i] = np.exp(np.dot(deltaT, GrowthRate[i] + np.dot(icomp, Frequency[i])))
                    Reconst = reconstruct(u, T, mu)
                    t1 = time.time()
    
                    print(f'lcHODMD completed in {np.round(t1 - t0, 3)} seconds')

            amps1=[]
            freqs1=[]
            modescases2=[]
            amps.append(Amplitude)
            freqs.append(Frequency)
            grs.append(GrowthRate)
            
            #print(grs)

            # 3. RRMS error and other reconstruction error metrics (UQ)
            # Reconst, which is the reconstruction matrix JxK is reshaped so that its shape matches Tensor (nv, nx, ny, ..., snapshots)
            newshape = []

            newshape.append(shape[:-1])
            newshape.append(DMDmode.shape[-1])
            print(DMDmode.shape)
            newshape = list(newshape[0]) + [newshape[1]]

            DMDmode = np.reshape(DMDmode, np.array(newshape))

            shape1 = []

            shape1.append(shape[:-1])
            shape1.append(Reconst.shape[-1])

            shape1 = list(shape1[0]) + [shape1[1]]

            Reconst = np.reshape(Reconst, np.array(shape1))

            recons.append(Reconst)
            modescases.append(DMDmode)

            amps1.append(Amplitude)
            freqs1.append(Frequency)
            modescases2.append(DMDmode)  
            if user_choice6==1:
                cs=cs+1
                amp_temp=np.array(amps1)
                freq_temp=np.array(freqs1)
                DMDmode1=np.array(modescases2)
                cleaning_spectrum(amp_temp,freq_temp,DMDmode1,d,tol,cs)
    
            else:
                print("Performing complete raw analysis")
                
            if case == 1 and i < 1:
                RRMSE = np.linalg.norm(np.reshape(Tensor[..., Time] - Reconst, newshape = (np.size(Tensor[..., Time]), 1)), ord=2) / np.linalg.norm(np.reshape(Tensor[..., Time], newshape = (np.size(Tensor[..., Time]), 1)))

            else:
                RRMSE = np.linalg.norm(np.reshape(Tensor - Reconst, newshape=(np.size(Tensor), 1)), ord=2) / np.linalg.norm(np.reshape(Tensor, newshape=(np.size(Tensor), 1)))

            print(f'\nRRMS error made in the during reconstruction: {np.round(RRMSE * 100, 3)}%\n')

            if i < 1:
                print(f'Input data shape: {Ared.shape}')
                print(f'Output data shape: {Reconst.shape}')
                if case in [0, 2]:
                    print(f'Objective data shape: {Tensor.shape}')
                
       
         # 4. Result graphs/plots
        plt.figure(num='CLOSE TO CONTINUE RUN - Frequency/GrowthRate', figsize = (10, 10))
        plt.plot(freqs[0], grs[0], 'bs', markersize = 14)
        plt.plot(freqs[1], grs[1], 'ro', markersize = 14, alpha = 0.5)
        if any(grs[1]) > 0:
            plt.yscale('log')
        plt.xlabel(r'Frequency ($\omega_{n}$)')
        plt.ylabel(r'GrowthRate ($\delta_{n}$)')
        #plt.legend(loc = 'best')
        plt.show()

            
        plt.figure(num='CLOSE TO CONTINUE RUN - Frequency/Amplitude', figsize = (10, 10))
        plt.plot(freqs[0], amps[0]/ np.amax(amps[0]),'bs', markersize = 14)
        plt.plot(freqs[1], amps[1] / np.amax(amps[1]), 'ro', markersize=14, alpha = 0.5)
        if any(amps[1]) > 0:
            plt.yscale('log')           # Logarithmic scale in y axis
        plt.xlabel(r'Frequency ($\omega_{n}$)')
        plt.ylabel(r'Amplitude divided by max. amplitude ($a_{n}$)')
        #plt.legend(loc='best')
        plt.show()
        # First DMD mode plots
        
        check=min(spectr_min1)
        
        
        if check >= 5:
            check = 5
        else:
            print ("Comparing first {check} modes")
            
        for DMDmode, tc in zip(modescases, case_data):
            DMDm = DMDmode
            print(DMDm.shape)
            for j in range(check):
                if DMDmode.ndim == 5:
                    nz = int(DMDmode.shape[-2] / 2)

            

                if DMDm.ndim <= 4:
                    for i in range(DMDm.shape[0]):
                        fig, ax = plt.subplots(1, 3, gridspec_kw={'width_ratios': [25, 25, 1]}, figsize=(10, 5))
                        #fig.suptitle(f'{tc} - DMD mode {j + 1} (Slice {i + 1})')
                
                        # Titles for subplots
                        #ax[0].set_title('Real part')
                        #ax[1].set_title('Imaginary part')
                
                        # Plot the real part
                        if user_choice==4 or user_choice==5:
                            im = ax[0].contourf(DMDm[i, ..., j].real)#*(Factor[i])+Media[i])+Media_tiempo[i,:,:,j]
                        else:
                            im = ax[0].contourf(DMDm[i, ..., j].real)

                        # Plot the imaginary part
                        if user_choice==4 or user_choice==5:
                            ax[1].contourf(DMDm[i, ..., j].imag)#*(Factor[i])+Media[i])+Media_tiempo[i,:,:,j])
                        else:
                            ax[1].contourf(DMDm[i, ..., j].imag)
                        # Add colorbar
                        plt.colorbar(im, cax=ax[2])
                
                        # Remove axis ticks
                        ax[0].set(xticks=[], yticks=[])
                        ax[1].set(xticks=[], yticks=[])
                
                        # Set axis labels
                        ax[0].set_ylabel('Y')
                        ax[0].set_xlabel('X')
                        ax[1].set_xlabel('X')
                
                        # Show the plot for each slice
                        plt.show()

                        
                    
                else:

                    for i in range(DMDm.shape[0]):
                        # Create a new figure and set of subplots for each slice
                        fig, ax = plt.subplots(1, 3, gridspec_kw={'width_ratios': [25, 25, 1]}, figsize=(10, 5))
                        #fig.suptitle(f'{tc} - DMD mode {j + 1} (Slice {i + 1})')
                
                        # Titles for subplots
                        #ax[0].set_title('Real part')
                        #ax[1].set_title('Imaginary part')
                
                        # Plot the real part
                        im = ax[0].contourf(DMDm[i, ..., nz, j].real)
                        # Plot the imaginary part
                        ax[1].contourf(DMDm[i, ..., nz, j].imag)
                        # Add colorbar
                        plt.colorbar(im, cax=ax[2])
                
                        # Remove axis ticks
                        ax[0].set(xticks=[], yticks=[])
                        ax[1].set(xticks=[], yticks=[])
                
                        # Set axis labels
                        ax[0].set_ylabel('Y')
                        ax[0].set_xlabel('X')
                        ax[1].set_xlabel('X')
                
                        # Show the plot for the current slice
                        plt.show()


        fig, ax = plt.subplots()

        print(modescases[0].shape, modescases[0].ndim)
        DMDlr = modescases[0]
        DMDhr = modescases[1]
        check1=min(DMDlr.shape[-1],DMDhr.shape[-1])
        for j in range(check):
            if Tensor.ndim == 5:
                nz = int(modescases[0].shape[-2] / 2)
                
            DMDlr = modescases[0]
            DMDhr = modescases[1]
                #print(np.abs(DMDlr[..., nz, j].real - DMDhr[..., nz, j].real).shape)




            if DMDlr.ndim <= 4:
                for i in range(DMDlr.shape[0]):
                    # Create a new figure and set of subplots for each slice
                    fig, ax = plt.subplots(1, 3, gridspec_kw={'width_ratios': [25, 25, 1]}, figsize=(10, 5))
                    #fig.suptitle(f'DMD mode {j + 1} - Absolute error (Slice {i + 1})')
                
                    # Titles for subplots
                    #ax[0].set_title('Real part')
                    #ax[1].set_title('Imaginary part')
                
                    # Plot the absolute error between the real parts
                    im = ax[0].contourf(np.abs(DMDlr[i, ..., j].real - DMDhr[i, ..., j].real))
                    # Plot the absolute error between the imaginary parts
                    ax[1].contourf(np.abs(DMDlr[i, ..., j].imag - DMDhr[i, ..., j].imag))
                    # Add colorbar
                    plt.colorbar(im, cax=ax[2])
                
                    # Remove axis ticks
                    ax[0].set(xticks=[], yticks=[])
                    ax[1].set(xticks=[], yticks=[])
                
                    # Set axis labels
                    ax[0].set_ylabel('Y')
                    ax[0].set_xlabel('X')
                    ax[1].set_xlabel('X')
                
                    # Show the plot for the current slice
                    plt.show()

                

            else:

                for i in range(DMDlr.shape[0]):
                    # Create a new figure and set of subplots for each slice
                    fig, ax = plt.subplots(1, 3, gridspec_kw={'width_ratios': [25, 25, 1]}, figsize=(10, 5))
                    #fig.suptitle(f'DMD mode {j + 1} - Absolute error (Slice {i + 1})')
                
                    # Titles for subplots
                    #ax[0].set_title('Real part')
                    #ax[1].set_title('Imaginary part')
                
                    # Plot the absolute error between the real parts
                    im = ax[0].contourf(np.abs(DMDlr[i, ..., nz, j].real - DMDhr[i, ..., nz, j].real))
                    # Plot the absolute error between the imaginary parts
                    ax[1].contourf(np.abs(DMDlr[i, ..., nz, j].imag - DMDhr[i, ..., nz, j].imag))
                    # Add colorbar
                    plt.colorbar(im, cax=ax[2])
                
                    # Remove axis ticks
                    ax[0].set(xticks=[], yticks=[])
                    ax[1].set(xticks=[], yticks=[])
                
                    # Set axis labels
                    ax[0].set_ylabel('Y')
                    ax[0].set_xlabel('X')
                    ax[1].set_xlabel('X')
                
                    # Show the plot for the current slice
                    plt.show()

            check=DMDhr.shape[-1]
    # Reconstruction plots for the max absolute error snapshot for each velocity component
    for i, Reconst, tc in zip(range(len(recons)), recons, case_data):
        if i == 0:
            if case == 1:
                Tensor0 = Tensor[..., Time].copy()
            else:
                Tensor0 = Tensor.copy()
        else:
            Tensor0 = Tensor.copy()

        if Reconst.ndim == 5:
            erroru = np.abs(Tensor0[0, ...] - Reconst[0, ...])
            errorv = np.abs(Tensor0[1, ...] - Reconst[1, ...])
            errorw = np.abs(Tensor0[2, ...] - Reconst[2, ...])

            maxu = np.argmax(erroru)
            maxv = np.argmax(errorv)
            maxw = np.argmax(errorw)

            su = np.unravel_index(maxu, erroru.shape)[-1]
            sv = np.unravel_index(maxv, errorv.shape)[-1]
            sw = np.unravel_index(maxw, errorw.shape)[-1]

            zu = np.unravel_index(maxu, erroru.shape)[-2]
            zv = np.unravel_index(maxv, errorv.shape)[-2]
            zw = np.unravel_index(maxw, errorw.shape)[-2]
            
            zu=nz/2;zv=nz/2;zw=nz/2
            
            if user_choice==2:
                Ared=np.reshape(Ared,[3,5,2,3,Tensor.shape[-1]],order='F') 
            elif user_choice==1:
                Ared=np.reshape(Ared,[2,5,10,Tensor.shape[-1]],order='F') 
            elif user_choice==3:
                Ared=np.reshape(Ared,[2,5,10,Tensor.shape[-1]],order='F')
            elif user_choice==4:
                Ared=np.reshape(Ared,[10,2,5,Tensor.shape[-1]],order='F')
            else:
                Ared=np.reshape(Ared,[2,25,10,Tensor.shape[-1]],order='F')


            fig, ax = plt.subplots(Reconst.shape[0], 5, figsize=(15, 6), width_ratios=[25, 25, 25, 25, 1])
            ax[0, 0].set_ylabel('Y')
            ax[0, 0].yaxis.set_label_coords(-0.025, .5)
            ax[1, 0].set_ylabel('Y')
            ax[1, 0].yaxis.set_label_coords(-0.025, .5)
            ax[2, 0].set_ylabel('Y')
            ax[2, 0].yaxis.set_label_coords(-0.025, .5)
            ax[0, 0].set_yticks([])
            ax[0, 1].set_yticks([])
            ax[0, 2].set_yticks([])
            ax[0, 3].set_yticks([])
            ax[1, 0].set_yticks([])
            ax[1, 1].set_yticks([])
            ax[1, 2].set_yticks([])
            ax[1, 3].set_yticks([])
            ax[2, 0].set_yticks([])
            ax[2, 1].set_yticks([])
            ax[2, 2].set_yticks([])
            ax[2, 3].set_yticks([])
            ax[2, 0].set_xlabel('X')
            ax[2, 1].set_xlabel('X')
            ax[2, 2].set_xlabel('X')
            ax[2, 3].set_xlabel('X')
            ax[2, 0].xaxis.set_label_coords(.5, -.05)
            ax[2, 1].xaxis.set_label_coords(.5, -.05)
            ax[2, 2].xaxis.set_label_coords(.5, -.05)
            ax[2, 3].xaxis.set_label_coords(.5, -.05)
            ax[1, 0].set_xticks([])
            ax[1, 1].set_xticks([])
            ax[1, 2].set_xticks([])
            ax[1, 3].set_xticks([])
            ax[0, 0].set_xticks([])
            ax[0, 1].set_xticks([])
            ax[0, 2].set_xticks([])
            ax[0, 3].set_xticks([])
            ax[2, 0].set_xticks([])
            ax[2, 1].set_xticks([])
            ax[2, 2].set_xticks([])
            ax[2, 3].set_xticks([])
            ax[0, 0].set_title('Real')
            ax[0, 1].set_title('Downsampled ')
            ax[0, 2].set_title('Reconstruction ')
            ax[0, 3].set_title('Absolute Error')

            ax[0, 0].contourf(Tensor0[0, ..., nz, su], cmap='viridis')
            im1 = ax[0, 1].contourf(Ared[0, ..., 1, su], cmap='viridis')
            im2 = ax[0, 2].contourf(Reconst[0, ..., nz, su], cmap='viridis')
            im3 = ax[0, 3].contourf(erroru[..., nz, su], cmap='viridis')

            ax[1, 0].contourf(Tensor0[1, ..., nz, sv], cmap='viridis')
            im4 = ax[1, 1].contourf(Ared[1, ..., 1, sv], cmap='viridis')
            im5 = ax[1, 2].contourf(Reconst[1, ..., nz, sv], cmap='viridis')
            im6 = ax[1, 3].contourf(errorv[..., nz, sv], cmap='viridis')

            ax[2, 0].contourf(Tensor0[2, ..., nz, sw], cmap='viridis')
            im7 = ax[2, 1].contourf(Ared[2, ..., 1, sw], cmap='viridis')
            im8 = ax[2, 2].contourf(Reconst[2, ..., nz, sw], cmap='viridis')
            im9 = ax[2, 3].contourf(errorw[..., nz, sw], cmap='viridis')

            #plt.colorbar(im2, cax=ax[0, 2])
            #plt.colorbar(im3, cax=ax[1, 2])
            plt.colorbar(im2, cax=ax[0, 4])
            plt.colorbar(im5, cax=ax[1, 4])
            #plt.colorbar(im5, cax=ax[2, 2])
            plt.colorbar(im8, cax=ax[2, 4])

            plt.tight_layout()
            plt.show()

        elif Reconst.ndim == 4:

            for i in range(Reconst.shape[0]):
                # Compute the absolute error for the current variable
                #error = np.abs(((Tensor0[i, ...]*(Factor[i])+Media[i])+Media_tiempo[i,:,:,:]) - ((Reconst[i, ...]*(Factor[i])+Media[i])+Media_tiempo[i,:,:,:]))
                error = np.abs(Tensor0[i, ...] - Reconst[i, ...])
                
                # Find the index of the maximum error
                max_idx = np.argmax(error)
                s = np.unravel_index(max_idx, error.shape)[-1]
            
                # Create a new figure for the current variable
                fig, ax = plt.subplots(1, 5, figsize=(18, 4), width_ratios=[25, 25, 25, 25, 1])
                for axs in ax.flatten():
                    axs.set(xticks=[], yticks=[])
            
                # Set axis labels and titles
                ax[0].set_ylabel('Y')
                ax[0].yaxis.set_label_coords(-0.025, .5)
                ax[0].set_xlabel('X')
                ax[1].set_xlabel('X')
                ax[2].set_xlabel('X')
                ax[3].set_xlabel('X')

                if user_choice==2:
                    Ared=np.reshape(Ared,[3,5,2,3,Tensor.shape[-1]],order='F') 
                elif user_choice==1:
                    Ared=np.reshape(Ared,[2,5,10,Tensor.shape[-1]],order='F') 
                elif user_choice==3:
                    Ared=np.reshape(Ared,[2,5,10,Tensor.shape[-1]],order='F')
                elif user_choice==4:
                    Ared=np.reshape(Ared,[10,2,5,Tensor.shape[-1]],order='F')
                    #Media1=np.reshape(Media1,[10,2,5,Tensor.shape[-1]],order='F')
                    Media_tiempo1=np.reshape(Media_tiempo1,[10,2,5,Tensor.shape[-1]],order='F')

                else:
                    Ared=np.reshape(Ared,[2,25,10,Tensor.shape[-1]],order='F')
                    #Media1=np.reshape(Media1,[2,5,10,Tensor.shape[-1]],order='F')
                    Media_tiempo1=np.reshape(Media_tiempo1,[2,25,10,Tensor.shape[-1]],order='F')


                if user_choice==4:   
                    Reconst[i, ..., s]=(Reconst[i, ..., s]*(Factor[i])+Media[i])+Media_tiempo[i,:,:,s]
                    Tensor0[i, ..., s]=(Tensor0[i, ..., s]*(Factor[i])+Media[i])+Media_tiempo[i,:,:,s]
                    Ared[i, ..., s]=(Ared[i, ..., s]*(Factor[i])+Media[i])+Media_tiempo1[i,:,:,s]
                    Reconst[Reconst<0]=0
                    Tensor0[Tensor0<0]=0
                    
                elif user_choice==5:
                    Reconst[i, ..., s]=(Reconst[i, ..., s]*(Factor[i])+Media[i])+Media_tiempo[i,:,:,s]
                    Tensor0[i, ..., s]=(Tensor0[i, ..., s]*(Factor[i])+Media[i])+Media_tiempo[i,:,:,s]
                    Ared[i, ..., s]=(Ared[i, ..., s]*(Factor[i])+Media[i])+Media_tiempo1[i,:,:,s]
                    Reconst=Reconst
                else:
                    Reconst=Reconst
                    
                #ax[0].set_title('Real')
                #ax[1].set_title('Reconstruction')
                #ax[3].set_title('Absolute Error')
            
                # Plot the real part, reconstruction, and error
                if user_choice==4 or user_choice==5:
                    ax[0].contourf(Tensor0[i, ..., s], cmap='viridis')
                    im1 = ax[1].contourf(Ared[i, ..., s], cmap='viridis')
                    im2 = ax[2].contourf(Reconst[i, ..., s], cmap='viridis')
                    im3 = ax[3].contourf(error[..., s], cmap='viridis')               
                else:
                    ax[0].contourf(Tensor0[i, ..., s], cmap='viridis')
                    im1 = ax[1].contourf(Ared[i, ..., s], cmap='viridis')
                    im2 = ax[2].contourf(Reconst[i, ..., s], cmap='viridis')
                    im3 = ax[3].contourf(error[..., s], cmap='viridis')
            
                # Add colorbars
                plt.colorbar(im2, cax=ax[4])
                #plt.colorbar(im1, cax=ax[4])
            
                # Adjust layout and show the plot
                plt.tight_layout()
                #plt.suptitle(f'Variable {i + 1} - Max Error Slice {s}', y=1.02)
                plt.show()


        else:
            erroru = np.abs(Tensor0 - Reconst)
            maxu = np.argmax(erroru)

            su = np.unravel_index(maxu, erroru.shape)[-1]

            fig, ax = plt.subplots(1, 4, figsize=(13, 4), width_ratios=[25, 25, 25, 1])
            for axs in ax.flatten():
                axs.set(xticks=[], yticks=[])

            ax[0].set_ylabel('Y')
            ax[0].yaxis.set_label_coords(-0.025, .5)

            ax[0].set_xlabel('X')
            ax[1].set_xlabel('X')
            ax[2].set_xlabel('X')

            #ax[0].set_title('Real')
            #ax[1].set_title('Reconstruction')
            #ax[3].set_title('Absolute Error')

            ax[0].contourf(Tensor0[..., su], cmap='viridis')
            im1 = ax[1].contourf(Reconst[..., su], cmap='viridis')
            im2 = ax[2].contourf(erroru[..., su], cmap='viridis')

            #plt.colorbar(im1, cax=ax[2])
            plt.colorbar(im1, cax=ax[3])

            plt.tight_layout()
            plt.show()



        epsU = (Tensor0[0, ...] - Reconst[0, ...]) / np.abs(Tensor0[0, ...] - Reconst[0, ...]).max()
        if Tensor.ndim > 3:
            epsV = (Tensor0[1, ...] - Reconst[1, ...]) / np.abs(Tensor0[1, ...] - Reconst[1, ...]).max()
            if Tensor0.shape[0] > 2:
                epsW = (Tensor0[2, ...] - Reconst[2, ...]) / np.abs(Tensor0[2, ...] - Reconst[2, ...]).max()

        # Plot PD Functions
        fig, ax = plt.subplots(1, 1, figsize=(18, 10))
        sns.histplot(data=epsU.flatten(), stat='probability', bins=50, legend=True, ax=ax,
                     label=r'$\frac{\epsilon_u}{|\epsilon_{u, max}|}$', kde=False, fill=False,
                     common_norm=False, element='poly', color="red")

        if Tensor0.ndim > 3:
            if Tensor0.shape[0] >= 2:
                sns.histplot(data=epsV.flatten(), stat='probability', bins=50, legend=True, ax=ax,
                             label=r'$\frac{\epsilon_v}{|\epsilon_{v, max}|}$', kde=False, fill=False,
                             common_norm=False, element='poly', color="green")

                if Tensor0.shape[0] == 3:
                    sns.histplot(data=epsW.flatten(), stat='probability', bins=50, legend=True, ax=ax,
                                 label=r'$\frac{\epsilon_w}{|\epsilon_{w, max}|}$', kde=False, fill=False,
                                 common_norm=False, element='poly', color="blue")

            ax.legend(loc='best')

            ax.set(xlabel=None, ylabel=None)

        ax.set_xlabel('Error')
        ax.set_ylabel('Probability')

        ax.vlines(0, ymin=0, ymax=0.5, colors="gray", alpha=0.8, lw=2, linestyles="dashed")
        plt.tight_layout()
        plt.show()
        print(freqs)

if calibrate:
    errors = []
    # Reconstruction case
    """
    Case 0. K is not reduced, meaning all snapshots are available
    
    Case 1. When applying lcSVD inside lcHODMD on a tensor with snapshots < K, then lcSVD returns Vred, which is V for the downsampled dataset
                """

    caseList = ['Case 0: Time component has not been downsampled', 'Case 1: Time component downsampled. V not reconstructed when applying lcSVD',
                'Case 1: Time component downsampled. V has not been reconstructed when applying lcSVD']

    if n_snap == Tensor.shape[-1]:
        case = 0

    else:
        case = 1 # 1 o 2

    if case == 0:
        T = np.linspace(0, Tensor.shape[-1] - 1, num = Tensor.shape[-1]) * deltaT

    elif case == 1:
        T = np.linspace(0, n_snap - 1, num = n_snap) * deltaT

    print(caseList[case])
    for d, case in zip(d_list, case_d):
        print(f'Running case {case}')
        # 2. Applying lcHODMD (if the window size is 1 -> lcDMD, else -> lcHODMD)
        if d == 1:
            t0 = time.time()
            u, Amplitude, Eigval, GrowthRate, Frequency, DMDmode = dmd1(Ared, Tensor, deltaT, esvd, edmd, Time, points,
                                                                        case)
            icomp = complex(0, 1)
            mu = np.zeros(np.size(GrowthRate), dtype=np.complex64)
            for i in range(np.size(GrowthRate)):
                mu[i] = np.exp(np.dot(deltaT, GrowthRate[i] + np.dot(icomp, Frequency[i])))
            Reconst = reconstruct(u, T, mu)
            t1 = time.time()

            print(f'lcDMD completed in {np.round(t1 - t0, 3)} seconds')

        else:
            t0 = time.time()
            u, Amplitude, Eigval, GrowthRate, Frequency, DMDmode = lcHODMD(Ared, Tensor, d, deltaT, T, esvd, edmd, Time,
                                                                           points, case)
            icomp = complex(0, 1)
            mu = np.zeros(np.size(GrowthRate), dtype=np.complex64)
            for i in range(np.size(GrowthRate)):
                mu[i] = np.exp(np.dot(deltaT, GrowthRate[i] + np.dot(icomp, Frequency[i])))
            Reconst = reconstruct(u, T, mu)
            t1 = time.time()

            print(f'lcHODMD completed in {np.round(t1 - t0, 3)} seconds')

        # 3. RRMS error and other reconstruction error metrics (UQ)
        # Reconst, which is the reconstruction matrix JxK is reshaped so that its shape matches Tensor (nv, nx, ny, ..., snapshots)
        newshape = []

        newshape.append(shape[:-1])
        newshape.append(DMDmode.shape[-1])

        newshape = list(newshape[0]) + [newshape[1]]

        DMDmode = np.reshape(DMDmode, np.array(newshape))

        shape1 = []

        shape1.append(shape[:-1])
        shape1.append(Reconst.shape[-1])

        shape1 = list(shape1[0]) + [shape1[1]]

        Reconst = np.reshape(Reconst, np.array(shape1))

        if case == 1:
            RRMSE = np.linalg.norm(np.reshape(Tensor[..., Time] - Reconst, newshape=(np.size(Tensor[..., Time]), 1)),
                                   ord=2) / np.linalg.norm(
                np.reshape(Tensor[..., Time], newshape=(np.size(Tensor[..., Time]), 1)))

        else:
            RRMSE = np.linalg.norm(np.reshape(Tensor - Reconst, newshape=(np.size(Tensor), 1)), ord=2) / np.linalg.norm(
                np.reshape(Tensor, newshape=(np.size(Tensor), 1)))

        errors.append(RRMSE)
        print(f'\nRRMS error made in the during reconstruction: {np.round(RRMSE * 100, 3)}%\n')


    plt.figure(figsize=(10, 10))
    # Reverse the order of d_list and error
    
    print(d_list)

    
    plt.plot(d_list, errors, 'bs')
    plt.xlabel('Window size')

    # Setting the x-ticks and labels
    plt.xticks(ticks=d_list, rotation=45)  # rotation=45 to tilt the labels if they are long
    # Set uniform limits for both axes
    x_min, x_max = min(d_list), max(d_list)  # Determine min and max of x data
    y_min, y_max = min(errors), max(errors)    # Determine min and max of y data
    
    # Apply limits to make the axes uniform
    plt.xlim(x_min, x_max)
    plt.ylim(y_min, y_max)


    plt.ylabel('RRMSE (%)')
    plt.tight_layout()
    plt.show()